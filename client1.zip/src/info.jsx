// 1 হাজার বছরের শ্রেষ্ঠ বাঙ্গালি জাতির পিতা বঙ্গবন্ধু শেখ মুজিবুর রহমানের জন্মশতবার্ষিকী ও জাতীয় শিশু দিবস উপলক্ষে #বন্ধুসততা_বিজনেস__লিমিটেড'র আয়োজনে আলোচনা সভা, দাোয়া, কেককর্তন ও মিষ্টান্ন বিতরন অনুষ্ঠান।
// 2 স্মরণ করি সকল শহীদদের, যাদের  জন্য আজকের এই স্বাধীনতা
// 3 বন্ধুসততা বিজনেস লিঃ কর্তৃক বড়জামবাড়ীয়া সরকারী প্রাথঃ বিদ্যালয় এর 
//  বিদায়ী ছাত্র/ছাত্রী ও শিক্ষকদের পুরস্কার বিতরন করেন #বন্ধুসততা বিজনেস লিমিটেডের এর পরিচালক মো: মোশাররফ হোসেন সোহেল।
// 4 বন্ধুসততা বিজনেস লিঃ এর পক্ষ থেকে  জামবাড়ীয়া বালিকা উচ্চ বিদ্যালয় এ ফ্যান  উপহার দেওয়ার সময়!
// 5বিনম্র শ্রদ্ধা,,,,,
// বন্ধুসততা বিজনেস লিঃ এর উদ্দোগে  শোকাবহ ১৫ ই আগষ্টের আলোচনা ও দোয়া মাহফিল।
//6 বিনম্র শ্রদ্ধা,,,,,
// বন্ধুসততা বিজনেস লিঃ এর উদ্দেগে জামবাড়ীয়া ইউনিয়নের ০৯ নং ওয়ার্ড বড়জামবাড়ীয়ায় শোকাবহ ১৫ ই আগষ্টের আলোচনা ও দোয়া মাহফিল।
// 71 জুন, 2019  · 
// গতকাল বন্ধুসততা বিজনেস লিঃ, বড়জামবাড়ীয়া এর উদ্দ্যেগে অসহায় দরিদ্র মানুষের মাঝে লাচ্ছা - সেমাই  বিতরন, ইফতার ও দোয়া অনুষ্ঠান।
// 8 1 জুন, 2019  · 
// BSBL এর উদ্দোগে ইফতার পার্টি !
// 9 28 মার্চ, 2019  · 
// #বন্ধুসততা বিজনেস লি:  (BSBL)   কর্তিক আয়োজিত মহান স্বাধীনতা ও জাতীয় দিবস উপলক্ষে বড়জামবাড়ীয়া সরকারী প্রাথমিক বিদ্যালয় মাঠে   খেলাধুলার উপহার তুলে দেন বন্ধুসততা বিজনেস লিঃ এর চেয়ারম্যান মোশাররফ হোসেন সোহেল এবং বাবুল আকতার,
// 10 সকল শহীদের স্বরনে,,,,
// 11 বন্ধুসততা বিজনেস লিঃ (BSBL) এর প্রধান কার্যালয়,,,,



    // if(dglData.length){ 
 
    //     let total_admission_fee= 0;
    //     let total_loan_fees = 0;
    //     let total_insurance = 0;
    //     let total_form_fee = 0;
    //     let total_miscellaneous = 0;
    //     let total_number_of_members = 0;
    //     let total_profit_withdrawal = 0;
    //     let total_w_debt_provide = 0;
    //     let total_d_debt_provide = 0;
    //     let total_m_debt_provide = 0;
    //     let total_sm_debt_provide = 0;
    //     let total_recoverable = 0;
    //     let total_realization = 0;  
    
    //     dglData.filter(info => {
    
    //         //    total_admission_fee = total_admission_fee+Number(info.admission_fee);
    //         //    total_loan_fees = total_loan_fees+Number(info.loan_fees);
    //         //    total_insurance = total_insurance+Number(info.insurance);
    //         //    total_form_fee = total_form_fee+Number(info.form_fee);
    //         //    total_miscellaneous = total_miscellaneous+Number(info.miscellaneous);
    //         //    total_number_of_members = total_number_of_members+Number(info.number_of_members); 
    //         //    total_profit_withdrawal = total_profit_withdrawal+Number(info.profit_withdrawal);
    //         //    total_w_debt_provide = total_w_debt_provide+Number(info.w_debt_provide);
    //         //    total_d_debt_provide = total_d_debt_provide+Number(info.d_debt_provide);
    //         //    total_m_debt_provide = total_m_debt_provide+Number(info.m_debt_provide);
    //         //    total_sm_debt_provide = total_sm_debt_provide+Number(info.sm_debt_provide);
    //         //    total_recoverable = total_recoverable+Number(info.recoverable);
    //         //    total_realization = total_realization+Number(info.realization);
    //         //console.log(info);
    //     })     
    //     let newInfo = {...newDglResultInfo};
    //     newInfo.admission_fee= total_admission_fee;
    //     newInfo.loan_fees = total_loan_fees;
    //     newInfo.insurance = total_insurance;
    //     newInfo.form_fee = total_form_fee;
    //     newInfo.miscellaneous = total_miscellaneous;
    //     newInfo.number_of_members = total_number_of_members;
    //     newInfo.profit_withdrawal = total_profit_withdrawal;
    //     newInfo.w_debt_provide = total_w_debt_provide;
    //     newInfo.d_debt_provide = total_d_debt_provide;
    //     newInfo.m_debt_provide = total_m_debt_provide;
    //     newInfo.sm_debt_provide = total_sm_debt_provide;
    //     newInfo.recoverable = total_recoverable;
    //     newInfo.realization = total_realization;  
    
    //     setNewDglResultInfo(newInfo); 
    // } 


    let details  = {
            total_admission_fee: 0,
            total_d_debt_provide: 0,
            total_form_fee: 0,
            total_insurance: 0,
            total_loan_fees: 0,
            total_m_debt_provide: 0,
            total_miscellaneous: 0,
            total_number_of_members: 1,
            total_profit_withdrawal: 0,
            total_realization: 100,
            total_recoverable: 200,
            total_sm_debt_provide: 0,
            total_w_debt_provide: 0,
    }

    let {    total_admission_fee, total_d_debt_provide, total_form_fee,  total_insurance, total_loan_fees,  total_m_debt_provide,  total_miscellaneous,  total_number_of_members,   total_profit_withdrawal,  total_realization, total_recoverable,  total_sm_debt_provide,  total_w_debt_provide,
    } = details;



    let info = ` "total_admission_fee",  "total_d_debt_provide",  "total_form_fee",  "total_insurance",  "total_loan_fees",  "total_m_debt_provide",  "total_miscellaneous",  "total_number_of_members",  "total_profit_withdrawal",  "total_realization",  "total_recoverable",  "total_sm_debt_provide",  "total_w_debt_provide" `