 


import React, { createContext } from 'react';
import { useState } from 'react';
import Login from './Components/Login/Login.jsx'
import Admin from './Components/Adminn/Admin.jsx'
// admin panel
import NewAdd from './Components/NewAdd/NewAdd.jsx';
// passbook
import DGL from './Components/DGL/DGL.jsx'
// dgl
import NewMember from './Components/NewMember/NewMember.jsx';
// member Introduction
import LoanReciever from './Components/LoanReciever/LoanReciever.jsx';
// loan reciever
import Navbarr from './Components/Navbarr/Navbarr.jsx';
import Footer  from './Components/Footer/Footer.jsx'; 
import { 
  Switch,
  Route
} from "react-router-dom";
import PrivateRoute from './Components/PrivateRoute/PrivateRoute.jsx';
import NotFound from './Components/NotFound/NotFound.jsx'; 
import HeaderBanner from './Components/HeaderBanner/HeaderBanner.jsx';
import DebtInfoBook from './Components/DebtInfoBook/DebtInfoBook.jsx';
// Loan exchange
import GL from './Components/GL/GL.jsx';
// gl
import DGLResult from './Components/DGLResult/DGLResult.jsx'; 
// dgl result 
import LoggedInUserNavbar from './Components/LoggedInUserNavbar/LoggedInUserNavbar.jsx';
import Profile from './Components/Profile/Profile.jsx';
import WebSettings from './Components/WebSettings/WebSettings.jsx';
import UserSettings from './Components/UserSettings/UserSettings.jsx';
import ContactUs from './Components/ContactUs/ContactUs.jsx';
import AboutUs from './Components/AboutUs/AboutUs.jsx';
import OurServices from './Components/OurServices/OurServices.jsx'; 
import FooterForm from './Components/FooterForm/FooterForm.jsx';
import './App.css' 
import ServerResult from './Components/ServerResult/ServerResult.jsx';
import Notice from './Components/Notice/Notice.jsx'; 
import Services from './Components/OurServices/Services.jsx';
import Messages from './Components/Messages/Messages.jsx';
import DglUpdate from './Components/UpdateContainer/DglUpdate.jsx';
import DglResultUpdate from './Components/UpdateContainer/DglResultUpdate.jsx';
import GlUpdate from './Components/UpdateContainer/GlUpdate.jsx';
import LoanExchangeUpdate from './Components/UpdateContainer/LoanExchangeUpdate.jsx';
import PassbookUpdate from './Components/UpdateContainer/PassbookUpdate.jsx';
import CheckPassbook from './Components/CheckPassbook/CheckPassbook.jsx'; 
import NoticeBoard from './Components/NoticeBoard/NoticeBoard.jsx';
import ContactUsForm from './Components/WebSettings/ContactUsForm.jsx';
import ServicesForm from './Components/WebSettings/ServicesForm.jsx';  
import UploadFile from './Components/UploadFile/UploadFile.jsx';
import Statement from './Components/Statement/Statement.jsx';
import StatementDgl from './Components/Statement/StatementDgl.jsx';
import StatementDglResult from './Components/Statement/StatementDglResult.jsx';
import StatementGl from './Components/Statement/StatementGl.jsx';
import StatementLoanReciever from './Components/Statement/StatementLoanReciever.jsx';
import StatementLoanexchange from './Components/Statement/StatementLoanexchange.jsx';
import StatementPassbook from './Components/Statement/StatementPassbook.jsx';


export const UserContext = createContext();

const App = () => {
  
  const [loggedInUser, setLoggedInUser] = useState({
    admin_level: "",
    admitted_date: "",
    branch_code: "", 
    first_name: "",
    fourth_securityy: "",
    id_find: null, 
    second_email: "",
    third_phone: "",
    work_code: "",
    img__url:'',
    isLoggedIn: false,   
    noticeLength:0,
  })
  
 

  return (
    <UserContext.Provider className='bg-danger' value={[loggedInUser, setLoggedInUser]}> 
        {/* <UploadFile/> */}
        <Navbarr/>
        <Notice/>   
        <LoggedInUserNavbar/>  
        <ServerResult/>
            <Switch>
              <Route exact path='/'>    
                <HeaderBanner/>
                <Services/>
              </Route> 
              <Route path='/login'>
                <Login/>
              </Route>
              <Route path='/checkpassbook'> 
                <CheckPassbook/>
              </Route>
              <Route path='/ourservices'>
                <OurServices/>
              </Route>
              <Route path='/aboutus'>
                <AboutUs/>
              </Route>
              <Route path='/notice'> 
                <NoticeBoard/>
              </Route>
              <Route path='/contactus'>
                <ContactUs/>
              </Route>
              <PrivateRoute path='/profile'> 
                  <Profile/>
              </PrivateRoute>  
              <PrivateRoute path='/adminpanel'>
                <Admin/>
              </PrivateRoute>  
              
              <PrivateRoute path='/dgl'>
                <DGL/>
              </PrivateRoute>  
              <PrivateRoute path='/dglresults'>
                <DGLResult/>
              </PrivateRoute>  
              <PrivateRoute path='/gl'>
                <GL/>
              </PrivateRoute>  
              <PrivateRoute path='/loanreciever'>
                <LoanReciever/>
              </PrivateRoute>  
              <PrivateRoute path='/loanexchange'>
                <DebtInfoBook/>
              </PrivateRoute>  
              <PrivateRoute path='/statement'>
                <Statement/>
              </PrivateRoute>  
              <PrivateRoute path='/statementpassbook'>
                <StatementPassbook/>
              </PrivateRoute>  
              <PrivateRoute path='/statementloanexchange'>
                <StatementLoanexchange/>
              </PrivateRoute>  
              <PrivateRoute path='/statementloanreciever'>
                <StatementLoanReciever/>
              </PrivateRoute>  
              <PrivateRoute path='/statementgl'>
                <StatementGl/>
              </PrivateRoute>  
              <PrivateRoute path='/statementdglresult'>
                <StatementDglResult/>
              </PrivateRoute>  
              <PrivateRoute path='/statementdgl'>
                <StatementDgl/>
              </PrivateRoute>
              <PrivateRoute path='/memberintroduction'>
                <NewMember/>
              </PrivateRoute>   
              {/* update section start here //////////////////////// */}

              <PrivateRoute path='/dglupdate/:id'> 
                <DglUpdate/> 
              </PrivateRoute>
              <PrivateRoute path='/dglresultupdate/:id'> 
                <DglResultUpdate/>
              </PrivateRoute>
              <PrivateRoute path='/glupdate/:id'> 
                <GlUpdate/>
              </PrivateRoute> 
              <PrivateRoute path='/messages'>  
                <Messages/>
              </PrivateRoute>
              <PrivateRoute path='/loanexchangeupdate/:id'> 
                <LoanExchangeUpdate/>
              </PrivateRoute>
              <PrivateRoute path='/passbookupdate/:id'> 
                <PassbookUpdate/>
              </PrivateRoute> 

              {/* update section finish here /////////////////////*/}
              <PrivateRoute path='/passbook'>
                <NewAdd/>
              </PrivateRoute>   
              <PrivateRoute path='/usersettings'>
                <UserSettings/>
              </PrivateRoute>  
              <PrivateRoute exact path='/websettings/notice'>
                  <WebSettings/>
              </PrivateRoute> 
              <PrivateRoute exact path='/websettings/contact'> 
                <ContactUsForm/>
              </PrivateRoute>
              <PrivateRoute exact path='/websettings/service'>
                <ServicesForm/>
              </PrivateRoute>
              <Route path='*'>
                <NotFound/>
              </Route>
            </Switch>
            <FooterForm/> 
           
        <Footer/>
    </UserContext.Provider>
  );
};

export default App;
 