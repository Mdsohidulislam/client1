import './Messages.scss'
import axios from 'axios';
import React, { useEffect } from 'react';
import { useState } from 'react';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import { useContext } from 'react';
import { UserContext } from '../../App';

const Messages = () => {
        const [messages, setMessages] = useState([]);
        const [loggedInUser, setLoggedInUser] = useContext(UserContext); 
        const [deleteState, setDeleteState] = useState(false);
        const [deleteNumber, setDeleteNumber] = useState(0);
        const [ServerResult, setServerResult] = useState({
            successShow:false,
            faildShow:false,
            loaderShow:false,
            successMessage:'',
            faildMesssage:''
        });
        

        useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getalldata',{
            params:{
                code:']42T3a2cP&p?m3Fg',
                database:'message'
            }
        })
        .then(res => {  

            
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        let newLoggedInInfo = {...loggedInUser};
                        newLoggedInInfo.noticeLength=res.data.successResult.length;
                        setLoggedInUser(newLoggedInInfo);

                        setMessages(res.data.successResult);
                    }, 800); 
            }, 800);


        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])


    const handleDeleteAccess =(id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    const handleAdminDelete = () => { 
        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'message'
            }
        })
        .then(response => { 
            

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    return (
        <div className='messages__container bg-dark text-white'> 

            {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleAdminDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}
            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}


            {messages.length?
            
                <div className='container p-3'> 

                    {
                        messages.map(info =>{
                            return <div key={info.id_find} id={info.id_find} className='container border rounded py-3 my-2'> 
                            <p><b>Message ID</b>: ({info.id_find})</p>
                            <p><b>Name</b>: {info.name}</p>
                            <p><b>Email</b>: {info.email}</p>
                            <p><b>Mobile</b>: {info.phone}</p>
                            <p><b>Opinion/Message : </b>: {info.message}</p>
                            <button className='btn btn-outline-danger' onClick={()=>handleDeleteAccess(info.id_find)}>delete</button>
                        </div> 
                        })
                    }




            </div>
            
            :""}
        </div>
    );
};

export default Messages;