import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import './LoggedInUserNavbar.scss'
import NavLogo from '@material-ui/icons/Menu'
import { useContext } from 'react';
import { UserContext } from '../../App';

const LoggedInUserNavbar = () => { 
    const [isClick, setIsClick] = useState(false);
    const [loggedInUser, setLoggedInUser]  = useContext(UserContext); 


    const handleOpenClose = () => { 
        const targetNav = document.getElementById('loggedInUserNavbar');

        if(!isClick){
            targetNav.style.cssText=`
            left: 0;
            transition: .3s;
            `;
            setIsClick(!isClick)

        }
        if(isClick){
            targetNav.style.cssText=`
            left: -200px;
            transition: .3s;
            `
            setIsClick(!isClick)
        }
    }

    const handleLogOut = () => {
        setLoggedInUser({
            admin_level: "",
            admitted_date: "",
            branch_code: "", 
            first_name: "",
            fourth_securityy: "",
            id_find: null, 
            second_email: "",
            third_phone: "",
            work_code: "",
            isLoggedIn: false, 
            bg:'#006600', 
            show: 'none',
            message:'SUCCESSFULLY DATA SUBMITTED',
            err: false
        })
    }
 
    return (
        <>
            {loggedInUser.isLoggedIn?
            
                <div className="logged__in__user__navbar" id='loggedInUserNavbar'>
                    <div className="link__url">

                        {
                            (loggedInUser.admin_level==='1' ||loggedInUser.admin_level==='01') || (loggedInUser.admin_level ==='2' || loggedInUser.admin_level ==='02')?
                            
                            <span>
                                <NavLink className='text-decoration-none' activeClassName='active__link bg-success' to='/profile'><li>PROFILE</li></NavLink> 
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/dgl'><li>DGL</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/dglresults'><li>DGL RESULTS</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/gl'><li>GL</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/loanreciever'><li>LOAN RECIEVER</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/loanexchange'><li>LOAN EXCHANGE</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/memberintroduction'><li>MEMBER INTRODUCTION</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/passbook'><li>PASSBOOK</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/usersettings'><li>USER SETTINGS</li></NavLink> 
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/adminpanel'><li>ADMIN PANEL</li></NavLink>
                                <NavLink className='text-decoration-none' activeClassName='active__link' to='/statement'><li>STATEMENT</li></NavLink> 

                                {loggedInUser.admin_level==='02'?"":<NavLink className='text-decoration-none' activeClassName='active__link' to='/websettings/notice'><li>WEB SETTINGS</li></NavLink>}
                            </span>
                            
                            :''
                        }
                                                {
                            loggedInUser.admin_level==='3' || loggedInUser.admin_level==='03'? 
                            
                            <span>
                                <Link className='text-decoration-none' to='/profile'><li>PROFILE</li></Link>  
                                <Link className='text-decoration-none' to='/memberintroduction'><li>MEMBER INTRODUCTION</li></Link>
                                <Link className='text-decoration-none' to='/passbook'><li>PASSBOOK</li></Link>
                                <Link className='text-decoration-none' to='/usersettings'><li>USER SETTINGS</li></Link>  
                            </span>
                            
                            :''
                        }
                        <li onClick={handleLogOut}>LOG OUT</li>
                    </div>
                    <div onClick={handleOpenClose} className="nav__logo">
                        <NavLogo className="logo"/>
                    </div>
                </div> 
            : ""} 
        </>

    );
};

export default LoggedInUserNavbar;