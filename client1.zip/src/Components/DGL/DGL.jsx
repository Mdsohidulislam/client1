
import axios from 'axios';
import React from 'react';
import { useContext } from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { UserContext } from '../../App'; 
import { _sum } from '../../helpers';
import '../Form.scss';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const DGL = () => {
    
    const [openTable, setOpenTable] = useState(false);
    const [dgl, setDgl] = useState({});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true);
    const [accountInfo, setAccountInfo] = useState([]);
    const [showTotal, setShowTotal] = useState(false)
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })
    const handleBlur = (e) => { 
        const newInfo = {...dgl};
        newInfo[e.target.name]=e.target.value;
        setDgl(newInfo)     
    };
    if(loggedInUser.isLoggedIn){
        dgl.branch_code = loggedInUser.branch_code
    }
    

 

    if(dgl.date){
        let date = dgl.date;
        dgl.month = date.slice(5,7);
        dgl.day = date.slice(8,10);
        dgl.year = date.slice(0,4)  
    }
 

    const handleSubmitLoanReciever = (e) => { 
        e.preventDefault()
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)


        axios.post('https://www.md-sohidul-islam.com/dgl', {
                info: dgl
    }).then(response => {  
        
            setTimeout(() => {
                setDgl({});
                setClear(!Clear);
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data submitted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo); 
                        setClear(true)
                    }, 3000); 
            }, 3000);
        
    }).catch(error => {  
        setTimeout(() => {
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=false;
            newInfo.faildShow=true;
            newInfo.faildMesssage='Internal server error' 
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult};  
                    newInfo.faildShow=false; 
                    setServerResult(newInfo)  
                }, 3000); 
        }, 3000);
    })
    }

    useEffect(()=>{

        axios.get('https://www.md-sohidul-islam.com/getallonebranchdgl',{
            params:{
                code: loggedInUser.branch_code
            }
       })
       .then(res => {     
           setAccountInfo(res.data.successResult)  
       })
       .catch(error => {  
           alert(error.message)
       })

    },[])

    const handleDeleteAccess = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }


    const handleDelete = () =>  {

        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);


        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:"dgl"
            }
        })
        .then(res => {  

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }

    const handleCheck = () => { 

        let debtSum = 0;
        let savingsSum = 0;
        let extraSum = 0;
        let savingsWithDrawSum = 0;
        let debtProvideSum = 0;

        debtSum += _sum(dgl.debt_daily, dgl.debt_weekly, dgl.debt_monthly, dgl.debt_term);
        savingsSum += _sum(dgl.savings_current, dgl.saving__monthly, dgl.saving_weekly);
        extraSum  += _sum(dgl.loan_fees, dgl.form_fee, dgl.miscellaneous, dgl.admission_fee, dgl.insurance)
        savingsWithDrawSum += _sum(dgl.weekly, dgl.monthly, dgl.current);
        debtProvideSum += _sum(dgl.w_debt_provide, dgl.d_debt_provide, dgl.m_debt_provide, dgl.sm_debt_provide);
        
        dgl.total_debt_recovery = debtSum;
        dgl.collection_of_total_savings = savingsSum;
        dgl.total_realization= extraSum + savingsSum + debtSum;
        dgl.total_debt_provide = debtProvideSum;
        dgl.total_savings_withdrawal = savingsWithDrawSum; 
        dgl.total_status = (Number(dgl.total_realization)) - (savingsWithDrawSum+debtProvideSum+Number(dgl.profit_withdrawal))
        setShowTotal(!showTotal)

        // console.log(savingsWithDrawSum, debtProvideSum , dgl.profit_withdrawal);
    }



    return (
        <div style={{backgroundColor:'#015E31'}}>
        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}
            <div className='py-3' style={{backgroundColor:'yellow',color:'darkgreen'}}>
            <p className='text-center'><b>Name</b>: {loggedInUser.first_name} <b>Email</b>: {loggedInUser.second_email} <b>শাখা কোড </b>: {loggedInUser.branch_code}</p>
            </div>
            {Clear? 

                    <div className='form__container text-center' style={{backgroundColor:'#015E31'}}> 
                    <form  onSubmit={handleSubmitLoanReciever}> 
 
                        <input 
                            className='input'
                            type='date'
                            onBlur={handleBlur}
                            placeholder="তারিখ"
                            name='date'
                            required 
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="কর্মীর কোড"
                            name='name_of_the_employee'
                            required
                            type="text"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="শীট নং"
                            name='sheet_no'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="সদস্য সংখ্যা"
                            name='number_of_members'
                            required
                            type="number"
                        />    
                        <span className='py-3'> <b>ঋণ আদায়</b> <br />
                       
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="সাপ্তাহিক"
                                name='debt_weekly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="দৈনিক"
                                name='debt_daily'
                                required
                                type="number"
                            />   
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মাসিক"
                                name='debt_monthly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মেয়াদি"
                                name='debt_term'
                                required
                                type="number"
                            />  
                            {showTotal? 
                            <input 
                                className='input bg-success'
                                onBlur={handleBlur}
                                placeholder="মোট ঋণ আদায়"
                                name='total_debt_recovery'
                                defaultValue={dgl.total_debt_recovery}
                                required
                                type="number"
                            />  :""}
                        </span> 
                        <span className='py-3 mb-1'> <b>সঞ্চয় আদায়</b> <br />
                       
                        
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="সাপ্তাহিক"
                                name='saving_weekly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মাসিক"
                                name='saving__monthly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="চলতি"
                                name='savings_current'
                                required
                                type="number"
                            />  
                            {showTotal?  
                            <input 
                                className='input bg-success'
                                onBlur={handleBlur}
                                placeholder="মোট সঞ্চয় আদায়"
                                name='collection_of_total_savings'
                                required
                                defaultValue={dgl.collection_of_total_savings}
                                type="number"
                            />
                            :""}
                        </span>
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="ভর্তি ফি"
                            name='admission_fee'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="ঋণ ফি"
                            name='loan_fees'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="বীমা"
                            name='insurance'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="ফরম ফি"
                            name='form_fee'
                            required
                            type="number"
                        />  
                        
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="বিবিধ"
                            name='miscellaneous'
                            required
                            type="number"
                        />  
                        {showTotal? 
                        <input 
                            className='input bg-success'
                            onBlur={handleBlur}
                            placeholder="মোট আদায়"
                            name='total_realization'
                            required
                            defaultValue={dgl.total_realization}
                            type="number"
                        />   
                        :""}
                       
                        <span className='py-3'> <b>সঞ্চয় উত্তোলন</b> <br />
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="সাপ্তাহিক"
                                name='weekly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মাসিক"
                                name='monthly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="চলতি"
                                name='current'
                                required
                                type="number"
                            />  
                            {showTotal? 
                            <input 
                                className='input bg-success'
                                onBlur={handleBlur}
                                placeholder="মোট সঞ্চয় উত্তোলন"
                                name='total_savings_withdrawal'
                                required
                                defaultValue={dgl.total_savings_withdrawal}
                                type="number"
                            />
                            :""}
                        </span>

                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="লাভ উত্তোলন"
                            name='profit_withdrawal'
                            required
                            type="number"
                        />  
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            placeholder="সাক্ষর"
                            name='signature'
                            required
                            type="text"
                        />
                        <span className='py-3'> <b>ঋণ প্রদান</b> <br />
                        
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="w ঋণ  প্রদান"
                            name='w_debt_provide'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="d ঋণ  প্রদান"
                            name='d_debt_provide'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="m ঋণ  প্রদান"
                            name='m_debt_provide'
                            required
                            type="number"
                        />  
                        
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="sm ঋণ  প্রদান"
                            name='sm_debt_provide'
                            required
                            type="number"
                        />  
                        {showTotal? 
                        <input 
                            className='input bg-success'
                            onBlur={handleBlur}
                            placeholder="মোট ঋণ  প্রদান"
                            name='total_debt_provide'
                            required
                            type="number"
                            defaultValue={dgl.total_debt_provide}
                        />:""}
                        {showTotal? 
                        <input 
                            className='input bg-success'
                            onBlur={handleBlur}
                            placeholder="মোট স্থিতি"
                            name='total_status'
                            required
                            type="number"
                            defaultValue={dgl.total_status}
                        /> :""}

                    <input 
                        className='input'
                        onBlur={handleBlur}
                        placeholder="আদায়যোগ্য "
                        name='recoverable'
                        required
                        type="number"  
                    />
                    <input 
                        className='input'
                        onBlur={handleBlur}
                        placeholder="আদায় "
                        name='realization'
                        required
                        type="number"  
                        

                    />

                        </span>
                        <div className="w-100 m-2">
                            <input  onClick={handleCheck} value={showTotal? 'Retake' : 'Check'} className={showTotal? 'btn btn-warning clear w-25' : 'btn btn-info w-25'} />
                        </div>
                        <div className="w-100 m-2">
                            <input type="submit" value="Submit" className='btn btn-success w-25' />
                        </div>
                        
                    </form>
                    <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>
                    </div>
                    
            :""}
            
{openTable? 
            
<table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                             ["তারিখ","কর্মীর কোড","শীট নং","সদস্য সংখ্যা","সাপ্তাহিক`","দৈনিক`","মাসিক`","মেয়াদি","মোট ঋণ আদায়","সাপ্তাহিক.","মাসিক.","চলতি.","মোট সঞ্চয় আদায়","ভর্তি ফি","ঋণ ফি","বীমা","ফরম ফি","বিবিধ","মোট আদায়","সাপ্তাহিক","মাসিক","চলতি","মোট সঞ্চয় উত্তোলন","লাভ উত্তোলন","সাক্ষর","w ঋণ  প্রদান","d ঋণ  প্রদান","m ঋণ  প্রদান","sm ঋণ  প্রদান","মোট ঋণ  প্রদান","মোট স্থিতি","শাখা কোড","আদায়যোগ্য", "আদায়"].map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    {/* আদায়  আদায়যোগ্য */}
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.date}</td>  
                                        <td>{info.name_of_the_employee}</td>  
                                        <td>{info.sheet_no}</td>  
                                        <td>{info.number_of_members}</td>  
                                        <td>{info.debt_weekly}</td>  
                                        <td>{info.debt_daily}</td>  
                                        <td>{info.debt_monthly}</td>  
                                        <td>{info.debt_term}</td>  
                                        <td>{info.total_debt_recovery}</td>  
                                        <td>{info.saving_weekly}</td>  
                                        <td>{info.saving__monthly}</td>  
                                        <td>{info.savings_current}</td>  
                                        <td  title={`${info.name_of_the_employee} / ${info.date}`}  className='bg-info'>{info.collection_of_total_savings}</td>  
                                        <td>{info.admission_fee}</td>  
                                        <td>{info.loan_fees}</td>  
                                        <td>{info.insurance}</td>  
                                        <td>{info.form_fee}</td>  
                                        <td>{info.miscellaneous}</td>  
                                        <td  title={`${info.name_of_the_employee} / ${info.date}`}  className='bg-info'>{info.total_realization}</td>  
                                        <td>{info.weekly}</td>  
                                        <td>{info.monthly}</td>  
                                        <td>{info.current}</td>  
                                        <td  title={`${info.name_of_the_employee} / ${info.date}`}  className='bg-info'>{info.total_savings_withdrawal}</td>  
                                        <td>{info.profit_withdrawal}</td>  
                                        <td>{info.signature}</td>  
                                        <td>{info.w_debt_provide}</td>  
                                        <td>{info.d_debt_provide}</td>  
                                        <td>{info.m_debt_provide}</td>  
                                        <td>{info.sm_debt_provide}</td>  
                                        <td title={`${info.name_of_the_employee} / ${info.date}`} className='bg-info'>{info.total_debt_provide}</td>  
                                        <td>{info.total_status}</td>    
                                        <td>{info.branch_code}</td>  
                                        <td>{info.recoverable}</td> 
                                        <td>{info.realization}</td>  
                                        {loggedInUser.admin_level==='01'?<span><button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>DELETE</button><Link to={`/dglupdate/${info.id_find}`}><button className='btn btn-warning btn-sm mr-1'>UPDATE</button></Link></span>:""} 
                                         
                                        
                                         
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}


        </div>
        
    );
};

export default DGL;


 

 
 
 
 

 
 
 
 


 
 
 