
import React from 'react';
import { useContext } from 'react';
import { UserContext } from '../../App';
import './ServerResult.scss'

const ServerResult = () => {



    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const myStyle = {
        backgroundColor: `${loggedInUser.bg}`,
        display:`${loggedInUser.show}` 
    }


    const handleCloseServerResult = () => {
        let newInfo = {...loggedInUser};
        newInfo.show='none';
        setLoggedInUser(newInfo)
    }

    return (
        <div style={myStyle} className='server__result__container'>
             <p style={{color:'white'}}>{loggedInUser.message}</p>
             {loggedInUser.err? <button onClick={handleCloseServerResult}>I got it</button> : ''}
        </div>
    );
};

export default ServerResult;