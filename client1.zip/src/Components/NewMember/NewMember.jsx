import '../Form.scss'
import axios from 'axios';
import React, { useState } from 'react';
import { useContext } from 'react';
import { UserContext } from '../../App';
import { useEffect } from 'react'; 
import 'react-super-responsive-table/dist/SuperResponsiveTableStyle.css';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import FaildResult from '../Loader/FaildResult';




const NewMember = () => {

    const [newMemberInfo, setNewMemberInfo] = useState({});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true);
    const [openTable, setOpenTable] = useState(false);
    const [memberInfos, setMemberInfos] = useState([])
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const tableHeader = ["শাখা কোড ","প্রকল্পের ধরণ","বই নম্বর","হিসাব নম্বর","লেজার পৃষ্ঠা নম্বর","ভর্তির তারিখ","নাম","পিতা / স্বামী","মাতা","নমিনীর নাম","ঠিকানা","কর্মীর নাম","কেন্দ্র নং","কর্ম এলাকার কোড","কর্মীর মোবাইল নং","ঋণের স্থিতি","কিস্তি সংখ্যা","কততম ঋণ গ্রহণ"];
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })

    const handleBlur = (e) => { 
        const newInfo = {...newMemberInfo};
        newInfo[e.target.name]=e.target.value;
        setNewMemberInfo(newInfo)   
    };

    newMemberInfo.branch_code=loggedInUser.branch_code;

    const handleBlurAccountNumber = (e) => {
        newMemberInfo.hisabNumber=loggedInUser.branch_code+e.target.value;
    };

    useEffect(()=>{  
         axios.get('https://www.md-sohidul-islam.com/getallmember',{
             params:{
                code:']42T3a2cP&p?m3Fg'
             }
         })
         .then(response => { 
             setMemberInfos(response.data.successResult); 
         }).catch(error => {  
            let newLoggedInUserInfo = {...loggedInUser};
            newLoggedInUserInfo.bg='red';
            newLoggedInUserInfo.show='flex';
            newLoggedInUserInfo.err= true;
            newLoggedInUserInfo.message=error.message;
            setLoggedInUser(newLoggedInUserInfo); 
         })
    },[])

    if(newMemberInfo.vortirTarikh){
        let vortirTarikh = newMemberInfo.vortirTarikh;
        newMemberInfo.month = vortirTarikh.slice(5,7);
        newMemberInfo.day = vortirTarikh.slice(8,10);
        newMemberInfo.year = vortirTarikh.slice(0,4)  
    }
    if(newMemberInfo.how_much_to_borrow){
        let bl=(newMemberInfo.how_much_to_borrow).length 
        if(bl === 1){
            newMemberInfo.how_much_to_borrow = "0"+newMemberInfo.how_much_to_borrow; 
        }
    }
  
    const handleSubmitNewMember = (e) => { 
        e.preventDefault();

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.post('https://www.md-sohidul-islam.com/newmember', {
                info: newMemberInfo
    }).then(response => {  
        
        setTimeout(() => {    
            setClear(!Clear);  

            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo); 
                    setClear(true)
                }, 3000); 
        }, 3000);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }

    const handleDeleteAccess =(id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    const handleDelete = () => {

        setDeleteState(false);

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'newmember'
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);
            
        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    return ( 
        <div style={{backgroundColor:'#015e31'}}>
        
        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}


        {ServerResult.loaderShow? <Loader/>:""}
        {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
        {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}
        
        <div className='py-2' style={{backgroundColor:'#e6e600', color:'#015e31'}}>
            
            <p className='text-center'><b>Name</b>: {loggedInUser.first_name} <b>Email</b>: {loggedInUser.second_email} <b>শাখা কোড </b>: {loggedInUser.branch_code}</p>

        </div>



            {Clear?  
            
            
            <div className='form__container text-center'>     
            <form onSubmit={handleSubmitNewMember}>  
            
                <select onBlur={handleBlur} name="prokolperNam" className='input' required>
                    <option>প্রকল্পের ধরণ</option>
                    <option value="W">W</option>
                    <option value="D">D</option>
                    <option value="M">M</option> 
                    <option value="SM">SM</option> 
                </select> 

                <input className="input"   onBlur={handleBlur} type='number' label="বই নম্বর" variant="outlined" color="secondary"    placeholder="বই নম্বর" name="boiNumber" required/>  
                <input className="input"   onBlur={handleBlurAccountNumber} type='number' label="হিসাব নম্বর" variant="outlined" color="secondary"    placeholder="হিসাব নম্বর" name="hisabNumber" required/>  
                <input className="input"   onBlur={handleBlur} type='number' label="লেজার পৃষ্ঠা নম্বর" variant="outlined" color="secondary"    placeholder="লেজার পৃষ্ঠা নম্বর" name="lejarPresthaNumber" required/>  
                <input className="input"   onBlur={handleBlur} type='date'  variant="outlined" color="secondary"    placeholder="ভর্তির তারিখ" name="vortirTarikh" required/>  
                <input className="input"   onBlur={handleBlur} label="নাম" variant="outlined" color="secondary"    placeholder="নাম" name="nam" required/>  
                <input className="input"   onBlur={handleBlur} label="পিতা / স্বামী" variant="outlined" color="secondary"    placeholder="পিতা / স্বামী" name="pitaShami" required/>  
                <input className="input"   onBlur={handleBlur} label="মাতা" variant="outlined" color="secondary"    placeholder="মাতা" name="mata" required/>  
                <input className="input"   onBlur={handleBlur} label="নমিনীর নাম" variant="outlined" color="secondary"    placeholder="নমিনীর নাম" name="nominirNam" required/>  
                <input className="input"   onBlur={handleBlur} label="ঠিকানা" variant="outlined" color="secondary"    placeholder="ঠিকানা" name="thikana" required/>  
                <input className="input"   onBlur={handleBlur} label="কর্মীর নাম" variant="outlined" color="secondary"    placeholder="কর্মীর নাম" name="kormirNam" required/>  
                <input className="input"   onBlur={handleBlur} type='number' label="কেন্দ্র নং" variant="outlined" color="secondary"    placeholder="কেন্দ্র নং" name="kendroNo" required/>  
                <input className="input"   onBlur={handleBlur} type='number' label="কর্ম এলাকার নাম" variant="outlined" color="secondary"    placeholder="কর্ম এলাকার কোড" name="kormoElakarCode" required/>     
                <input className="input"   onBlur={handleBlur} type='number' label="কর্মীর মোবাইল নং" variant="outlined" color="secondary"    placeholder="কর্মীর মোবাইল নং" name="kormirMobileNo" required/>
                <input onBlur={handleBlur} type="number" name='debt_total' className='input' placeholder='ঋণের স্থিতি' required/>
                <input onBlur={handleBlur} type="text" name='installment_count' className='input' placeholder='কিস্তি সংখ্যা' required/>
                <input onBlur={handleBlur} type="number" name='how_much_to_borrow'   className='input' placeholder='কততম ঋণ গ্রহণ' required/>   
                <input type="submit" className='submit__button' value='submit' />
            </form>
            <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>
        </div> 
            // ["শাখা কোড ","প্রকল্পের ধরণ","বই নম্বর","হিসাব নম্বর","লেজার পৃষ্ঠা নম্বর","ভর্তির তারিখ","নাম","পিতা / স্বামী","মাতা","নমিনীর নাম","ঠিকানা","কর্মীর নাম","কেন্দ্র নং","কর্ম এলাকার কোড","কর্মীর মোবাইল নং","ঋণের স্থিতি","কিস্তি সংখ্যা","কততম ঋণ গ্রহণ"]
            :""}

{openTable? 
<table className='table table-dark' style={{overflow:'scroll', width:'2000px'}}>
                <thead>
                    <tr>
                        {
                            tableHeader.map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                {memberInfos.length? 
                 <tbody>
                        
                        {
                             memberInfos.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                 <td>{info.branch_code}</td>
                                 <td>{info.prokolperNam}</td> 
                                  
                                        <td>{info.boiNumber}</td> <td>{info.hisabNumber}</td> <td>{info.lejarPresthaNumber}</td>	<td>{info.vortirTarikh}</td>	<td>{info.nam}</td>	<td>{info.pitaShami}</td>	<td>{info.mata}</td>	<td>{info.nominirNam}</td>	<td>{info.thikana}</td>	<td>{info.kormirNam}</td>	<td>{info.kendroNo}</td>	<td>{info.kormoElakarCode}</td>	<td>{info.kormirMobileNo}</td>  <td>{info.debt_total}</td> <td>{info.installment_count}</td> <td>{info.how_much_to_borrow}</td> 
                                        {loggedInUser.admin_level==='01'? <button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button>:''}
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>:""}
            </table>:""}
        </div>
    );
};

export default NewMember;

// prokolperNam, boiNumber, hisabNumber, lejarPresthaNumber,	vortirTarikh,	nam,	pitaShami,	mata,	nominirNam,	thikana,	kormirNam,	kendroNo,	kormoElakarCode,	kormirMobileNo,	day,	month,	year, debt_total, installment_count, how_much_to_borrow, branch_code
// '${prokolperNam}', '${boiNumber}', '${hisabNumber}', '${lejarPresthaNumber}',	'${vortirTarikh}',	'${nam}',	'${pitaShami}',	'${mata}',	'${nominirNam}',	'${thikana}',	'${kormirNam}',	'${kendroNo}',	'${kormoElakarCode}',	'${kormirMobileNo}',	'${day}',	'${month}',	'${year}','${debt_total}','${installment_count}','${how_much_to_borrow}','${branch_code}'