import axios from 'axios';
import React, { useState } from 'react';
import { useEffect } from 'react';
import { useContext } from 'react';
import { Link } from 'react-router-dom';
import { UserContext } from '../../App';
import { _sum } from '../../helpers';
import '../Form.scss'
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const DGLResult = () => {

    const [dglInfo, setDglInfo] = useState({});
    const [loggedInUser,setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true); 
    const [findInfo, setFindInfo] = useState({});
    const [branch, setBranch] = useState([]);
    const [dglData, setDglData] = useState([]);
    const [isStore, setIsStore] = useState(false);
    const [openTable, setOpenTable] = useState(false);
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [dglResultObj, setDglResultObj]  = useState({
        dgl_employee_total:0,
        total:0
    });
    const [accountInfo, setAccountInfo] = useState([]);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })
    const [dglTotal, setDglTotal]  = useState({
        debt_daily:0,
        debt_monthly:0,
        debt_weekly:0,
        total_debt_recovery:0,
        saving_weekly:0,
        saving__monthly:0,
        savings_current:0,
        
    })
    const handleBlur = (e) => { 
        const newInfo = {...dglInfo};
        newInfo[e.target.name]=e.target.value;
        setDglInfo(newInfo)    
    };

    if(loggedInUser.isLoggedIn){
            dglInfo.branch_code= loggedInUser.branch_code;
    }
    if(dglData.length){  

            let collectionSum = 0;
            let minimizeSum = 0;

            dglData.map(info => {
            
             collectionSum += _sum(info.debt_weekly, info.debt_daily, info.debt_monthly, info.debt_term, info.saving_weekly, info.saving__monthly, info.savings_current, info.admission_fee, info.loan_fees, info.insurance, info.form_fee,  info.miscellaneous)
              
             minimizeSum += _sum(info.weekly  ,info.monthly  ,info.current  ,info.profit_withdrawal, info.w_debt_provide  ,info.d_debt_provide  ,info.m_debt_provide  ,info.sm_debt_provide)
            
            })      
            console.log(minimizeSum);
            dglInfo.dgl_employee_total= collectionSum - minimizeSum;  
            dglResultObj.dgl_employee_total=collectionSum - minimizeSum;
    }else{
        dglInfo.dgl_employee_total=0;
        dglResultObj.dgl_employee_total=0;
    } 
    {/*profit_withdrawal,  korjoprodan, pedices, total */}
    if(dglInfo.profit_withdrawal && dglInfo.dgl_employee_total && dglInfo.korjoprodan && dglInfo.pedices){
        let result= (Number(dglInfo.profit_withdrawal)+Number(dglInfo.dgl_employee_total)) - (Number(dglInfo.korjoprodan)+Number(dglInfo.pedices));
        dglResultObj.total=result;
        dglInfo.total= result;
    }else{
        dglResultObj.total=0;
        dglInfo.total= 0;
    }
 



    let dbYear = new Date().getFullYear().toString();
    let dbMonth =new Date().getMonth()+1;
    let dbDay =  new Date().getDate().toString();

    dglInfo.day=dbDay;
    dglInfo.month=dbMonth.toString();
    dglInfo.year=dbYear;
    dglInfo.date=`${dbMonth}/${dbDay}/${dbYear}`;

    const handleFindBlur = (e) => {
            let newInfo = {...findInfo};
            newInfo[e.target.name]  = e.target.value;
            setFindInfo(newInfo); 
    }
 

    const handleFindBlurGet = (e) => {
            e.preventDefault();

            let newInfo = {...ServerResult};
            newInfo.loaderShow=true;
            setServerResult(newInfo)

            axios.get('https://www.md-sohidul-islam.com/getdglbydateandcode',{
                    params:{
                            date:findInfo.date,
                            code:findInfo.branch_code, 
                    }
            }).then(response => {  
                
                console.log(response)

                setTimeout(() => { 
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully data loaded';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);  
                            setClear(true)
                            setIsStore(true);
                            setDglData(response.data.successResult);
                        }, 3000); 
                }, 3000);
            
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage='Internal server error' 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
    }


    useEffect(()=>{ 

        axios.get('https://www.md-sohidul-islam.com/getalldata',{
            params:{
                code:']42T3a2cP&p?m3Fg',
                database:'contactinfo'
            }
        })
        .then(res => {  
                        setBranch(res.data.successResult);  

        }).catch(error => {  
            
            //console.log(error.message);

        })
    },[])

    const handleDglResult = (e) => { 

        e.preventDefault()
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)


        axios.post('https://www.md-sohidul-islam.com/dglresult', {
                info: dglInfo
    }).then(response => {  
        
        setTimeout(() => {   

            setIsStore(false)
            setClear(false);
            setDglInfo({});
            setDglResultObj({});

            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo); 
                    setClear(true)
                }, 3000); 
        }, 3000);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    
        
    }
    

    useEffect(()=>{
        axios.get('https://www.md-sohidul-islam.com/getallonebranchdglresult',{
            params:{
                code: loggedInUser.branch_code
            }
       })
       .then(res => {     
           //console.log(res);
           setAccountInfo(res.data.successResult);
           
       })
       .catch(error => {  
           alert(error.message)
       })
    },[]) 
    /// dgl employee total and korjo grohon jog hobe and korjo prodan and dedicesh jog hoye purber dui field er sathe minush

    const handleDeleteAccess = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    const handleDelete = () =>  {

        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);


        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'dglresult'
            }
        })
        .then(res => {  

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  

            
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    let count = 0;

    return (
        <div> 

{deleteState? 
        <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}


            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}

                <div className='form__container text-white'>
                        <p className='text-center'><b>Name</b>: {loggedInUser.first_name} <b>Email</b>: {loggedInUser.second_email} <b>শাখা কোড </b>: {loggedInUser.branch_code}</p>
                        {isStore?  
                        <div className='text-center'> 
                        <form className='my-4' onSubmit={handleDglResult}>  
                                {dglResultObj.dgl_employee_total? 
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="DGL employee total"
                                        name='dgl_employee_total'
                                        required
                                        type="number"
                                        defaultValue={dglResultObj.dgl_employee_total}
                                />:""}
                                <input 
                                        className='input'
                                        onBlur={handleBlur}
                                        placeholder="কর্জ  গ্রহণ" 
                                        name='profit_withdrawal'
                                        required
                                        type="number"
                                />  
                                
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="কর্জ প্রদান" //minush value
                                        name='korjoprodan'
                                        required
                                        type="number"
                                />  
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="পেডিকেস"//minush value 
                                        name='pedices'
                                        required
                                        type="number"
                                />
                                {dglResultObj.total? 
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="মোট"//minush value 
                                        name='total'
                                        required
                                        type="number"
                                        defaultValue={dglResultObj.total}
                                />:""}
                                <input type="submit" value="submit" className='submit__button' />
                       </form> </div>:
                       <form onSubmit={handleFindBlurGet}>
                    {branch.length? 
                    <select onBlur={handleFindBlur} name="branch_code" className='input' required>
                        <option>শাখা কোড</option> 
                        {branch.map(info => {
                            return <option key={info.id_find} value={`${info.branch_code}`}>{info.branch_code}</option>;
                        })} 
                    </select>:""}
                                <input 
                                        className='input'
                                        type='date'
                                        onBlur={handleFindBlur}
                                        placeholder="তারিখ"
                                        name='date'
                                        required 
                                />  
                                <input type="submit" value="FIND" className='submit__button' />
                       </form>}
                       <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>
                </div>
                {openTable? 
                <table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                             ["তারিখ ","DGL employee total","কর্জ  গ্রহণ","কর্জ প্রদান","পেডিকেস","মোট","শাখা কোড " ].map(data => {
                                return(<td key={count++}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                //console.log(info);
                                return(<tr key={info.id_find} id={`${info.id_find}`}> 
                                        <td>{info.date}</td> 
                                        <td>{info.dgl_employee_total}</td>  
                                        <td>{info.profit_withdrawal}</td>  
                                        <td>{info.korjoprodan}</td>  
                                        <td>{info.pedices}</td>  
                                        <td>{info.total}</td>   
                                        <td>{info.branch_code}</td>    
                                        {loggedInUser.admin_level==='01'?<span><button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button><Link to={`/dglresultupdate/${info.id_find}`}><button className='btn btn-warning btn-sm mr-1'>UPDATE</button></Link></span>:""}  
                                        
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}

        </div>
        
    );
};

export default DGLResult;