import axios from 'axios';
import React from 'react';
import { useContext } from 'react';
import { useState } from 'react';
import { UserContext } from '../../App';
import '../Form.scss'


const CheckPassbook = () => {

    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [accountInfo, setAccountInfo] = useState([]);
    const [memberInfo, setMemberInfo] = useState({});
    const [newAddInfo, setNewAddInfo] = useState({});
    const [haveMember, setHaveMember] = useState(false);
    const [haveAccount, setHaveAccount] = useState(false);

    // document.title = 'পাসবই যাচাই'


    const handleBlur = (e) => {
        const newInfo = {...newAddInfo};
        newInfo[e.target.name] = e.target.value;
        setNewAddInfo(newInfo);
    }
    
    
    const handleFind = (e) => {
        e.preventDefault();
        axios.get('https://www.md-sohidul-islam.com/getmember',{
            params:{
                name: newAddInfo.hisabNumber
            }
        })
        .then(res => {     
            let result = res.data.successResult; 
            let resultLength = res.data.successResult.length;   
            if(resultLength){
                setMemberInfo(result[resultLength-1])
                setHaveMember(true); 
            }else{
                alert('NO RECORD IN OUR DATABASE')
            }
            
 

        }).catch(error => { 
            let newLoggedInUserInfo = {...loggedInUser};
            newLoggedInUserInfo.bg='red';
            newLoggedInUserInfo.show='flex';
            newLoggedInUserInfo.err= true;
            newLoggedInUserInfo.message=error.message;
            setLoggedInUser(newLoggedInUserInfo); 
        });

    } 

    const handleShowDetails = () => {
        axios.get('https://www.md-sohidul-islam.com/getaccount',{
            params:{
                name: memberInfo.hisabNumber,
                type: memberInfo.how_much_to_borrow
            }
        })
        .then(res => { 
            if(res.data.successResult.length){
                setAccountInfo(res.data.successResult); 
                setHaveAccount(true);
            }else{
                alert('empty passbook')
            }
             
            
        }).catch(error => {
            let newLoggedInUserInfo = {...loggedInUser};
            newLoggedInUserInfo.bg='red';
            newLoggedInUserInfo.show='flex';
            newLoggedInUserInfo.err= true;
            newLoggedInUserInfo.message=error.message;
            setLoggedInUser(newLoggedInUserInfo); 
        });
    }


    return (
        <div className='form__container' style={{backgroundColor:'#015E31'}}> 
            <form onSubmit={handleFind}> 
                <input onBlur={handleBlur} type="number" placeholder='Account number' name="hisabNumber" className='input' id="id" />
                <input type='submit' className='submit__button text-center' value="CHECK" />
            </form> 
            
            {haveMember? 

            <div className='container my-5 text-center'>
                <p className='text-white'><b>Name</b> : {memberInfo.nam}</p>
                <p className='text-white'><b>Address</b> : {memberInfo.thikana}</p>
                <p className='text-white'><b>Account No</b> : {memberInfo.hisabNumber}</p>
                <button className='btn btn-outline-info' onClick={handleShowDetails}>SHOW PASSBOOK</button>
            </div>

            :""}
            
            {haveAccount? 
            <table className='table table-dark my-5' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                            ['তারিখ','সঞ্চয় জমা',  'সঞ্চয় উত্তলন', 'সঞ্চয় স্থিতি', 'কিস্তি সংখ্যা', 'ঋণ আদায়', 'ঋণের স্থিতি', 'আদায়কারীর নাম'].map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.date}</td>
                                        <td>{info.save_deposit}</td>
                                        <td>{info.save_withdraw}</td>
                                        <td>{info.save_total}</td>
                                        <td>{info.installment_count}</td>
                                        <td>{info.debt_collection}</td>
                                        <td>{info.debt_total}</td>
                                        <td>{info.signature}</td>  
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}
        </div>
    );
};

export default CheckPassbook;