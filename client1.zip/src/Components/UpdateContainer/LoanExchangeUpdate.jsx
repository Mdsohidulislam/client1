import { TextField } from '@material-ui/core';
import axios from 'axios';
import React from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';    
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './UpdateForm.scss'

const DglUpdate = () => {
    const id = useParams().id;
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [oldInfo, setOldInfo] = useState({}); 


    const history = useHistory();

    const handleBlur = (e) => {

         oldInfo[e.target.name] = e.target.value;  
    }
     
    
    // https://www.md-sohidul-islam.com/getdglbyid/:id
    const handleloanexchange = (e) => {
        e.preventDefault(); 
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.patch('https://www.md-sohidul-islam.com/updateloanexchange',{
            updateInfo:oldInfo,
        })
        .then(res => {    
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully dgl data updated';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        history.replace('/loanexchange');
                    }, 800); 
            }, 800);

        }).catch(error => {  
            ////console.log(error.message);
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
        
    }

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get(`https://www.md-sohidul-islam.com/getloanexchangebyid/${id}`)
        .then(res => {      
            setOldInfo(res.data.successResult[0]);  
                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully dgl data loaded';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);   
                        }, 800); 
                }, 800);
    
            }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message; 
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                }) 
    },[])

    return (
        <div className='container py-5 update__form__container'> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
            {oldInfo.w_lending? 
            <form  onSubmit={handleloanexchange}>  
                    

                                                <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w ঋণ প্রদান"
                            type='number'
                            name='w_lending'
                            required   defaultValue={oldInfo.w_lending}  

                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w মোট ঋণ প্রদান"
                            type='number'
                            name='w_total_lending' 
                            required   defaultValue={oldInfo.w_total_lending}
                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w সার্ভিস চার্জ "
                            type='number'
                            name='w_service_charge'
                            required   defaultValue={oldInfo.w_service_charge}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w মোট সার্ভিস চার্জ "
                            type='number'
                            name='w_total_service_charge' 
                            required   defaultValue={oldInfo.w_total_service_charge}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w ঋণ আদায়"
                            type='number'
                            name='w_debt_collection'
                            required   defaultValue={oldInfo.w_debt_collection}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w মোট ঋণ আদায় "
                            type='number'
                            name='w_total_debt_collection' 
                            required   defaultValue={oldInfo.w_total_debt_collection}

                            /> 

                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="w মোট ঋণ স্থিতি"
                            type='number'
                            name='w_total_debt_status' 
                            required   defaultValue={oldInfo.w_total_debt_status} 
                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D ঋণ প্রদান"
                            type='number'
                            name='d_lending'
                            required   defaultValue={oldInfo.d_lending}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D মোট ঋণ প্রদান"
                            type='number'
                            name='d_total_loan_disbursement' 
                            required   defaultValue={oldInfo.d_total_loan_disbursement}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D সার্ভিস চার্জ "
                            type='number'
                            name='d_service_charge'
                            required   defaultValue={oldInfo.d_service_charge}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D মোট সার্ভিস চার্জ "
                            type='number'
                            name='d_total_service_charge' 
                            required   defaultValue={oldInfo.d_total_service_charge}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D ঋণ আদায়"
                            type='number'
                            name='d_debt_collection'
                            required   defaultValue={oldInfo.d_debt_collection}

                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D মোট ঋণ আদায়"
                            type='number'
                            name='d_total_debt_collection' 
                            required   defaultValue={oldInfo.d_total_debt_collection}

                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="D মোট ঋণ স্থিতি"
                            type='number'
                            name='d_total_debt_status'
                            required   defaultValue={oldInfo.d_total_debt_status} 
                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M ঋণ প্রদান"
                            type='number'
                            name='m_lending'
                            required   defaultValue={oldInfo.m_lending}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M মোট  ঋণ প্রদান"
                            type='number'
                            name='m_total_loan_disbursement'
                            required   defaultValue={oldInfo.m_total_loan_disbursement}  
                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M  সার্ভিস চার্জ"
                            type='number'
                            name='m_service_charge'
                            required   defaultValue={oldInfo.m_service_charge}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M মোট সার্ভিস চার্জ "
                            type='number'
                            name='m_total_service_charge'
                            required   defaultValue={oldInfo.m_total_service_charge} 

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M ঋণ আদায় "
                            type='number'
                            name='m_debt_collection'
                            required   defaultValue={oldInfo.m_debt_collection}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M মোট ঋণ আদায়"
                            type='number'
                            name='m_total_debt_collection'
                            required   defaultValue={oldInfo.m_total_debt_collection} 

                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="M মোট ঋণ স্থিতি"
                            type='number'
                            name='m_total_debt_status'
                            required   defaultValue={oldInfo.m_total_debt_status}  
                            />
                                        <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM ঋণ প্রদান"
                            type='number'
                            name='sm_lending'
                            required   defaultValue={oldInfo.sm_lending}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM মোট  ঋণ প্রদান"
                            type='number'
                            name='sm_total_loan_disbursement'
                            required   defaultValue={oldInfo.sm_total_loan_disbursement} 

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM সার্ভিস চার্জ "
                            type='number'
                            name='sm_service_charge'
                            required   defaultValue={oldInfo.sm_service_charge}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM মোট সার্ভিস চার্জ"
                            type='number'
                            name='sm_total_service_charge'
                            required   defaultValue={oldInfo.sm_total_service_charge} 
                            />  

                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM ঋণ আদায়"
                            type='number'
                            name='sm_debt_collection'
                            required   defaultValue={oldInfo.sm_debt_collection}

                            />  
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM মোট ঋণ আদায় "
                            type='number'
                            name='sm_total_debt_collection'
                            required   defaultValue={oldInfo.sm_total_debt_collection} 
                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="SM মোট ঋণ স্থিতি "
                            type='number'
                            name='sm_total_debt_status'
                            required   defaultValue={oldInfo.sm_total_debt_status} 
                            />   
                            <TextField
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মোট ঋণ স্থিতি "
                            type='number'
                            name='total_debt_status'
                            required   defaultValue={oldInfo.total_debt_status} 
                            />



                    <input type="submit" value="UPDATE" className='submit__button' />
                    </form>:""}
            <Link to='/loanexchange'>Go back loan exchange</Link>
        </div>
    );
};

export default DglUpdate;
 

 

 


