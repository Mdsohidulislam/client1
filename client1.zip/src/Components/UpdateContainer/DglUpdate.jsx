import { TextField } from '@material-ui/core';
import axios from 'axios';
import React from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';    
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './UpdateForm.scss'

const DglUpdate = () => {
    const id = useParams().id;
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [oldInfo, setOldInfo] = useState({}); 


    const history = useHistory();

    const handleBlur = (e) => {

         oldInfo[e.target.name] = e.target.value;  
    }
     
    
    // https://www.md-sohidul-islam.com/getdglbyid/:id
    const handleDglUpdate = (e) => {
        e.preventDefault(); 
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.patch('https://www.md-sohidul-islam.com/updatedgl',{
            updateInfo:oldInfo,
        })
        .then(res => {    
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully dgl data updated';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        history.replace('/dgl');
                    }, 800); 
            }, 800);

        }).catch(error => {  
            ////console.log(error.message);
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
        
    }

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get(`https://www.md-sohidul-islam.com/getdglbyid/${id}`,{
            params:{
                code:'qh{7HTEAU;?W]]Pk'
            }
        })
        .then(res => {      
            setOldInfo(res.data.successResult[0]); 
                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully dgl data loaded';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);   
                        }, 800); 
                }, 800);
    
            }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message; 
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                }) 
    },[])

    return (
        <div className='container py-5 update__form__container'> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
            {oldInfo.name_of_the_employee? 
            <form  onSubmit={handleDglUpdate}>  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="শাখা কোড"
                        name='branch_code'
                        required
                        type="text"
                        defaultValue={oldInfo.branch_code}
                    />
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="কর্মীর কোড"
                        name='name_of_the_employee'
                        required
                        type="text"
                        defaultValue={oldInfo.name_of_the_employee}
                    /> 

                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="শীট নং"
                        name='sheet_no'
                        required
                        type="number"
                        defaultValue={oldInfo.sheet_no}

                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="সদস্য সংখ্যা"
                        name='number_of_members'
                        required
                        type="number"
                        defaultValue={oldInfo.number_of_members}

                    /> 
                    <span className='both_clear'> <b>ঋণ আদায়</b> <br />

                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="সাপ্তাহিক"
                            name='debt_weekly'
                            required
                            type="number"
                        defaultValue={oldInfo.debt_weekly}

                        />  
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="দৈনিক"
                            name='debt_daily'
                            required
                            type="number"
                        defaultValue={oldInfo.debt_daily}

                        />   
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মাসিক"
                            name='debt_monthly'
                            required
                            type="number"
                            defaultValue={oldInfo.debt_monthly}
                        />  
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মেয়াদি"
                            name='debt_term'
                            required
                            type="number"
                            defaultValue={oldInfo.debt_term}

                        />   
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মোট ঋণ আদায়"
                            name='total_debt_recovery' 
                            required
                            type="number"
                            defaultValue={oldInfo.total_debt_recovery}
                        /> 
                    </span> 
                    <span className='both_clear mb-1'> <b>সঞ্চয় আদায়</b> <br />

                    
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="সাপ্তাহিক"
                            name='saving_weekly'
                            required
                            type="number"
                            defaultValue={oldInfo.saving_weekly}
                        />  
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মাসিক"
                            name='saving__monthly'
                            required
                            type="number"
                            defaultValue={oldInfo.saving__monthly}
                        />  
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="চলতি"
                            name='savings_current'
                            required
                            type="number"
                            defaultValue={oldInfo.savings_current}
                        />    
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মোট সঞ্চয় আদায়"
                            name='collection_of_total_savings'
                            required 
                            type="number"
                            defaultValue={oldInfo.collection_of_total_savings}
                        /> 
                    </span>
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="ভর্তি ফি"
                        name='admission_fee'
                        required
                        type="number"
                        defaultValue={oldInfo.admission_fee}
                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="ঋণ ফি"
                        name='loan_fees'
                        required
                        type="number"
                        defaultValue={oldInfo.loan_fees}
                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="বীমা"
                        name='insurance'
                        required
                        type="number"
                        defaultValue={oldInfo.insurance}
                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="ফরম ফি"
                        name='form_fee'
                        required
                        type="number"
                        defaultValue={oldInfo.form_fee}
                    />  
                    
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="বিবিধ"
                        name='miscellaneous'
                        required
                        type="number"
                        defaultValue={oldInfo.miscellaneous}
                    />   
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="মোট আদায়"
                        name='total_realization'
                        required 
                        type="number"
                        defaultValue={oldInfo.total_realization}
                    />    

                    <span className='both_clear'> <b>সঞ্চয় উত্তোলন</b> <br />
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="সাপ্তাহিক"
                            name='weekly'
                            required
                            type="number"
                            defaultValue={oldInfo.weekly}
                        />  
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মাসিক"
                            name='monthly'
                            required
                            type="number"
                            defaultValue={oldInfo.monthly}
                        />  
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="চলতি"
                            name='current'
                            required
                            type="number"
                            defaultValue={oldInfo.current}
                        />   
                        <TextField 
                            className='textfield__input'
                            onBlur={handleBlur}
                            label="মোট সঞ্চয় উত্তোলন"
                            name='total_savings_withdrawal'
                            required 
                            type="number"
                            defaultValue={oldInfo.total_savings_withdrawal}
                        /> 
                    </span>

                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="লাভ উত্তোলন"
                        name='profit_withdrawal'
                        required
                        type="number"
                        defaultValue={oldInfo.profit_withdrawal}
                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="সাক্ষর"
                        name='signature'
                        required
                        type="text"
                        defaultValue={oldInfo.signature}
                    />
                    <span className='both_clear'> <b>ঋণ প্রদান</b> <br />
                    
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="w ঋণ  প্রদান"
                        name='w_debt_provide'
                        required
                        type="number"
                        defaultValue={oldInfo.w_debt_provide}
                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="d ঋণ  প্রদান"
                        name='d_debt_provide'
                        required
                        type="number"
                        defaultValue={oldInfo.d_debt_provide}
                    />  
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="m ঋণ  প্রদান"
                        name='m_debt_provide'
                        required
                        type="number"
                        defaultValue={oldInfo.m_debt_provide}
                    />  
                    
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="sm ঋণ  প্রদান"
                        name='sm_debt_provide'
                        required
                        type="number"
                        defaultValue={oldInfo.sm_debt_provide}
                    />   
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="মোট ঋণ  প্রদান"
                        name='total_debt_provide'
                        required
                        type="number" 
                        defaultValue={oldInfo.total_debt_provide}
                    /> 
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="মোট স্থিতি"
                        name='total_status'
                        required
                        type="number" 
                        defaultValue={oldInfo.total_status}
                    />  
                    </span>        
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="আদায়যোগ্য "
                        name='recoverable'
                        required
                        type="number" 
                        defaultValue={oldInfo.recoverable}
                    />
                    <TextField 
                        className='textfield__input'
                        onBlur={handleBlur}
                        label="আদায় "
                        name='realization'
                        required
                        type="number" 
                        defaultValue={oldInfo.realization} 
                    /> 
                    <input type="submit" value="UPDATE" className='submit__button' />
                    </form>:""}
            <Link to='/dgl'><button className="btn btn-outline-warning">GO BACK DGL</button></Link>
        </div>
    );
};

export default DglUpdate;