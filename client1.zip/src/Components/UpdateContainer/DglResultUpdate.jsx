import { TextField } from '@material-ui/core';
import axios from 'axios';
import React, { useEffect } from 'react';
import { useState } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const DglResultUpdate = () => {
    const id = useParams().id; 
    const [oldInfo, setOldInfo] = useState({});
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [updateInfo, setUpdateInfo] = useState({});

    const handleBlur  = (e) => { 
        oldInfo[e.target.name] = e.target.value; 
    } 

    const history = useHistory();

    const handleDglResultUpdate   = (e) => {
        e.preventDefault();  
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.patch('https://www.md-sohidul-islam.com/updatedglresult',{
            updateInfo:oldInfo,
        })
        .then(res => {   

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully dgl data updated';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        history.replace('/dglresults');
                    }, 800); 
            }, 800);

        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
        


    }


    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get(`https://www.md-sohidul-islam.com/getdglresultbyid/${id}`)
        .then(res => {   
            setOldInfo(res.data.successResult[0]);
            ////console.log(res);
                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully dgl data loaded';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);   
                        }, 800); 
                }, 800);
    
            }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message; 
                        ////console.log(updateInfo);
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                }) 
    },[]) 
     
      

    return (
        <div className='container-fluid py-5 update__form__container'> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
            msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
            msg={ServerResult.faildMesssage}/> : ""}
            
            {oldInfo.dgl_employee_total? 
            <form onSubmit={handleDglResultUpdate}>   

                                <TextField 
                                        className='textfield__input' 
                                        onBlur={handleBlur}
                                        label="DGL employee total"
                                        name='date'
                                        required  
                                        type="number" 
                                /> 
                                <TextField 
                                        className='textfield__input' 
                                        onBlur={handleBlur}
                                        label="DGL employee total"
                                        name='dgl_employee_total'
                                        required 
                                        defaultValue={oldInfo.dgl_employee_total}
                                        type="number" 
                                /> 
                                <TextField 
                                        className='textfield__input'
                                        onBlur={handleBlur}
                                        label="কর্জ  গ্রহণ" 
                                        name='profit_withdrawal'
                                        required
                                        defaultValue={oldInfo.profit_withdrawal}
                                        type="number"
                                />  
                                
                                <TextField 
                                        className='textfield__input' 
                                        onBlur={handleBlur}
                                        label="কর্জ প্রদান" //minush value
                                        name='korjoprodan'
                                        required
                                        type="number"
                                        defaultValue={oldInfo.korjoprodan}
                                />  
                                <TextField 
                                        className='textfield__input' 
                                        onBlur={handleBlur}
                                        label="পেডিকেস"//minush value 
                                        name='pedices'
                                        required
                                        defaultValue={oldInfo.pedices}
                                        type="number"
                                />
                                <TextField 
                                        className='textfield__input' 
                                        onBlur={handleBlur}
                                        label="মোট"//minush value 
                                        name='total'
                                        required
                                        defaultValue={oldInfo.total}
                                        type="number" 
                                /> 
                                <TextField 
                                    className='textfield__input'
                                    onBlur={handleBlur}
                                    label="শাখা কোড"
                                    name='branch_code'
                                    required
                                    type="text"
                                    defaultValue={oldInfo.branch_code}
                                />
                    <input type="submit" value="submit" className='submit__button' />
            </form> :""}
            <Link to='/dglresults'><button className='btn my-2 btn-outline-warning'>GO BACK DGL RESULT</button></Link>
             
            
        </div>
    );
};

export default DglResultUpdate;

 