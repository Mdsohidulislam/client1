import { TextField } from '@material-ui/core';
import axios from 'axios';
import React from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';    
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './UpdateForm.scss'

const DglUpdate = () => {
    const id = useParams().id;
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [oldInfo, setOldInfo] = useState({}); 


    const history = useHistory();

    const handleBlur = (e) => {

         oldInfo[e.target.name] = e.target.value;  
    }
     
    
    // https://www.md-sohidul-islam.com/getdglbyid/:id
    const handleglUpdate = (e) => {
        e.preventDefault(); 
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.patch('https://www.md-sohidul-islam.com/updategl',{
            updateInfo:oldInfo,
        })
        .then(res => {    
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully dgl data updated';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        history.replace('/gl');
                    }, 800); 
            }, 800);

        }).catch(error => {  
            ////console.log(error.message);
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
        
    }

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get(`https://www.md-sohidul-islam.com/getglbyid/${id}`)
        .then(res => {      
            setOldInfo(res.data.successResult[0]); 
                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully dgl data loaded';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);   
                        }, 800); 
                }, 800);
    
            }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message; 
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                }) 
    },[])

    return (
        <div className='container py-5 update__form__container'> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
            {oldInfo.gl_deposit? 
            <form  onSubmit={handleglUpdate}>  
                    
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="সাপ্তাহিক জমা" 
                name='gl_deposit'
                required defaultValue={oldInfo.gl_deposit}  
            />  
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="সাপ্তাহিক মোট জমা" 
                name='gl_weekly_total_deposit'
                required defaultValue={oldInfo.gl_weekly_total_deposit}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="সাপ্তাতিক উত্তোলন" 
                name='gl_weekly_withdrawal'
                required defaultValue={oldInfo.gl_weekly_withdrawal}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="সাপ্তাহিক মোট উত্তোলন" 
                name='gl_weekly_total_withdrawal'
                required defaultValue={oldInfo.gl_weekly_total_withdrawal}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="সাপ্তাহিক স্থিতি" 
                name='gl_weekly_status'
                required defaultValue={oldInfo.gl_weekly_status}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মাসিক জমা" 
                name='gl_monthly_deposit'
                required defaultValue={oldInfo.gl_monthly_deposit}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মাসিক মোট জমা" 
                name='gl_monthly_total_deposit'
                required defaultValue={oldInfo.gl_monthly_total_deposit}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মাসিক উত্তোলন" 
                name='gl_monthly_withdrawal'
                required defaultValue={oldInfo.gl_monthly_withdrawal}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মাসিক মোট  উত্তোলন" 
                name='gl_monthly_total_withdrawal'
                required defaultValue={oldInfo.gl_monthly_total_withdrawal}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মাসিক স্থিতি" 
                name='gl_monthly_status'
                required defaultValue={oldInfo.gl_monthly_status}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="FD জমা" 
                name='gl_fd_deposit'
                required defaultValue={oldInfo.gl_fd_deposit}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="FD মোট জমা" 
                name='gl_fd_total_deposit'
                required defaultValue={oldInfo.gl_fd_total_deposit}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="FD উত্তোলন" 
                name='gl_fd_withdrawal'
                required defaultValue={oldInfo.gl_fd_withdrawal}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="FD মোট উত্তোলন" 
                name='gl_fd_total_withdrawal'
                required defaultValue={oldInfo.gl_fd_total_withdrawal}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="FD স্থিতি" 
                name='gl_fd_status'
                required defaultValue={oldInfo.gl_fd_status}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মোট জমা স্থিতি" 
                name='gl_total_savings_status'
                required defaultValue={oldInfo.gl_total_savings_status}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মোট উত্তোলন স্থিতি" 
                name='gl_total_withdrawal_status'
                required defaultValue={oldInfo.gl_total_withdrawal_status}  
            />
            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='number'
                label="মোট স্থিতি" 
                name='gl_total_status'
                required defaultValue={oldInfo.gl_total_status}  
            />             



            <TextField
            className='textfield__input'
                onBlur={handleBlur}
                type='text'
                label="সাক্ষর" 
                name='gl_signature'
                required defaultValue={oldInfo.gl_signature}  
            /> 


                    <input type="submit" value="UPDATE" className='submit__button' />
                    </form>:""}
            <Link to='/gl'><button className='btn btn-outline-warning'>GO BACK GL</button></Link>
        </div>
    );
};

export default DglUpdate;
 

// <form onSubmit={handleGlUpdate}>    


// <input type="submit" value="submit" className='submit__button' />
// </form> :""}