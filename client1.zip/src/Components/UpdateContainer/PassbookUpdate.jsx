import { TextField } from '@material-ui/core';
import axios from 'axios';
import React from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';    
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './UpdateForm.scss'

const DglUpdate = () => {
    const id = useParams().id;
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [oldInfo, setOldInfo] = useState({}); 


    const history = useHistory();

    const handleBlur = (e) => {

         oldInfo[e.target.name] = e.target.value;  
    }
     
     
    const handlePassbookUpdate = (e) => {
        e.preventDefault(); 
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.patch('https://www.md-sohidul-islam.com/updatepassbook',{
            updateInfo:oldInfo,
        })
        .then(res => {    
            ////console.log(res);
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully dgl data updated';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        history.replace('/passbook');
                    }, 800); 
            }, 800);

        }).catch(error => {  
            ////console.log(error.message);
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
        
    }

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get(`https://www.md-sohidul-islam.com/getpasssbookbyid/${id}`)
        .then(res => {      
            setOldInfo(res.data.successResult[0]);  
                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully dgl data loaded';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);   
                        }, 800); 
                }, 800);
    
            }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message; 
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                }) 
    },[])

    return (
        <div className='container-fluid py-5 update__form__container'> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
            {oldInfo.save_deposit? 
            <form  onSubmit={handlePassbookUpdate}>  
                    


                    <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='save_deposit' 
                            className='textfield__input' 
                            label='সঞ্চয় জমা' 
                            required defaultValue={oldInfo.save_deposit} 
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='save_withdraw' 
                            className='textfield__input' 
                            label='সঞ্চয় উত্তলন' 
                            required defaultValue={oldInfo.save_withdraw}
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='save_total' 
                            className='textfield__input' 
                            label='সঞ্চয় স্থিতি'
                            required defaultValue={oldInfo.save_total}
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='installment_count' 
                            className='textfield__input' 
                            label='কিস্তি সংখ্যা' 
                            required defaultValue={oldInfo.installment_count}
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='debt_collection' 
                            className='textfield__input' 
                            label='ঋণ আদায়' 
                            required defaultValue={oldInfo.debt_collection}
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='debt_total' 
                            className='textfield__input' 
                            label='ঋণের স্থিতি' 
                            required defaultValue={oldInfo.debt_total}
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="number" 
                            name='area_code' 
                            className='textfield__input' 
                            label='কর্ম এলাকার কোড' 
                            required defaultValue={oldInfo.area_code}
                        /> 
                        <TextField
                            onBlur={handleBlur} 
                            type="text" 
                            name='signature' 
                            className='textfield__input' 
                            label='আদায়কারীর নাম' 
                            required defaultValue={oldInfo.signature}
                        />



                    <input type="submit" value="UPDATE" className='submit__button' />
                    </form>:""}
            <Link to='/passbook'><button className='btn btn-outline-warning'>GO BACK PASSBOOK</button></Link>
        </div>
    );
};

export default DglUpdate;
 

 

 







// <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='save_deposit' 
//                             className='textfield__input' 
//                             label='সঞ্চয় জমা' 
//                             required defaultValue={oldInfo.save_deposit} 
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='save_withdraw' 
//                             className='textfield__input' 
//                             label='সঞ্চয় উত্তলন' 
//                             required defaultValue={oldInfo.save_withdraw}
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='save_total' 
//                             className='textfield__input' 
//                             label='সঞ্চয় স্থিতি'
//                             required defaultValue={oldInfo.save_total}
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='installment_count' 
//                             className='textfield__input' 
//                             label='কিস্তি সংখ্যা' 
//                             required defaultValue={oldInfo.installment_count}
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='debt_collection' 
//                             className='textfield__input' 
//                             label='ঋণ আদায়' 
//                             required defaultValue={oldInfo.debt_collection}
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='debt_total' 
//                             className='textfield__input' 
//                             label='ঋণের স্থিতি' 
//                             required defaultValue={oldInfo.debt_total}
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="number" 
//                             name='area_code' 
//                             className='textfield__input' 
//                             label='কর্ম এলাকার কোড' 
//                             required defaultValue={oldInfo.area_code}
//                         /> 
//                         <TextField
//                             onBlur={handleBlur} 
//                             type="text" 
//                             name='signature' 
//                             className='textfield__input' 
//                             label='আদায়কারীর নাম' 
//                             required defaultValue={oldInfo.signature}
//                         />