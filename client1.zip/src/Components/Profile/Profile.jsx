import { IconButton } from '@material-ui/core';
import { PhotoCamera } from '@material-ui/icons';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useContext } from 'react'; 
import { UserContext } from '../../App'; 
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './Profile.scss'


const Profile = () => { 
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [messages, setMessages] = useState([]); 

    const [open, setOpen] = useState(false);
    const [file, setFile] = useState(null); 

    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });


    useEffect(()=>{

        axios.get('https://www.md-sohidul-islam.com/loginN',{
            params:{
                email: loggedInUser.second_email,
                password: loggedInUser.fourth_securityy,
                code:']42T3a2cP&p?m3Fg'
            }
        }).then(response => { 
                let  bsblMemberInfo = response.data.successResult; 
                bsblMemberInfo.isLoggedIn = true;
                setLoggedInUser(bsblMemberInfo) 

                let newInfo = {...ServerResult};
                newInfo.loaderShow=true;
                setServerResult(newInfo);
                //console.log(response)

                axios.get('https://www.md-sohidul-islam.com/getalldata',{
                    params:{
                        code:']42T3a2cP&p?m3Fg',
                        database:'message'
                    }
                })
                .then(res => {  
            
                    
                    setTimeout(() => {     
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=true;
                        newInfo.successMessage='Successfully data loaded';
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult}; 
                                newInfo.successShow=false;
                                setServerResult(newInfo);  
                                let newLoggedInInfo = {...loggedInUser};
                                newLoggedInInfo.noticeLength=res.data.successResult.length;
                                setLoggedInUser(newLoggedInInfo);
            
                                setMessages(res.data.successResult);
                            }, 800); 
                    }, 800);
            
            
                }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message; 
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                })


        }).catch(error => {
            //console.log(error.message);
        })

    },[])


 
 
    const handleFileChange = e => {
        setFile(e.target.files[0]);
        
    }
    

    const handleFileSubmit = e => {
        e.preventDefault();
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        let formData = new FormData();

        formData.append('file', file);
        formData.append('id_find', loggedInUser.id_find);
        formData.append('email',loggedInUser.second_email)
        formData.append('prev__img__url',loggedInUser.img__url)

        axios.post('https://www.md-sohidul-islam.com/postimage',formData,{
            headers: {
                "Content-Type": "multipart/form-data",
              }
        }).then(res => {  
            

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully image uploaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        let newInfoo = {...loggedInUser}; 
                        newInfo.img__url = res.data.img__url;
                        setLoggedInUser(newInfoo)
                        setOpen(!open)
                    }, 800); 
            }, 800);
 
        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);


        })

    } 

    //console.log(loggedInUser)

    return ( 
    

    <div className='profile__container'> 

        {ServerResult.loaderShow? <Loader/>:""}
        {ServerResult.successShow? <SuccessResult
        msg={ServerResult.successMessage}/>:""}
        {ServerResult.faildShow? <FaildResult
        msg={ServerResult.faildMesssage}/> : ""}

            <div className="profile__gradient__container">
                <div className="profile__main__container">
                    <div className="profile__image__container"> 
                        <img src="/profile__banner.png" className='banner__image' alt="" /> 
                        <img src={`https://www.md-sohidul-islam.com/${loggedInUser.img__url}`} className='profile__image' alt="" /> 
                        
                        
                        <label className='upload__icon' onClick={()=>setOpen(!open)} title='upload your profile image'>
                            <IconButton color="secondary" className='bg-white' aria-label="upload picture" component="span">
                            <PhotoCamera className='upload__logo__icon' />
                            </IconButton>
                        </label>
                         

                    </div>
                    <div className="profile__info__container">
                        <p className='profile__name1'>{loggedInUser.first_name}</p>
                        <p className='profile__name2'>branch code : {loggedInUser.branch_code}</p>
                        <p className='profile__name3'>work code : {loggedInUser.work_code}</p>
                    </div>
                </div>
            </div>
        

        {open? 
        <div className="form__container__upload">
            <div className="form__fit__container__upload">
                <div className="form__gradient___container__upload text-white">
                    <form onSubmit={handleFileSubmit}> 
                        <input type="file" onChange={handleFileChange} className='input__file' name="image" id="image" />
                        <input type="submit" className='input__submit' value="UPLOAD" /> 
                        <button className='input__submit bg-warning text-secondary' onClick={()=>setOpen(!open)}>CANCEL</button>
                    </form>
                </div>
            </div>
        </div>
        :""}

        </div>
    );
};

export default Profile;


// {/* <div className='profile__container'>
           
// <div className="container">  
//     <p>Name: {loggedInUser.first_name}</p>
//     <p>Email: {loggedInUser.second_email}</p>
//     <p>Phone: {loggedInUser.third_phone}</p>
//     <p>শাখা কোড : {loggedInUser.branch_code}</p>
//     <p>Work Code: {loggedInUser.work_code}</p> 
// </div>
// </div> */}