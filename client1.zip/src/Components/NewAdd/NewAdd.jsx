import '../Form.scss';
import axios from 'axios';
import React from 'react';
import { useState } from 'react';
import { useContext } from 'react';
import { UserContext } from '../../App';   
import './NewAdd.scss' 
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import FaildResult from '../Loader/FaildResult';
import { Link } from 'react-router-dom';



const NewAdd = () => {
    let passbookObj = {
        prevSaveStatus:0, 
        prevSaveWithdrawStatus:0,
        presentSaveStatus:0,
        prevTotalDebtCollection:0,
        presentTotalDebtCollection:0,
        passbookHeader:['সঞ্চয় জমা',  'সঞ্চয় উত্তলন', 'সঞ্চয় স্থিতি', 'কিস্তি সংখ্যা', 'ঋণ আদায়', 'ঋণের স্থিতি', 'আদায়কারীর নাম'],
        bigest:0,
    }
    const [loggedInUser, setLoggedInUser] = useContext(UserContext)
    const [Clear ,setClear] = useState(true);
    const [memberInfo, setMemberInfo] = useState({});
    const [newAddInfo, setNewAddInfo] = useState({}); 
    const [dataStore, setDataStore] = useState(false); 
    const [accountInfo, setAccountInfo] = useState([]) 

    const [openTable ,setOpenTable] = useState(false); 
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
 
    if(memberInfo){ 
    // newAddInfo of add some property start
    newAddInfo.how_much_to_borrow=memberInfo.how_much_to_borrow;
    newAddInfo.signature=memberInfo.kormirNam;
    newAddInfo.area_code=memberInfo.kormoElakarCode;
    newAddInfo.prokolperNam=memberInfo.prokolperNam;
    // newAddInfo of add some property end
    }
    

     
 

 
    accountInfo.filter(AI => {  
      
        passbookObj.prevSaveStatus=passbookObj.prevSaveStatus + Number(AI.save_deposit);
        passbookObj.prevSaveWithdrawStatus = passbookObj.prevSaveWithdrawStatus + Number(AI.save_withdraw)
        passbookObj.prevTotalDebtCollection = passbookObj.prevTotalDebtCollection + Number(AI.debt_collection);
         
    })   

    const handleBlur = (e) => { 
        const newInfo = {...newAddInfo};
        newInfo[e.target.name]=e.target.value; 
        setNewAddInfo(newInfo)   
    }; 
    ////console.log(newAddInfo);

    if(newAddInfo.save_deposit){
      passbookObj.prevSaveStatus =  Number(newAddInfo.save_deposit) + passbookObj.prevSaveStatus;

    } 
    if(newAddInfo.save_withdraw){
        passbookObj.prevSaveStatus =passbookObj.prevSaveStatus- Number(newAddInfo.save_withdraw);
    }
    
    if(newAddInfo.save_deposit && newAddInfo.save_withdraw){
        passbookObj.presentSaveStatus = passbookObj.prevSaveStatus -passbookObj.prevSaveWithdrawStatus
        newAddInfo.save_total = passbookObj.presentSaveStatus
    }
    
 
    

    if(newAddInfo.date){
        let date = newAddInfo.date;
        newAddInfo.month = date.slice(5,7);
        newAddInfo.day = date.slice(8,10);
        newAddInfo.year = date.slice(0,4)  
    }

    if(newAddInfo.debt_collection){
        passbookObj.prevTotalDebtCollection = passbookObj.prevTotalDebtCollection + Number(newAddInfo.debt_collection);
        let presentDebtStatus = Number(memberInfo.debt_total) - passbookObj.prevTotalDebtCollection;
        passbookObj.presentDebtStatus= presentDebtStatus;
        newAddInfo.debt_total = passbookObj.presentDebtStatus;
    }  

    if(accountInfo.installment_count){
        newAddInfo.installment_count=accountInfo.length+1;
    }

    const handleSubmitNewAdd = (e) => { 
        e.preventDefault();
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.post('https://www.md-sohidul-islam.com/passbook', {
                info: newAddInfo
    }).then(response => {  
        
        setTimeout(() => {   
            setNewAddInfo({hisabNumber:memberInfo.hisabNumber});
            setClear(!Clear);
            setDataStore(!dataStore)
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo); 
                    setClear(true)
                }, 800); 
        }, 800);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
    } 
 
    const handleFind = (e) => {
        e.preventDefault();


        axios.get('https://www.md-sohidul-islam.com/getmember',{
            params:{
                name: newAddInfo.hisabNumber
            }
        })
        .then(res => {     
            let result = res.data.successResult; 
            let resultLength = res.data.successResult.length;  
            setMemberInfo(result[resultLength-1]) 

            if(memberInfo.how_much_to_borrow){ 
                let newInfo = {...ServerResult};
                newInfo.loaderShow=true;
                setServerResult(newInfo)
                axios.get('https://www.md-sohidul-islam.com/getaccount',{
                    params:{
                        name: memberInfo.hisabNumber,
                        type: memberInfo.how_much_to_borrow
                    }
                }) 
                .then(res => { 
                    setAccountInfo([]); 

                    setAccountInfo(res.data.successResult);
                    setDataStore(!dataStore); 
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true; 
                    setServerResult(newInfo)  

                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo); 
                        setClear(true)
                    }, 800); 

                }).catch(error => {  
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage=error.message;
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 3000);
                }) 
            }
 

        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 

    } 

    const handlePassbookDeleteAccess = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    
    const handleDelete = (id) => { 

        setDeleteState(false);

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'passbook'
            }
        })
        .then(res => { 
            
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true; 
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)
                setTimeout(() => {
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;  
                    setServerResult(newInfo)
                    document.getElementById(`${deleteNumber}`).style.display='none';
                }, 800);
            }, 800);
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message;
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
    }

    const addAnother = () => { 

        // const [Clear ,setClear] = useState(true);
        // const [memberInfo, setMemberInfo] = useState({});
        // const [newAddInfo, setNewAddInfo] = useState({}); 
        // const [dataStore, setDataStore] = useState(false); 
        // const [accountInfo, setAccountInfo] = useState([]) 
 
        setAccountInfo([])
        setDataStore(!dataStore)
    }
    

    return (
        
        <div style={{backgroundColor:'#015e31'}}>

        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
                    <div>
            {
                Clear? 
                
                <div className='form__container text-center'>   
                {dataStore ? <p className='text-center text-white'><b>Name:</b> {memberInfo.nam}  <b> Account number:</b> {memberInfo.hisabNumber}</p>: ''}
                {dataStore?  
                    <div>
                        <form onSubmit={handleSubmitNewAdd}>
                            <input onBlur={handleBlur} type="date" name='date' className='input' placeholder='Enter date' required/> 
                            <input onBlur={handleBlur} type="number" name='save_deposit' className='input' placeholder='সঞ্চয় জমা' required/> 
                            <input onBlur={handleBlur} type="number" name='save_withdraw' className='input' placeholder='সঞ্চয় উত্তলন' required/> 
                            {passbookObj.presentSaveStatus? <input onBlur={handleBlur} type="number" name='save_total' className='input' placeholder='সঞ্চয় স্থিতি' defaultValue={passbookObj.presentSaveStatus} required/> : ""}
                            <input onBlur={handleBlur} type="text" name='installment_count' className='input' placeholder='কিস্তি সংখ্যা' required/> 
                            <input onBlur={handleBlur} type="number" name='debt_collection' className='input' placeholder='ঋণ আদায়' required/> 
                            {passbookObj.presentDebtStatus ? <input onBlur={handleBlur} type="number" name='debt_total' className='input' placeholder='ঋণের স্থিতি' defaultValue={passbookObj.presentDebtStatus} required/>: ''} 
                            <input onBlur={handleBlur} type="number" name='area_code' className='input' placeholder='কর্ম এলাকার কোড' defaultValue={memberInfo.kormoElakarCode} required/> 
                            <input onBlur={handleBlur} type="text" name='signature' className='input' placeholder='আদায়কারীর নাম' defaultValue={memberInfo.kormirNam} required/>
                            <input type="submit" className='submit__button' value='submit' />
                        </form> 
                        
                        <buttton onClick ={addAnother} className='btn btn-warning'>add another</buttton>

                    </div>
                
                :<form onSubmit={handleFind}><input className="input"   onBlur={handleBlur} type='number'   placeholder="হিসাব নম্বর" name="hisabNumber" required/><input className='submit__button' type="submit" value="FIND MEMBER" /></form>}
              {dataStore?   <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>:""}
            </div>
                
                
                : ""
            }  
            {dataStore?  
            <>
            {openTable? 
            <table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                            ['তারিখ','সঞ্চয় জমা',  'সঞ্চয় উত্তলন', 'সঞ্চয় স্থিতি', 'কিস্তি সংখ্যা', 'ঋণ আদায়', 'ঋণের স্থিতি', 'আদায়কারীর নাম'].map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.date}</td>
                                        <td>{info.save_deposit}</td>
                                        <td>{info.save_withdraw}</td>
                                        <td>{info.save_total}</td>
                                        <td>{info.installment_count}</td>
                                        <td>{info.debt_collection}</td>
                                        <td>{info.debt_total}</td>
                                        <td>{info.signature}</td>
                                        {loggedInUser.admin_level==='01'?                                        <span>
                                        <button onClick={()=>handlePassbookDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button>
                                        <Link to={`/passbookupdate/${info.id_find}`}><button className='btn btn-warning btn-sm mr-1'>UPDATE</button></Link>
                                        </span>:''}
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table> :""}</>:""}
        </div>
{/*         
        <div className="form__container">

        <form autoComplete={false} onSubmit={handleDebtInfoBook}> 
 
                        <input 
                            className='input'
                            type='date'
                            onBlur={handleBlur}
                            placeholder="তারিখ"
                            name='date'
                            required 
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="কর্মীর কোড"
                            name='name_of_the_employee'
                            required
                            type="text"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="শীট নং"
                            name='sheet_no'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="সদস্য সংখ্যা"
                            name='number_of_members'
                            required
                            type="number"
                        /> 
                        <span className='py-3'> <b>ঋণ আদায়</b> <br />
                       
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="সাপ্তাহিক"
                                name='debt_weekly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="দৈনিক"
                                name='debt_daily'
                                required
                                type="number"
                            />   
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মাসিক"
                                name='debt_monthly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মেয়াদি"
                                name='debt_term'
                                required
                                type="number"
                            />   
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মোট ঋণ আদায়"
                                name='total_debt_recovery' 
                                required
                                type="number"
                            /> 
                        </span> 
                        <span className='py-3 mb-1'> <b>সঞ্চয় আদায়</b> <br />
                       
                        
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="সাপ্তাহিক"
                                name='saving_weekly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মাসিক"
                                name='saving__monthly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="চলতি"
                                name='savings_current'
                                required
                                type="number"
                            />    
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মোট সঞ্চয় আদায়"
                                name='collection_of_total_savings'
                                required 
                                type="number"
                            /> 
                        </span>
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="ভর্তি ফি"
                            name='admission_fee'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="ঋণ ফি"
                            name='loan_fees'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="বীমা"
                            name='insurance'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="ফরম ফি"
                            name='form_fee'
                            required
                            type="number"
                        />  
                        
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="বিবিধ"
                            name='miscellaneous'
                            required
                            type="number"
                        />   
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="মোট আদায়"
                            name='total_realization'
                            required 
                            type="number"
                        />    
                       
                        <span className='py-3'> <b>সঞ্চয় উত্তোলন</b> <br />
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="সাপ্তাহিক"
                                name='weekly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মাসিক"
                                name='monthly'
                                required
                                type="number"
                            />  
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="চলতি"
                                name='current'
                                required
                                type="number"
                            />   
                            <input 
                                className='input '
                                onBlur={handleBlur}
                                placeholder="মোট সঞ্চয় উত্তোলন"
                                name='total_savings_withdrawal'
                                required 
                                type="number"
                            /> 
                        </span>

                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="লাভ উত্তোলন"
                            name='profit_withdrawal'
                            required
                            type="number"
                        />  
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            placeholder="সাক্ষর"
                            name='signature'
                            required
                            type="text"
                        />
                        <span className='py-3'> <b>ঋণ প্রদান</b> <br />
                        
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="w ঋণ  প্রদান"
                            name='w_debt_provide'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="d ঋণ  প্রদান"
                            name='d_debt_provide'
                            required
                            type="number"
                        />  
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="m ঋণ  প্রদান"
                            name='m_debt_provide'
                            required
                            type="number"
                        />  
                        
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="sm ঋণ  প্রদান"
                            name='sm_debt_provide'
                            required
                            type="number"
                        />   
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="মোট ঋণ  প্রদান"
                            name='total_debt_provide'
                            required
                            type="number" 
                        /> 
                        <input 
                            className='input '
                            onBlur={handleBlur}
                            placeholder="মোট স্থিতি"
                            name='total_status'
                            required
                            type="number" 
                        />  
                        </span>
                        <input type="submit" value="Submit" className='submit__button' />
                    </form>

        
        <form className='my-4' onSubmit={handleDebtInfoBook}>   
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="DGL employee total"
                                        name='dgl_employee_total'
                                        required
                                        type="number" 
                                /> 
                                <input 
                                        className='input'
                                        onBlur={handleBlur}
                                        placeholder="কর্জ  গ্রহণ" 
                                        name='profit_withdrawal'
                                        required
                                        type="number"
                                />  
                                
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="কর্জ প্রদান" //minush value
                                        name='korjoprodan'
                                        required
                                        type="number"
                                />  
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="পেডিকেস"//minush value 
                                        name='pedices'
                                        required
                                        type="number"
                                /> 
                                <input 
                                        className='input '
                                        onBlur={handleBlur}
                                        placeholder="মোট"//minush value 
                                        name='total'
                                        required
                                        type="number" 
                                /> 
                                <input type="submit" value="submit" className='submit__button' />
                       </form>


        <form onSubmit={handleDebtInfoBook}>   
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='date'
                            placeholder="তারিখ" 
                            name='date'
                            required  
                        />  

                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক জমা" 
                            name='gl_deposit'
                            required  
                        />  
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক মোট জমা" 
                            name='gl_weekly_total_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাতিক উত্তোলন" 
                            name='gl_weekly_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক মোট উত্তোলন" 
                            name='gl_weekly_total_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক স্থিতি" 
                            name='gl_weekly_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক জমা" 
                            name='gl_monthly_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক মোট জমা" 
                            name='gl_monthly_total_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক উত্তোলন" 
                            name='gl_monthly_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক মোট  উত্তোলন" 
                            name='gl_monthly_total_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক স্থিতি" 
                            name='gl_monthly_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD জমা" 
                            name='gl_fd_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD মোট জমা" 
                            name='gl_fd_total_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD উত্তোলন" 
                            name='gl_fd_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD মোট উত্তোলন" 
                            name='gl_fd_total_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD স্থিতি" 
                            name='gl_fd_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মোট জমা স্থিতি" 
                            name='gl_total_savings_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মোট উত্তোলন স্থিতি" 
                            name='gl_total_withdrawal_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মোট স্থিতি" 
                            name='gl_total_status'
                            required  
                        />             



                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='text'
                            placeholder="সাক্ষর" 
                            name='gl_signature'
                            required  
                        /> 
                        <input type="submit" value="submit" className='submit__button'/>
                    </form>

            <form onSubmit={handleSubmitNewAdd}>
                            <input onBlur={handleBlur} type="date" name='date' className='input' placeholder='Enter date'  required/> 
                            <input onBlur={handleBlur} type="number" name='save_deposit' className='input' placeholder='সঞ্চয় জমা' required/> 
                            <input onBlur={handleBlur} type="number" name='save_withdraw' className='input' placeholder='সঞ্চয় উত্তলন' required/> 
                            <input onBlur={handleBlur} type="number" name='save_total' className='input' placeholder='সঞ্চয় স্থিতি' defaultValue={passbookObj.presentSaveStatus} required/> 
                            <input onBlur={handleBlur} type="number" name='installment_count' className='input' placeholder='কিস্তি সংখ্যা' required/> 
                            <input onBlur={handleBlur} type="number" name='debt_collection' className='input' placeholder='ঋণ আদায়' required/> 
                            <input onBlur={handleBlur} type="number" name='debt_total' className='input' placeholder='ঋণের স্থিতি' defaultValue={passbookObj.presentDebtStatus} required/> 
                            <input onBlur={handleBlur} type="number" name='area_code' className='input' placeholder='কর্ম এলাকার কোড' defaultValue={memberInfo.kormoElakarCode} required/> 
                            <input onBlur={handleBlur} type="text" name='signature' className='input' placeholder='আদায়কারীর নাম' defaultValue={loggedInUser.first_name} required/>
                            <input type="submit" className='submit__button' value='submit' />
            </form>
            <form onSubmit={handleDebtInfoBook}> 

<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="Phone"
    type='date'
    name='date'
    required
     
/> 
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w ঋণ প্রদান"
    type='number'
    name='w_lending'
    required
     
/>   
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w মোট ঋণ প্রদান"
    type='number'
    name='w_total_lending' 
    required
    />  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w সার্ভিস চার্জ "
    type='number'
    name='w_service_charge'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w মোট সার্ভিস চার্জ "
    type='number'
    name='w_total_service_charge' 
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w ঋণ আদায়"
    type='number'
    name='w_debt_collection'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w মোট ঋণ আদায় "
    type='number'
    name='w_total_debt_collection' 
    required
     
/> 
  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="w মোট ঋণ স্থিতি"
    type='number'
    name='w_total_debt_status' 
    required 
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D ঋণ প্রদান"
    type='number'
    name='d_lending'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D মোট ঋণ প্রদান"
    type='number'
    name='d_total_loan_disbursement' 
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D সার্ভিস চার্জ "
    type='number'
    name='d_service_charge'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D মোট সার্ভিস চার্জ "
    type='number'
    name='d_total_service_charge' 
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D ঋণ আদায়"
    type='number'
    name='d_debt_collection'
    required
     
/>   
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D মোট ঋণ আদায়"
    type='number'
    name='d_total_debt_collection' 
    required
     
/>   
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="D মোট ঋণ স্থিতি"
    type='number'
    name='d_total_debt_status'
    required 
/>   
                <input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M ঋণ প্রদান"
    type='number'
    name='m_lending'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M মোট  ঋণ প্রদান"
    type='number'
    name='m_total_loan_disbursement'
    required  
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M  সার্ভিস চার্জ"
    type='number'
    name='m_service_charge'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M মোট সার্ভিস চার্জ "
    type='number'
    name='m_total_service_charge'
    required 
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M ঋণ আদায় "
    type='number'
    name='m_debt_collection'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M মোট ঋণ আদায়"
    type='number'
    name='m_total_debt_collection'
    required 
     
/>   
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="M মোট ঋণ স্থিতি"
    type='number'
    name='m_total_debt_status'
    required  
/>
                <input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM ঋণ প্রদান"
    type='number'
    name='sm_lending'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM মোট  ঋণ প্রদান"
    type='number'
    name='sm_total_loan_disbursement'
    required 
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM সার্ভিস চার্জ "
    type='number'
    name='sm_service_charge'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM মোট সার্ভিস চার্জ"
    type='number'
    name='sm_total_service_charge'
    required 
/>  

<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM ঋণ আদায়"
    type='number'
    name='sm_debt_collection'
    required
     
/>  
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM মোট ঋণ আদায় "
    type='number'
    name='sm_total_debt_collection'
    required 
/>   
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="SM মোট ঋণ স্থিতি "
    type='number'
    name='sm_total_debt_status'
    required 
/>   
<input
    className='input'
    onBlur={handleNewBlur}
    placeholder="মোট ঋণ স্থিতি "
    type='number'
    name='total_debt_status'
    required 
/>  

<input type="submit" value="submit" className='submit__button' />
</form> 
        </div> */}



        </div>
    );
};

export default NewAdd;