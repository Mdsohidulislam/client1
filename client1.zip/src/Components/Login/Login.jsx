
import './Form.css'
import TextField from '@material-ui/core/TextField';  

import firebase from "firebase/app"; 
import "firebase/analytics"; 
import "firebase/auth";
import "firebase/firestore";
import firebaseConfigKeys from '../../firebaseConfig';
import { useContext, useState } from 'react';
import { UserContext } from '../../App';
import { useHistory, useLocation } from 'react-router-dom';
import axios from 'axios'; 
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import FaildResult from '../Loader/FaildResult';


const firebaseConfig = firebaseConfigKeys;

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
 }else {
    firebase.app(); // if already initialized, use that one
 }
 
var provider = new firebase.auth.GoogleAuthProvider();









const FormComponents = () => {

  const [loggedInUser, setLoggedInUser] = useContext(UserContext);  
  const [googleVerify, setGoogleVerifyy] = useState(false);
  const [mailPassword, setMailPassword] = useState({});
  const [googleMail, setGoogleMail] = useState({});
  const history = useHistory();
  const location = useLocation();
  let { from } = location.state || { from: { pathname: "/" } };
  const [ServerResult, setServerResult] = useState({
      successShow:false,
      faildShow:false,
      loaderShow:false,
      successMessage:'',
      faildMesssage:''
  })
  

  const handleGoogleSignIn = () => { 
 
        
        
     firebase.auth().signInWithPopup(provider)
     .then((result) => { 
       var credential = result.credential;
    
       var token = credential.accessToken; 
       var user = result.user;    
       const {displayName, email, emailVerified, photoURL} = user;    
       const newLoggedInUser = {displayName, email, emailVerified, photoURL};
       setGoogleMail(newLoggedInUser)  
       if(emailVerified){
              axios.get('https://www.md-sohidul-islam.com/login',{
                 params:{
                     email: email,
                     code: ']42T3a2cP&p?m3Fg'
                 }  
              }).then(response => {   
                  let successResult = response.data.successResult;
                  if(successResult.second_email){
                        setGoogleVerifyy(!googleVerify)
                        
                  } 
            }).catch(error => {   
                //console.log(error.message);
            }) 
       }
 
     })
    
 

}   
    const handleBlur = (e) => {
        const newUser = {...mailPassword};
        newUser[e.target.name] = e.target.value; 
        setMailPassword(newUser)
    }
    
    const handleMailAndPasswordLogin = (e) => {
        e.preventDefault();
        //console.log(googleMail);

        if(mailPassword.email && mailPassword.password){
            let newInfo = {...ServerResult};
            newInfo.loaderShow=true;
            setServerResult(newInfo)

            axios.get('https://www.md-sohidul-islam.com/loginN',{
                params:{
                    email: mailPassword.email,
                    password: mailPassword.password,
                    code:']42T3a2cP&p?m3Fg'
                }
            }).then(response => {  
                let successResult = response.data.successResult;
                if(successResult && successResult.fourth_securityy === mailPassword.password){ 

 
 

                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=true;
                        newInfo.successMessage='Successfully logged in';
                        setServerResult(newInfo)
                        const bsblMemberInfo = response.data.successResult;
                        bsblMemberInfo.isLoggedIn = true;  
                            setLoggedInUser(bsblMemberInfo) 
                            setTimeout(() => {
                                history.replace(from);
                            }, 800); 
                    }, 800);
                }else{ 
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=false;
                        newInfo.faildShow=true;
                        newInfo.faildMesssage='Wrong email or password!' 
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult};  
                                newInfo.faildShow=false; 
                                setServerResult(newInfo)  
                            }, 3000); 
                    }, 800);

                } 
            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message;
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 800);
            }) 

            }
    }

    return (
        <div className="col-10 col-md-4 mx-auto my-5 shadow-lg p-3"> 
            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}
            {googleVerify? 
            <div className="log-create-area mb-2 pb-2 p-1">
                <form className='p-2 br-2'> 
                <TextField onBlur={handleBlur} name='email' className='w-100' type='email' label='Email' required></TextField><br/>
                <TextField onBlur={handleBlur} name='password' className='w-100' type='password' label='Password' required></TextField><br/> 
                
                <div className="submit mt-2" onClick={handleMailAndPasswordLogin}> 
                    {googleMail.email === mailPassword.email ? <button type='submit' className='submit_button my-auto'>LOG IN</button> :""}
                     
                </div>
                </form>
            </div>: 
            // {/* <div className="or-area">
            //     <div className='or_div'></div>
            //     <div className='or'>Or</div>
            // </div>    */}
            <div className="fb-google-area pt-3">
                {/* <p><img src='/facebook.png' alt=""/> Continue with Facebook</p> */}
                <p onClick={handleGoogleSignIn}><img src='/google.png' alt=""/> Continue with Google</p>
            </div> }   
        </div>
    );
};

export default FormComponents;










































// import "firebase/auth"; 
// import React, { useContext } from 'react'; 
// import firebase from "firebase/app";  
// import firebaseConfigKeys from '../../firebaseConfig';   
// import { UserContext } from "../../App";



// const firebaseConfig = firebaseConfigKeys;  


// if (!firebase.apps.length) {
//     firebase.initializeApp(firebaseConfig); 
//  }else {
//     firebase.app(); // if already initialized, use that one
//  }

// var provider = new firebase.auth.GoogleAuthProvider();

// const handleSignIn = () => {

//     firebase.auth()
//   .signInWithPopup(provider)
//   .then((result) => {
       
//     var credential = result.credential; 
//     var token = credential.accessToken; 
//     ////console.log(token);
//     var user = result.user;
     
//     if(result){
//         ////console.log(user);
//     }
//     // ...
//   }).catch((error) => { 
//     var errorCode = error.code;
//     var errorMessage = error.message; 
//     var email = error.email; 
//     var credential = error.credential;
//     ////console.log(errorMessage);
//     // ...
//   });

// }

// const Login = () => {

//     const [infos, setInfos]= useContext(UserContext)

//     return (
//         <div>
//             <button onClick={handleSignIn}>sign in via google</button>
//             <h1>Hello {infos.name}</h1>
//         </div>
//     );
// };

// export default Login;