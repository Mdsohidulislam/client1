import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './AboutUs.scss'

const AboutUs = () => {
    const [aboutUs, setAboutUs] = useState([]);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });

    // document.title = 'আমাদের সস্পর্কে'

    useEffect(()=>{ 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo); 

        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'aboutus'
            }
        })
        .then(res=> {

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    

                        let currentNotice = res.data.successResult;
                        setAboutUs(currentNotice);  

                    }, 800); 
            }, 800); 
        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])

    return (
        <div className='about__us__container'>

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
            msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
            msg={ServerResult.faildMesssage}/> : ""}
            {aboutUs.length? 
            <div>    
                  <h4><b>পরিচিতি:-</b></h4>
                  <p>{aboutUs[aboutUs.length-1].aboutus}</p>
            </div>
            :""}
            {/* <p><b>বন্ধুসততা বিজনেস লিমিটেড</b> একটি আর্থ সামাজিক উন্নয়নমূলক প্রতিষ্ঠান।
<b>"চলবো মোরা একসাথে জয় করবো মানবতাকে"</b> এই প্ৰতিপাদ্যকে সামনে রেখে ২০১৯ সালের ১৬মার্চ  <b>বন্ধুসততা বিজনেস লিমিটেড</b> এর আত্মপ্রকাশ রচনা হয়। <b>বন্ধুসততা বিজনেস লিমিটেড</b> একটি  অরাজনৈতীক সামাজিক  উন্নয়ন মূলক প্রতিষ্ঠান । বর্তমানে <b> বন্ধুসততা বিজনেস লিমিটেড</b> এর <Link to='/contactus'>চারটি শাখা</Link> দ্বারা চাঁপাইনবাবগঞ্জ  জেলার মধ্যে কার্যক্রম পরিচালনা  করা হচ্ছে। 
সমাজের অসহায় , দরিদ্রদের  প্রতক্ষ ও পরোক্ষভাবে সাহায্য ও  সহযোগিতা  করা , কর্মসংস্থানের সুযোগ সৃষ্টি  ও ক্ষুদ্র ঋণ কার্যক্রম , বয়স্ক ও বিধবাদের আর্থিক সাহায্য প্রদান এই প্রতিষ্ঠানের প্রধান লক্ষ।  
দুধ ও মাংসের চাহিদা পূরণের জন্য বন্দুসততা বিজনেস লিমিটেড এর আছে বন্ধুসততা ডেইরি ফার্ম   (গরুর খামার)। </p> */}
        </div> 
    );
};

export default AboutUs;