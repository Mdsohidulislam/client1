import { AccountCircle } from '@material-ui/icons';
import React from 'react';
import { Container, Nav, Navbar} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import IconButton from '@material-ui/core/IconButton';
import Badge from '@material-ui/core/Badge'; 
import MailIcon from '@material-ui/icons/Mail';
import { useContext } from 'react';
import { UserContext } from '../../App';


const Navbarr = () => {
  const [loggedInUser, setLoggedInUser] = useContext(UserContext); 

  return (
    <div>   
        <Navbar style={{background:'#015E31'}} expand="lg">
  <Container>
    <Navbar.Brand><Link className='navbar-brand text-white' to='/'>
      <h1>BSBL</h1> 
      
      </Link></Navbar.Brand>
    <Navbar.Toggle className='bg-white' aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="ml-auto">    



          <Link className='nav-link text-center text-white' to='/'><span>HOME</span></Link> 
          <Link className='nav-link text-center text-white' to='/ourservices'><span>OUR SERVICES</span></Link> 
          <Link className='nav-link text-center text-white' to='/aboutus'><span>ABOUT US</span></Link> 
          <Link className='nav-link text-center text-white' to='/contactus'><span>CONTACT US</span></Link>
          <Link className='nav-link text-center text-white' to='/checkpassbook'><span>CHECK PASSBOOK</span></Link>
          <Link className='nav-link text-center text-white' to='/notice'><span>NOTICE</span></Link>
          {loggedInUser.admin_level==='01'? 
          <Link style={{marginTop:'-10px'}} className='nav-link text-center text-white' to='/messages'> 
          <IconButton aria-label="show 4 new mails" color="inherit">
            <Badge badgeContent={loggedInUser.noticeLength} color="secondary">
              <MailIcon className='text-white'/>
            </Badge>
          </IconButton>
          </Link>:""}
          <Link className='nav-link text-center text-white' to='/profile'><span><AccountCircle/></span></Link>
      </Nav>
    </Navbar.Collapse>
  </Container>
</Navbar>
    </div>
  );
};

export default Navbarr;