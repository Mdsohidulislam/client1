import axios from 'axios';
import React, { useEffect } from 'react';
import { useContext } from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { UserContext } from '../../App'; 
import './Notice.scss'



const Notice = () => {
    const [notice, setNotice]  = useState({notice:'empty notice'}); 
    const [officeNotice, setOfficeNotice] = useState({notice:'empty notice'});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);

    // document.title = 'বিজ্ঞপ্তি'

    useEffect(()=>{ 
        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'notice'
            }
        })
        .then(res=> {   
            setTimeout(() => {  
                    setTimeout(() => { 

                        let noticeLength = res.data.successResult.length;
                        let currentNotice = res.data.successResult[res.data.successResult.length-1];
                        if(noticeLength){
                            setNotice(currentNotice); 
                        }else{
                            setNotice({notice:'empty notice'})
                        } 
                    }, 3000); 
            }, 3000); 
        }).catch(error => {   
        })
    },[])
     
        useEffect(()=>{ 
        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'officenotice'
            }
        })
        .then(res=> {   
            setTimeout(() => {  
                    setTimeout(() => { 

                        let noticeLength = res.data.successResult.length;
                        let currentNotice = res.data.successResult[res.data.successResult.length-1];
                        if(noticeLength){
                            setOfficeNotice(currentNotice); 
                        }else{
                            setOfficeNotice({notice:'empty notice'})
                        } 
                    }, 3000); 
            }, 3000); 
        }).catch(error => {   
        })
    },[])
    
    

 


    return (
        <div>
            

            <div className='marquee__container'> 
                <Link to='/notice'>
                <marquee style={{color:'red'}}>{notice.notice}</marquee></Link> 
                 
                  {loggedInUser.isLoggedIn?<Link to='/notice'> <marquee style={{color:'red'}}>{officeNotice.notice}</marquee></Link>:""} 
                 
            </div>
        </div>
    );
};

export default Notice;