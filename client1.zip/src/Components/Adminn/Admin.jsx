
import axios from 'axios';
import React, { useState } from 'react';
import { useEffect } from 'react';
import { useContext } from 'react';
import { UserContext } from '../../App';
import '../Form.scss';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const Admin = () => { 

    const [adminInfo, setAdminInfo] = useState({});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true);
    const [branch, setBranch] = useState([]);
    const [accountInfo, setAccountInfo] = useState([]);
    const [openTable, setOpenTable] = useState(false);
    const [isStorePassword, setIsStorePassword] = useState(false);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getalldata',{
            params:{
                code:']42T3a2cP&p?m3Fg',
                database:'admin'
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        setAccountInfo(res.data.successResult); 
                    }, 800); 
            }, 800); 

        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    },[])

    useEffect(()=>{ 

        axios.get('https://www.md-sohidul-islam.com/getalldata',{
            params:{
                code:']42T3a2cP&p?m3Fg',
                database:'contactinfo'
            }
        })
        .then(res => {  
                        setBranch(res.data.successResult);  

        }).catch(error => {  
            
            //console.log(error.message);

        })
    },[])

    let dbYear = new Date().getFullYear().toString();
    let dbMonth =new Date().getMonth()+1;
    let dbDay =  new Date().getDate().toString();
    
    adminInfo.day=dbDay;
    adminInfo.month=dbMonth.toString();
    adminInfo.year=dbYear;
    adminInfo.admitted_date=`${dbMonth}/${dbDay}/${dbYear}`;

    const handleBlur = (e) => { 
        
        const newInfo = {...adminInfo};
        newInfo[e.target.name]=e.target.value;
        setAdminInfo(newInfo)  
        //console.log(newInfo);  
    };

    if(loggedInUser.admin_level === '2' || loggedInUser.admin_level === '02'){
        adminInfo.admin_level='03'
    } 

    const handleSubmitAdmin = (e) => { 
 
        e.preventDefault();

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.post('https://www.md-sohidul-islam.com/admin', {
                info: adminInfo
    }).then(response => {  
        
        setTimeout(() => {    
            setClear(!Clear); 
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo); 
                    setClear(true)
                }, 800); 
        }, 800);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 
    }

    const handleAdminDeleteAccess =(id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    const handleAdminDelete = () => { 
        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'admin'
            }
        })
        .then(response => { 
            

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    const handleShowPassword = (id) => {
        let logPass = prompt('Enter your password then show your employee password');
        if(logPass===loggedInUser.fourth_securityy){
            alert(`Your employee password is ${id}`);
        }else{
            alert('Wrong password')
        }
    }


    return (
        <div style={{backgroundColor:'#015e31'}}>
        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleAdminDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}
            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
            {Clear?  
            <div className='form__container text-center'>  
                <form  onSubmit={handleSubmitAdmin}>  
                    <input 
                        className='input'
                        onBlur={handleBlur}
                        type='text'
                        placeholder="Name" 
                        name='first_name'
                        required  
                    />  
                    <input
                        className='input'
                        onBlur={handleBlur}
                        placeholder="Email"
                        name='second_email'
                        type='email'
                        required
                        
                    />  
                    <input
                        className='input'
                        onBlur={handleBlur}
                        placeholder="Phone"
                        type='number'
                        name='third_phone'
                        required
                        
                    />  
                    <input
                        className='input'
                        onBlur={handleBlur}
                        placeholder="Security Code"
                        name='fourth_securityy'
                        required 
                    />   
                    {branch.length? 
                    <select onBlur={handleBlur} name="branch_code" className='input' required>
                        <option>শাখা কোড</option> 
                        {branch.map(info => {
                            return <option key={info.id_find} value={`${info.branch_code}`}>{info.branch_code}</option>;
                        })} 
                    </select>:""}

                    <input
                        onBlur={handleBlur}
                        type='number'
                        className='input'
                        placeholder="Number of work area"
                        name='work_code'
                        required 
                    />
                    {loggedInUser.admin_level === '2' || loggedInUser.admin_level === '02' ? 
                    ""
                    
                    :
                    
                    // <input
                    // type='number'
                    // className='input'
                    // onBlur={handleBlur}
                    // placeholder="Admin Level"
                    // name='admin_level'
                    // required 
                    // /> 
                    <select onBlur={handleBlur} name="admin_level" className='input' required>
                        <option>অ্যাডমিন লেভেল</option>
                        <option value="01">অ্যাডমিন</option>
                        <option value="02">ম্যানেজার</option>
                        <option value="03">মাঠকর্মী</option> 
                    </select>
                    }

                    <input type="submit" value="submit" className='submit__button'/>
                </form> 
                <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>
            </div>
            : ""}
{openTable? 
<table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                            ['Name','Email',  'Phone', 'শাখা কোড ', 'Work Code',loggedInUser.admin_level==='01'?"secuirty__code":''].map(data => {
                                return(<td>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.first_name}</td>
                                        <td>{info.second_email}</td>
                                        <td>{info.third_phone}</td>
                                        <td>{info.branch_code}</td>
                                        <td>{info.work_code}</td> 
                                        <td>{loggedInUser.admin_level === '01'?<button onClick={()=>handleShowPassword(info.fourth_securityy)}>show password</button>:''}</td>
                                        {loggedInUser.admin_level==='01'? <button onClick={()=>handleAdminDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button>:""}  
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}
        </div>
    );
};

export default Admin;