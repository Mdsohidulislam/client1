 
import axios from 'axios';
import React, { useState } from 'react';
import { useEffect } from 'react';
import { useContext } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { UserContext } from '../../App';
import '../Form.scss';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const GL = () => { 

    const [glInfo, setGlInfo] = useState({});
    const [newGlInfo, setNewGlInfo] = useState({});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true);
    const [IsNew, setIsNew] = useState(false);
    const [gl, setGl] = useState({});
    const [accountInfo, setAccountInfo] = useState([]);
    const [openTable, setOpenTable] = useState(false);
    const [result, setResult] = useState({});
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })

    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);

    const handleBlur = (e) => { 
        
        const newInfo = {...glInfo};
        newInfo[e.target.name]=e.target.value;
        setGlInfo(newInfo)     
    }; 

    const handleNewBlur = (e) => {
        let newInfo = {...newGlInfo};
        newInfo[e.target.name] = e.target.value;
        setNewGlInfo(newInfo); 
    }

 

    if(loggedInUser.isLoggedIn){ 
        glInfo.branch_code= loggedInUser.branch_code;
    } 
    if(loggedInUser.isLoggedIn){
        newGlInfo.branch_code = loggedInUser.branch_code;
    }
    


    if(glInfo.date){
        let date = glInfo.date;
        glInfo.month = date.slice(5,7);
        glInfo.day = date.slice(8,10);
        glInfo.year = date.slice(0,4)  
    }

    if(newGlInfo.date){
        let date = newGlInfo.date;
        newGlInfo.month = date.slice(5,7);
        newGlInfo.day = date.slice(8,10);
        newGlInfo.year = date.slice(0,4)  
    }

    let postObj = {};
    if(!IsNew){
        postObj = glInfo;
    }if(IsNew){
        postObj = newGlInfo;
    }


    {/*gl_deposit,  gl_weekly_total_deposit, gl_weekly_withdrawal, gl_weekly_total_withdrawal, gl_weekly_status*/}
    
    const Sum = (para1, para2) => {
        return Number(para1)+Number(para2)
    }

    const glResult = (para1, para2) => {
        return Number(para1)-Number(para2)
    }

    // gl weekly start
    if(glInfo.gl_deposit){
        let res = Sum(glInfo.gl_deposit, gl.gl_weekly_total_deposit); 
        glInfo.gl_weekly_total_deposit=res;
        result.gl_weekly_total_deposit=res; 
    }else{
        glInfo.gl_weekly_total_deposit=0;
        result.gl_weekly_total_deposit=0; 
    }

    if(glInfo.gl_weekly_withdrawal){
        let res = Sum(glInfo.gl_weekly_withdrawal, gl.gl_weekly_total_withdrawal);
        glInfo.gl_weekly_total_withdrawal=res;
        result.gl_weekly_total_withdrawal=res;
    }else{
        glInfo.gl_weekly_total_withdrawal=0;
        result.gl_weekly_total_withdrawal=0;
    }

    if(glInfo.gl_weekly_total_deposit && glInfo.gl_weekly_total_withdrawal){
        let res = glResult(glInfo.gl_weekly_total_deposit , glInfo.gl_weekly_total_withdrawal);
        glInfo.gl_weekly_status=res;
        result.gl_weekly_status=res;
    }else{
        glInfo.gl_weekly_status=0;
        result.gl_weekly_status=0;
    }

    // gl weekly end

    // gl monthly start
    {/*gl_monthly_deposit, gl_monthly_total_deposit, gl_monthly_withdrawal, gl_monthly_total_withdrawal, gl_monthly_status*/}


    if(glInfo.gl_monthly_deposit){
        let res = Sum(glInfo.gl_monthly_deposit, gl.gl_monthly_total_deposit); 
        glInfo.gl_monthly_total_deposit=res;
        result.gl_monthly_total_deposit=res; 
    }else{
        glInfo.gl_monthly_total_deposit=0;
        result.gl_monthly_total_deposit=0; 
    }

    if(glInfo.gl_monthly_withdrawal){
        let res = Sum(glInfo.gl_monthly_withdrawal, gl.gl_monthly_total_withdrawal);
        glInfo.gl_monthly_total_withdrawal=res;
        result.gl_monthly_total_withdrawal=res;
    }else{
        glInfo.gl_monthly_total_withdrawal=0;
        result.gl_monthly_total_withdrawal=0;
    }

    if(glInfo.gl_monthly_total_deposit && glInfo.gl_monthly_total_withdrawal){
        let res = glResult(glInfo.gl_monthly_total_deposit , glInfo.gl_monthly_total_withdrawal);
        glInfo.gl_monthly_status=res;
        result.gl_monthly_status=res;
    }else{
        glInfo.gl_monthly_status=0;
        result.gl_monthly_status=0;
    }

    // gl monthly end
    
    {/*gl_fd_deposit, gl_fd_total_deposit, gl_fd_withdrawal, gl_fd_total_withdrawal, gl_fd_status */}
    
    // gl fd start

    if(glInfo.gl_fd_deposit){
        let res = Sum(glInfo.gl_fd_deposit, gl.gl_fd_total_deposit); 
        glInfo.gl_fd_total_deposit=res;
        result.gl_fd_total_deposit=res; 
    }else{
        glInfo.gl_fd_total_deposit=0;
        result.gl_fd_total_deposit=0; 
    }

    if(glInfo.gl_fd_withdrawal){
        let res = Sum(glInfo.gl_fd_withdrawal, gl.gl_fd_total_withdrawal);
        glInfo.gl_fd_total_withdrawal=res;
        result.gl_fd_total_withdrawal=res;
    }else{
        glInfo.gl_fd_total_withdrawal=0;
        result.gl_fd_total_withdrawal=0;
    }

    if(glInfo.gl_fd_total_deposit && glInfo.gl_fd_total_withdrawal){
        let res = glResult(glInfo.gl_fd_total_deposit , glInfo.gl_fd_total_withdrawal);
        glInfo.gl_fd_status=res;
        result.gl_fd_status=res;
    }else{
        glInfo.gl_fd_status=0;
        result.gl_fd_status=0;
    } 
    {/* gl_total_savings_status, gl_total_withdrawal_status gl_total_status*/}
    // gl fd end
    // total deposit status start
    if(glInfo.gl_weekly_total_deposit && glInfo.gl_fd_total_withdrawal && glInfo.gl_monthly_total_deposit){
        let res =Number(glInfo.gl_weekly_total_deposit)+Number(glInfo.gl_fd_total_deposit)+Number(glInfo.gl_monthly_total_deposit);
        glInfo.gl_total_savings_status=res;
        result.gl_total_savings_status=res;
    }else{
        glInfo.gl_total_savings_status=0;
        result.gl_total_savings_status=0;
    } 
    // total deposit status end
    // gl total deposit status start
    if(glInfo.gl_weekly_total_withdrawal && glInfo.gl_fd_total_withdrawal && glInfo.gl_monthly_total_withdrawal){
        let res =Number(glInfo.gl_weekly_total_withdrawal)+Number(glInfo.gl_fd_total_withdrawal)+Number(glInfo.gl_monthly_total_withdrawal);
        glInfo.gl_total_withdrawal_status=res;
        result.gl_total_withdrawal_status=res;
    }else{
        glInfo.gl_total_withdrawal_status=0;
        result.gl_total_withdrawal_status=0;
    }
    // gl total deposit status end
    // gl total status start
    if(glInfo.gl_total_savings_status && glInfo.gl_total_withdrawal_status ){
        let res = Number(glInfo.gl_total_savings_status)-Number(glInfo.gl_total_withdrawal_status);

        glInfo.gl_total_status=res;
        result.gl_total_status=res;
    }else{
        
        glInfo.gl_total_status=0;
        result.gl_total_status=0;
    }
    // gl total status end 
    let history = useHistory();

    useEffect(()=>{
        axios.get('https://www.md-sohidul-islam.com/getallonebranchglinfo',{
            params:{
                code: loggedInUser.branch_code
            }
       })
       .then(res => {     
           setAccountInfo(res.data.successResult)
           let resLength = res.data.successResult.length; 
           let result = res.data.successResult;
           if(resLength){
               setGl(result[resLength-1]);
               setIsNew(false);
           }if(resLength === 0){
               setIsNew(true)
           }
       })
       .catch(error => {  
           alert(error.message)
       })
    },[]) 
    
    

    
    const handleSubmitAdmin = (e) => {  
        e.preventDefault();
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.post('https://www.md-sohidul-islam.com/gl', {
                info: postObj
    }).then(response => {  
        
        setTimeout(() => {   

            setGlInfo({});
            setResult({});
            setClear(!Clear);

            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo); 
                    setClear(true)
                }, 3000); 
        }, 3000);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }

    const handleDeleteAccess = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }


    const handleDelete = () => {

        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);


        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'gl'
            }
        })
        .then(res => {  

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }

    return (
        <div style={{backgroundColor:'#015E31'}}> 
        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}
            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}

            <div className='py-2' style={{backgroundColor:'#E6E600', color:'#015e31'}}>
                 <p className='text-center pt-2'><b>Name</b>: {loggedInUser.first_name} <b>Email</b>: {loggedInUser.second_email} <b>শাখা কোড </b>: {loggedInUser.branch_code}</p>
            </div>
            {Clear? 

                    <div className='form__container text-center'> 
                    {!IsNew? 
                    <form onSubmit={handleSubmitAdmin}>   
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='date'
                            placeholder="তারিখ" 
                            name='date'
                            required   
                        />   

                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="সাপ্তাহিক জমা" 
                            name='gl_deposit'
                            required  
                        />  
                        {result.gl_weekly_total_deposit ? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="সাপ্তাহিক মোট জমা" 
                            name='gl_weekly_total_deposit'
                            required  
                            defaultValue={result.gl_weekly_total_deposit}
                        />:""}
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="সাপ্তাতিক উত্তোলন" 
                            name='gl_weekly_withdrawal'
                            required  
                        /> 
                        {result.gl_weekly_total_withdrawal? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="সাপ্তাহিক মোট উত্তোলন" 
                            name='gl_weekly_total_withdrawal'
                            required  
                            defaultValue={result.gl_weekly_total_withdrawal}
                        />:""}
                        {result.gl_weekly_status? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="সাপ্তাহিক স্থিতি" 
                            name='gl_weekly_status'
                            required  
                            defaultValue={result.gl_weekly_status}
                        />:""}

                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মাসিক জমা" 
                            name='gl_monthly_deposit'
                            required  
                        />
                        { result.gl_monthly_total_deposit ? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মাসিক মোট জমা" 
                            name='gl_monthly_total_deposit'
                            required  
                            defaultValue={ result.gl_monthly_total_deposit}
                        />:""}
                        
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মাসিক উত্তোলন" 
                            name='gl_monthly_withdrawal'
                            required  
                        />
                        {result.gl_monthly_total_withdrawal?
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মাসিক মোট উত্তোলন" 
                            name='gl_monthly_total_withdrawal'
                            required  
                            defaultValue={result.gl_monthly_total_withdrawal}
                        /> :""}
                        {result.gl_monthly_status? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মাসিক স্থিতি" 
                            name='gl_monthly_status'
                            required  
                            defaultValue={result.gl_monthly_status}
                        />:""}
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="FD জমা" 
                            name='gl_fd_deposit'
                            required  
                        />
                        {result.gl_fd_total_deposit?
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="FD মোট জমা" 
                            name='gl_fd_total_deposit'
                            required  
                            defaultValue={result.gl_fd_total_deposit}
                        />
                        :""}
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="FD উত্তোলন" 
                            name='gl_fd_withdrawal'
                            required  
                        />
                        {result.gl_fd_total_withdrawal?
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="FD মোট উত্তোলন" 
                            name='gl_fd_total_withdrawal'
                            required  
                            defaultValue={result.gl_fd_total_withdrawal}
                        />:""}
                        {result.gl_fd_status? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="FD স্থিতি" 
                            name='gl_fd_status'
                            required  
                            defaultValue={result.gl_fd_status}
                        />:""}
                        {result.gl_total_savings_status? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মোট জমা স্থিতি" 
                            name='gl_total_savings_status'
                            required  
                            defaultValue={result.gl_total_savings_status}
                        />:""}
                        {result.gl_total_withdrawal_status? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মোট উত্তোলন স্থিতি" 
                            name='gl_total_withdrawal_status'
                            required  
                            defaultValue={result.gl_total_withdrawal_status}
                        />:""}
                        {result.gl_total_status? 
                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='number'
                            placeholder="মোট স্থিতি" 
                            name='gl_total_status'
                            required  
                            defaultValue={result.gl_total_status}
                        />:""}          



                        <input 
                            className='input'
                            onBlur={handleBlur}
                            type='text'
                            placeholder="সাক্ষর" 
                            name='gl_signature'
                            required  
                        /> 
                        <input type="submit" value="submit" className='submit__button'/>
                    </form>
                    : 
                    <form onSubmit={handleSubmitAdmin}>   
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='date'
                            placeholder="তারিখ" 
                            name='date'
                            required  
                        />  

                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক জমা" 
                            name='gl_deposit'
                            required  
                        />  
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক মোট জমা" 
                            name='gl_weekly_total_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাতিক উত্তোলন" 
                            name='gl_weekly_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক মোট উত্তোলন" 
                            name='gl_weekly_total_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="সাপ্তাহিক স্থিতি" 
                            name='gl_weekly_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক জমা" 
                            name='gl_monthly_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক মোট জমা" 
                            name='gl_monthly_total_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক উত্তোলন" 
                            name='gl_monthly_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক মোট  উত্তোলন" 
                            name='gl_monthly_total_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মাসিক স্থিতি" 
                            name='gl_monthly_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD জমা" 
                            name='gl_fd_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD মোট জমা" 
                            name='gl_fd_total_deposit'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD উত্তোলন" 
                            name='gl_fd_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD মোট উত্তোলন" 
                            name='gl_fd_total_withdrawal'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="FD স্থিতি" 
                            name='gl_fd_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মোট জমা স্থিতি" 
                            name='gl_total_savings_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মোট উত্তোলন স্থিতি" 
                            name='gl_total_withdrawal_status'
                            required  
                        />
                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='number'
                            placeholder="মোট স্থিতি" 
                            name='gl_total_status'
                            required  
                        />             



                        <input 
                            className='input'
                            onBlur={handleNewBlur}
                            type='text'
                            placeholder="সাক্ষর" 
                            name='gl_signature'
                            required  
                        /> 
                        <input type="submit" value="submit" className='submit__button'/>
                    </form>}
                      <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>

                    </div>
            
            :""}
            {openTable? 
            <table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                             ["তারিখ ","সাপ্তাহিক জমা ","সাপ্তাহিক মোট জমা ","সাপ্তাতিক উত্তোলন ","সাপ্তাহিক মোট উত্তোলন ","সাপ্তাহিক স্থিতি ","মাসিক জমা ","মাসিক মোট জমা ","মাসিক উত্তোলন","মাসিক মোট উত্তোলন","মাসিক স্থিতি","FD জমা","FD মোট জমা ","FD উত্তোলন ","FD মোট উত্তোলন ","FD  স্থিতি ","মোট জমা স্থিতি  ","মোট উত্তোলন স্থিতি ","মোট স্থিতি ","সাক্ষর","শাখা কোড "].map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.date}</td> 
                                        <td>{info.gl_deposit}</td> 
                                        <td>{info.gl_weekly_total_deposit}</td> 
                                        <td>{info.gl_weekly_withdrawal}</td> 
                                        <td>{info.gl_weekly_total_withdrawal}</td> 
                                        <td>{info.gl_weekly_status}</td> 
                                        <td>{info.gl_monthly_deposit}</td> 
                                        <td>{info.gl_monthly_total_deposit}</td> 
                                        <td>{info.gl_monthly_withdrawal}</td> 
                                        <td>{info.gl_monthly_total_withdrawal}</td> 
                                        <td>{info.gl_monthly_status}</td> 
                                        <td>{info.gl_fd_deposit}</td> 
                                        <td>{info.gl_fd_total_deposit}</td> 
                                        <td>{info.gl_fd_withdrawal}</td> 
                                        <td>{info.gl_fd_total_withdrawal}</td> 
                                        <td>{info.gl_fd_status}</td> 
                                        <td>{info.gl_total_savings_status}</td> 
                                        <td>{info.gl_total_withdrawal_status}</td> 
                                        <td>{info.gl_total_status }</td>  
                                        <td>{info.gl_signature }</td>  
                                        <td>{info.branch_code}</td>  
                                        {loggedInUser.admin_level==='01'?<span><button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button><Link to={`/glupdate/${info.id_find}`}><button className='btn btn-warning btn-sm mr-1'>UPDATE</button></Link></span>:''}  
                                        
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}
        </div>
        
    );
};

export default GL;