import axios from 'axios';
import React, { useEffect } from 'react';
import { useState } from 'react';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './ContactUs.scss'

const ContactUs = () => {
    const [contact, setContact] = useState([]);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    }); 

    // document.title = 'আমাদের শাখাসমূহ'

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getallcontactinfo')
        .then(res => {  

            
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        setContact(res.data.successResult);
                    }, 800); 
            }, 800);


        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])
 

    return (
         
        <div> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
            msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
            msg={ServerResult.faildMesssage}/> : ""}

            <div className='services__container'> 
            <div className="tittle__container py-4">
                 <h3>{/**OUR BRANCHES*/}আমাদের শাখা সমূহ </h3>
            </div>
            {contact.length? 
            <div className="contact__us__container">

                {
                    contact.map(info => {
                        return  <div className="contact__us mr-1" key={info.id_find}>  
                        <h5> {info.name} <br /> শাখা :  {info.branch} <br />শাখা কোড : {info.branch_code} <br />ঠিকানা : <small>{info.address}</small> <br />মোবাইল : <small>{info.mobile}</small> <br /> Email : <small>{info.email}</small></h5>
                       
                        
                    </div>
                    })
                }
                
            </div>:""}
        </div> 
        </div> 
    );
};

export default ContactUs;