import axios from 'axios';
import React from 'react';

const UploadFile = () => {

    const handleGo = () => {
        axios.get('https://www.md-sohidul-islam.com/getalldata',{
            params:{
                code:']42T3a2cP&p?m3Fg',
                database:'admin'
            }
        }).then(res => {
            //console.log(res);
        }).catch(err => {
            //console.log(err.message);
        })
    }


    return (
        <div>
            <h1>Hello world</h1>
            <button onClick={handleGo}>Get all data</button>
        </div>
    );
};

export default UploadFile;