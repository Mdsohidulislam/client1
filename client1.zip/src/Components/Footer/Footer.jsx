
import React from 'react';
import { NavLink } from 'react-router-dom';
// import { NavLink } from 'react-router-dom';
// import { logoFooter } from '../Databese';
// import {logos} from '../../documents'

import './Footer.scss'
const Footer = () => {
    let date = new Date().getFullYear(); 


    return (

        <div className='footer_container'>
        <div className="container d-flex justify-content-space-around  flex-wrap py-5">
            <div className="half col-12 col-md-4 col-lg-6"> 
                <img  src='/favicon.ico' alt=''></img>  
                <p><b>চলবো মোরা একসাথে, <br /> জয় করবো মানবতাকে ।</b></p>
            </div>
            <div className="infos col-12 col-md-4 col-lg-3 p-3">
                
                <NavLink activeClassName='navLinkActive' to='/' className='text-decoration-none text-white'><p>Home</p></NavLink>
                <NavLink activeClassName='navLinkActive' to='/ourservices' className='text-decoration-none text-white'><p>Our Services</p></NavLink>
                <NavLink activeClassName='navLinkActive' to='/aboutus' className='text-decoration-none text-white'><p>About Us</p> </NavLink>
                <NavLink activeClassName='navLinkActive' to='/contactus' className='text-decoration-none text-white'><p>Contact Us</p></NavLink>
                 
            </div>
            <div className="contact col-12 col-md-4 col-lg-3  p-3">
                <NavLink activeClassName='navLinkActive' to='/checkpassbook' className='text-decoration-none text-white'><p>Check Passbook</p></NavLink>
                <NavLink activeClassName='navLinkActive' to='/notice' className='text-decoration-none text-white'> <p>Notice</p></NavLink>
                <NavLink activeClassName='navLinkActive' to='/profile' className='text-decoration-none text-white'><p>Login/Profile</p></NavLink>
                <NavLink activeClassName='navLinkActive' to='/' className='text-decoration-none text-white'> <p>Read FAQs</p></NavLink>

                
               
                
               
            </div>
        </div>
        <div className="footer  container-fluid d-flex flex-wrap">
            <div className="copyright col-12 col-md-6">
                <p style={{color:'#015E31'}}>copyright© {date} BondhuShotota Business Limited all rights reserved.</p>
            </div>
            <div className="privacy col-12 col-md-6 d-flex justify-content-center">
                <p className='pl-3'>Privacy Policy</p>
                <p className='pl-3'>Terms of Use</p> 
            </div>
        </div>
    </div>
    
    );
};

export default Footer;