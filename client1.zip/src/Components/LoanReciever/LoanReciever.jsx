
import axios from 'axios';
import React from 'react';
import { useEffect } from 'react';
import { useContext } from 'react';
import { useState } from 'react';
import { UserContext } from '../../App';
import '../Form.scss'
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const LoanReciever = () => {

    const [loanRecieverInfo, setLoanRecieverInfo] = useState({});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true);
    const [openTable, setOpenTable] = useState(false);
    const [accountInfo ,setAccountInfo] = useState([]);
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })

    const handleBlur = (e) => { 
        const newInfo = {...loanRecieverInfo};
        newInfo[e.target.name]=e.target.value;
        setLoanRecieverInfo(newInfo);
    };

    loanRecieverInfo.branch_code=loggedInUser.branch_code;
    
    if(loanRecieverInfo.lr_date){
        let date = loanRecieverInfo.lr_date;
        loanRecieverInfo.month = date.slice(5,7);
        loanRecieverInfo.day = date.slice(8,10);
        loanRecieverInfo.year = date.slice(0,4)  
    }

    const handleBlurAccount = (e) => { 
        loanRecieverInfo.lr_accountNo=loggedInUser.branch_code+e.target.value;
    }
    
    
    const handleSubmitLoanReciever = (e) => { 
        e.preventDefault();

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.post('https://www.md-sohidul-islam.com/loanreciever', {
                info: loanRecieverInfo
    }).then(response => {  
        
        setTimeout(() => {    
            setClear(!Clear);

            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo); 
                    setClear(true)
                }, 3000); 
        }, 3000);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
        
    }

    useEffect(()=>{
        axios.get('https://www.md-sohidul-islam.com/getallloanrecieverbybranchcode',{
            params:{
                code: loggedInUser.branch_code
            }
        }).then(res => { 
            setAccountInfo(res.data.successResult);
        }).catch(err => {
            ////console.log(err.message);
        })
    })

    const handleDeleteAccess =(id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    const handleLoanRecieverDelete = () => {

        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:"loanreciever"
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   

                        document.getElementById(`${deleteNumber}`).style.display='none'
                        

                    }, 800); 
            }, 800);


        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    return (
        <div style={{backgroundColor:'#015e31'}}>

{deleteState? 
        <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleLoanRecieverDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}


            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}
              <p className='text-center text-white pt-2'><b>Name</b>: {loggedInUser.first_name} <b>Email</b>: {loggedInUser.second_email} <b>শাখা কোড </b>: {loggedInUser.branch_code}</p>
            {Clear? 
            
            <div className='form__container text-center'> 
            <form onSubmit={handleSubmitLoanReciever}>

                
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="ঝণ নং"
                    name='lr_debtNo'
                    type="number"
                    required
                    
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="সদস্যের নাম"
                    name='lr_memberName'
                    type="text"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlurAccount}
                    placeholder="হিসাব নং"
                    name='lr_accountNo'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur} 
                    type='date' 
                    name='lr_date'
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="বিনিয়োগ"
                    name='lr_investment'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="সার্ভিস চার্জ"
                    name='lr_serviceCharge'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="মোট বিনিয়োগ"
                    name='lr_totalInvestment'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="ঋণ ফি"
                    name='lr_loanFees'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="মোট ঋণ ফি"
                    name='lr_totalLoanFees'
                    type="number"
                    required
                />  
                {/* { ["শাখা কোড ","ঝণ নং","সদস্যের নাম","হিসাব নং","date","বিনিয়োগ","সার্ভিস চার্জ","মোট বিনিয়োগ","ঋণ ফি","মোট ঋণ ফি","ফরম ফি","মোট ফরম ফি","বীমা","মোট বীমা","বিবিধ","মোট বিবিধ","কর্মীর সাক্ষর","ঋন গ্রহীতার সাক্ষর","গ্যারেন্টারের সাক্ষর"] } */}

                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="ফরম ফি"
                    name='lr_formFee'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="মোট ফরম ফি"
                    name='lr_totalFormFee'
                    type="number"
                    required
                />  
                <input  
                    className='input '
                    onBlur={handleBlur}
                    placeholder="বীমা"
                    name='lr_insurance'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="মোট বীমা"
                    name='lr_totalInsurance'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="বিবিধ"
                    name='lr_miscellaneous'
                    type="number"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="মোট বিবিধ"
                    type="number"
                    name='lr_totalMiscellaneous'
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="কর্মীর সাক্ষর"
                    name='lr_employeeSignature'
                    type="text"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="ঋন গ্রহীতার সাক্ষর"
                    name='lr_signatureOfTheBorrower'
                    type="text"
                    required
                />  
                <input 
                    className='input '
                    onBlur={handleBlur}
                    placeholder="গ্যারেন্টারের সাক্ষর"
                    name='lr_signatureOfGuarantor'
                    type="text"
                    required
                />    
                <input type="submit" value="Submit" className='submit__button' />
            </form> 
            <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>
        </div>
            
        :""}
{openTable? 

<table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                             ["শাখা কোড ","ঝণ নং","সদস্যের নাম","হিসাব নং","date","বিনিয়োগ","সার্ভিস চার্জ","মোট বিনিয়োগ","ঋণ ফি","মোট ঋণ ফি","ফরম ফি","মোট ফরম ফি","বীমা","মোট বীমা","বিবিধ","মোট বিবিধ","কর্মীর সাক্ষর","ঋন গ্রহীতার সাক্ষর","গ্যারেন্টারের সাক্ষর"].map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.branch_code}</td> 
                                        <td>{info.lr_debtNo}</td> 
                                        <td>{info.lr_memberName}</td> 
                                        <td>{info.lr_accountNo}</td> 
                                        <td>{info.lr_date}</td> 
                                        <td>{info.lr_investment}</td> 
                                        <td>{info.lr_serviceCharge}</td> 
                                        <td>{info.lr_totalInvestment}</td> 
                                        <td>{info.lr_loanFees}</td> 
                                        <td>{info.lr_totalLoanFees}</td> 
                                        <td>{info.lr_formFee}</td> 
                                        <td>{info.lr_totalFormFee}</td> 
                                        <td>{info.lr_insurance}</td> 
                                        <td>{info.lr_totalInsurance}</td> 
                                        <td>{info.lr_miscellaneous}</td> 
                                        <td>{info.lr_totalMiscellaneous}</td> 
                                        <td>{info.lr_employeeSignature}</td> 
                                        <td>{info.lr_signatureOfTheBorrower}</td> 
                                        <td>{info.lr_signatureOfGuarantor }</td>  
                                        {loggedInUser.admin_level==='01'?<button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button>:""}  
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}

        </div>
    );
}; 									
export default LoanReciever;


 

 
 
 
 

 
 
 
 


 
 
 