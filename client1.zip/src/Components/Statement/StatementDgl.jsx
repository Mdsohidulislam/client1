import axios from 'axios';
import React, { useEffect, useState } from 'react';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import Statement from './Statement';

const StatementDgl = () => {
    const [accountInfo, setAccountInfo] = useState([]);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getalldata',{
            params:{
                code:']42T3a2cP&p?m3Fg',
                database:'dgl'
            }
        })
        .then(res => { 
            //console.log(res);
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        setAccountInfo(res.data.successResult); 
                    }, 800); 
            }, 800); 

        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    },[])


    return (
        <div>
            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}

            <Statement/> 
            <div className='bg-dark text-white py-5'>
                <h1>Hello passbook statement</h1>
            </div> 
        </div>
    );
};

export default StatementDgl;