import React from 'react';
import { NavLink } from 'react-router-dom';

const Statement = () => {
    return (
        <div> 
        <div className='web__settings__container'> 
            <div className="web__settings__nav__link">
                <NavLink activeClassName='li__active' to = '/statementpassbook' className='link notice__active'>
                    <li>PASSBOOK</li>
                </NavLink> 
                <NavLink activeClassName='li__active' to = '/statementloanexchange' className='link contact__active'>
                    <li>LOAN EXCHANGE</li>
                </NavLink> 
                <NavLink activeClassName='li__active' to = '/statementloanreciever' className='link service__active'>
                    <li>LOAN RECIEVER</li>
                </NavLink> 
                <NavLink activeClassName='li__active' to = '/statementgl' className='link service__active'>
                    <li>GL</li>
                </NavLink>  
                <NavLink activeClassName='li__active' to = '/statementdglresult' className='link service__active'>
                    <li>DGL RESULT</li>
                </NavLink>  
                <NavLink activeClassName='li__active' to = '/statementdgl' className='link service__active'>
                    <li>DGL</li>
                </NavLink> 
            </div> 
        </div>
        </div>
    );
};

export default Statement;