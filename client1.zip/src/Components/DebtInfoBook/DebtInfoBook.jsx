import axios from 'axios';
import React, { useState } from 'react';
import { useEffect } from 'react';
import { useContext } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { UserContext } from '../../App';
import '../Form.scss';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';


const DebtInfoBook = () => {

    const [IsOpen, setIsOpen] = useState({

                        d_total_debt_collection: false,
                        d_total_debt_status: false,
                        d_total_loan_disbursement: false,
                        d_total_service_charge: false,      
                        m_total_debt_collection: false,
                        m_total_debt_status: false,
                        m_total_loan_disbursement: false,
                        m_total_service_charge: false,    
                        sm_total_debt_collection: false,
                        sm_total_debt_status: false,
                        sm_total_loan_disbursement: false,
                        sm_total_service_charge: false,
                        total_debt_status: false,
                        w_total_debt_collection: false,
                        w_total_debt_status: false,
                        w_total_lending: false,
                        w_total_service_charge: false 
    
    })


    const [debtInfoBook, setDebtInfoBook] = useState({});
    const [newDebtInfoBook, setNewDebtInfoBook] = useState({})
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [Clear, setClear] = useState(true);
    const [debtInfo, setDebtInfo] = useState({});
    const [isStore, setIsStore] = useState(false);
    const [IsNew, setIsNew] = useState(false);
    const history = useHistory();
    const [openTable, setOpenTable] = useState(false);
    const [accountInfo, setAccountInfo] = useState([]);
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })

    useEffect(()=>{ 

        axios.get('https://www.md-sohidul-islam.com/getallloanexchangebybranchcode',{
            params:{ 
                code: loggedInUser.branch_code 
            }
        })
        .then(res => { 
            setAccountInfo(res.data.successResult);  
        }).catch(error => { 
            ////console.log(error.message);
            alert(error)
        });

    },[])

    

    const handleBlur = (e) => { 
        
        const newInfo = {...debtInfoBook};
        newInfo[e.target.name]=e.target.value;
        setDebtInfoBook(newInfo);    
    };
    
    const handleNewBlur = (e) => {
        let newInfo = {...newDebtInfoBook};
        newInfo[e.target.name] = e.target.value;
        setNewDebtInfoBook(newInfo)
    }

    let postObj = {};
    if(IsNew){
        postObj = newDebtInfoBook
    }else{
        postObj =debtInfoBook
    }
     

    

   

    const Sum = (para1, para2) => {
        return Number(para1)+Number(para2)
    }

    const TotalDebtStatus = (para1, para2, para3) => {
        return (Number(para1)+Number(para2))-Number(para3);
    }
      
    // w status start
    if(debtInfoBook.w_lending){ 
        let result = Sum(debtInfoBook.w_lending,debtInfo.w_total_lending); 
        debtInfoBook.w_total_lending=result;
        IsOpen.w_total_lending=true; 
    }else{
        debtInfoBook.w_total_lending='';
        IsOpen.w_total_lending=false;
    }
 
    if(debtInfoBook.w_service_charge){ 
        let result = Sum(debtInfoBook.w_service_charge,debtInfo.w_total_service_charge); 
        debtInfoBook.w_total_service_charge=result;
        IsOpen.w_total_service_charge=true;
    }else{
        debtInfoBook.w_total_service_charge='';
        IsOpen.w_total_service_charge=false;
    }
    
    if(debtInfoBook.w_debt_collection){ 
        let result = Sum(debtInfoBook.w_debt_collection,debtInfo.w_total_debt_collection); 
        debtInfoBook.w_total_debt_collection=result;
        IsOpen.w_total_debt_collection=true;
    }else{
        debtInfoBook.w_total_debt_collection='';
        IsOpen.w_total_debt_collection=false;
    }
    if(debtInfoBook.w_total_lending && debtInfoBook.w_total_service_charge && debtInfoBook.w_total_debt_collection){
        let result = TotalDebtStatus (debtInfoBook.w_total_lending, debtInfoBook.w_total_service_charge,debtInfoBook.w_total_debt_collection); 
        debtInfoBook.w_total_debt_status=result;
        IsOpen.w_total_debt_status = true;
    }else{
        debtInfoBook.w_total_debt_status='';
        IsOpen.w_total_debt_status = false;
    }
    // w status end


    // d status start
    if(debtInfoBook.d_lending){ 
        let result = Sum(debtInfoBook.d_lending,debtInfo.d_total_loan_disbursement); 
        debtInfoBook.d_total_loan_disbursement=result;
        IsOpen.d_total_loan_disbursement=true;
    }else{
        IsOpen.d_total_loan_disbursement=false;
        debtInfoBook.d_total_loan_disbursement='';
    }

    if(debtInfoBook.d_service_charge){ 
        let result = Sum(debtInfoBook.d_service_charge,debtInfo.d_total_service_charge); 
        debtInfoBook.d_total_service_charge=result;
        IsOpen.d_total_service_charge=true;
    }else{
        IsOpen.d_total_service_charge=false;
        debtInfoBook.d_total_service_charge='';
    } 

    if(debtInfoBook.d_debt_collection){
        let result = Sum(debtInfoBook.d_debt_collection,debtInfo.d_total_debt_collection); 
        debtInfoBook.d_total_debt_collection=result;
        IsOpen.d_total_debt_collection=true; 
    }else{
        IsOpen.d_total_debt_collection=false;
        debtInfoBook.d_total_debt_collection='';
    } 

    if(debtInfoBook.d_total_loan_disbursement && debtInfoBook.d_total_service_charge && debtInfoBook.d_total_debt_collection){
        let result = TotalDebtStatus (debtInfoBook.d_total_loan_disbursement, debtInfoBook.d_total_service_charge,debtInfoBook.d_total_debt_collection); 
        debtInfoBook.d_total_debt_status=result;
        IsOpen.d_total_debt_status = true; 
    }else{
        debtInfoBook.d_total_debt_status='';
        IsOpen.d_total_debt_status = false; 
    }
    // d status end 




    // m status start
    if(debtInfoBook.m_lending){ 
        let result = Sum(debtInfoBook.m_lending,debtInfo.m_total_loan_disbursement); 
        debtInfoBook.m_total_loan_disbursement=result;
        IsOpen.m_total_loan_disbursement=true;
    }else{
        IsOpen.m_total_loan_disbursement=false;
        debtInfoBook.m_total_loan_disbursement='';
    }
    if(debtInfoBook.m_service_charge){ 
        let result = Sum(debtInfoBook.m_service_charge,debtInfo.m_total_service_charge); 
        debtInfoBook.m_total_service_charge=result;
        IsOpen.m_total_service_charge=true;
    } else{
        IsOpen.m_total_service_charge=false;
        debtInfoBook.m_total_service_charge='';
    }
    if(debtInfoBook.m_debt_collection){ 
        let result = Sum(debtInfoBook.m_debt_collection,debtInfo.m_total_debt_collection); 
        debtInfoBook.m_total_debt_collection=result;
        IsOpen.m_total_debt_collection=true;
    } else{
        IsOpen.m_total_debt_collection=false;
        debtInfoBook.m_total_debt_collection='';
    }
    if(debtInfoBook.m_total_loan_disbursement && debtInfoBook.m_total_service_charge && debtInfoBook.m_total_debt_collection){
        let result = TotalDebtStatus (debtInfoBook.m_total_loan_disbursement, debtInfoBook.m_total_service_charge,debtInfoBook.m_total_debt_collection); 
        debtInfoBook.m_total_debt_status=result;
        IsOpen.m_total_debt_status = true;  
    }else{
        debtInfoBook.m_total_debt_status='';
        IsOpen.m_total_debt_status =false;
    }
    // m status end

    // sm status start
    if(debtInfoBook.sm_lending){ 
        let result = Sum(debtInfoBook.sm_lending,debtInfo.sm_total_loan_disbursement); 
        debtInfoBook.sm_total_loan_disbursement=result;
        IsOpen.sm_total_loan_disbursement=true;
    } else{
        IsOpen.sm_total_loan_disbursement=false;
        debtInfoBook.sm_total_loan_disbursement='';
    }
    if(debtInfoBook.sm_service_charge){  //this line working 
        let result = Sum(debtInfoBook.sm_service_charge,debtInfo.sm_total_service_charge); 
        debtInfoBook.sm_total_service_charge=result;
        IsOpen.sm_total_service_charge=true; 
        
    } else{
        IsOpen.sm_total_service_charge=false;
        debtInfoBook.sm_total_service_charge='';
    } 
    if(debtInfoBook.sm_debt_collection){ 
        let result = Sum(debtInfoBook.sm_debt_collection,debtInfo.sm_total_debt_collection); 
        debtInfoBook.sm_total_debt_collection=result;
        IsOpen.sm_total_debt_collection=true;
    }else{
        IsOpen.sm_total_debt_collection=false;
        debtInfoBook.sm_total_debt_collection='';
    } 

    if(debtInfoBook.sm_total_loan_disbursement && debtInfoBook.sm_total_service_charge && debtInfoBook.sm_total_debt_collection){
        let result = TotalDebtStatus (debtInfoBook.sm_total_loan_disbursement, debtInfoBook.sm_total_service_charge,debtInfoBook.sm_total_debt_collection); 
        debtInfoBook.sm_total_debt_status=result;
        IsOpen.sm_total_debt_status = true;  
    }else{
        debtInfoBook.sm_total_debt_status='';
        IsOpen.sm_total_debt_status = false;
    }
    if(debtInfoBook.w_total_debt_status &&debtInfoBook.d_total_debt_status &&debtInfoBook.m_total_debt_status &&debtInfoBook.sm_total_debt_status){
        let totalStatus = debtInfoBook.w_total_debt_status+debtInfoBook.d_total_debt_status+debtInfoBook.m_total_debt_status+debtInfoBook.sm_total_debt_status;
        debtInfoBook.total_debt_status=totalStatus; 
        IsOpen.total_debt_status=true;
    }else{
        IsOpen.total_debt_status=false;
        debtInfoBook.total_debt_status='';
    }
    // sm status end
 
    if(debtInfoBook.date){
        let date = debtInfoBook.date;
        debtInfoBook.month = date.slice(5,7);
        debtInfoBook.day = date.slice(8,10);
        debtInfoBook.year = date.slice(0,4)  
    }

    if(newDebtInfoBook.date){
        let date = newDebtInfoBook.date;
        newDebtInfoBook.month = date.slice(5,7);
        newDebtInfoBook.day = date.slice(8,10);
        newDebtInfoBook.year = date.slice(0,4)  
    }
    if(loggedInUser.isLoggedIn){
        newDebtInfoBook.branch_code=loggedInUser.branch_code;
        debtInfoBook.branch_code= loggedInUser.branch_code;
    }

    const handleDebtInfoDeleteAccess = (id) =>{
        setDeleteState(true);
        setDeleteNumber(id);
    }
    
    const handleDelete = (id) => {

        setDeleteState(false);
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);


        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:"debtinfobook"
            }
        })
        .then(res => {  

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    useEffect(()=>{
        axios.get('https://www.md-sohidul-islam.com/getallonebranchdebtinfo',{
            params:{
                code: loggedInUser.branch_code
            }
       })
       .then(res => {  

           let resultLength = (res.data.successResult).length;  
           if(resultLength){ 
            setDebtInfo(res.data.successResult[resultLength-1]);
            setIsNew(false) 
           }if(resultLength === 0){   
            setIsNew(true);
           }
           
           setIsStore(true);  
       })
       .catch(error => {
           ////console.log(error);
           setIsStore(false)
       })
    },[]) 
    

    const handleDebtInfoBook = (e) => { 
 
        e.preventDefault();
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)


        axios.post('https://www.md-sohidul-islam.com/debtinfobook', {
                  info: postObj
        }).then(response => {  
        
            setTimeout(() => {    
                setClear(!Clear);
                setDebtInfoBook({});
                setIsStore(false)
                setClear(!Clear);
    
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data submitted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo); 
                        setClear(true)
                    }, 3000); 
            }, 3000);
        
            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message; 
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 3000);
            })
        
    }

 

    return (
        <div style={{backgroundColor:'#015e31'}}>
        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}
            <div className='py-2' style={{backgroundColor:'#e6e600',color:'#015e31'}}>
                <p className='text-center pt-2'><b>Name</b>: {loggedInUser.first_name} <b>Email</b>: {loggedInUser.second_email} <b>শাখা কোড </b>: {loggedInUser.branch_code}</p>
            </div>
            {Clear?  
            <div className='form__container text-center'>  
            {!IsNew?  
            <form onSubmit={handleDebtInfoBook}> 
                <input
                    className='input'
                    onBlur={handleBlur} 
                    type='date'
                    name='date'
                    required
                     
                /> 
                {/* [date, w ঋণ প্রদান, w মোট ঋণ প্রদান, w সার্ভিস চার্জ, w মোট সার্ভিস চার্জ, w ঋণ আদায়, w মোট ঋণ আদায় , w মোট ঋণ স্থিতি, d ঋণ প্রদান, d মোট ঋণ প্রদান, d সার্ভিস চার্জ, d মোট সার্ভিস চার্জ, d ঋণ আদায়, d মোট ঋণ আদায় , d মোট ঋণ স্থিতি,M ঋণ প্রদান, M মোট ঋণ প্রদান, M সার্ভিস চার্জ, M মোট সার্ভিস চার্জ, M ঋণ আদায়,M মোট ঋণ আদায় , M মোট ঋণ স্থিতি, SM ঋণ প্রদান, SM মোট ঋণ প্রদান, SM সার্ভিস চার্জ, SM মোট সার্ভিস চার্জ, SM ঋণ আদায়, SM মোট ঋণ আদায় , SM মোট ঋণ স্থিতি] */}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w ঋণ প্রদান"
                    type='number'
                    name='w_lending'
                    required
                     
                />  
                {IsOpen.w_total_lending? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w মোট ঋণ প্রদান"
                    type='number'
                    name='w_total_lending'
                    defaultValue={debtInfoBook.w_total_lending}
                    required
                    /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w সার্ভিস চার্জ "
                    type='number'
                    name='w_service_charge'
                    required
                     
                /> 
                {IsOpen.w_total_service_charge? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w মোট সার্ভিস চার্জ "
                    type='number'
                    name='w_total_service_charge'
                    defaultValue={debtInfoBook.w_total_service_charge}
                    required
                     
                /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w ঋণ আদায়"
                    type='number'
                    name='w_debt_collection'
                    required
                     
                /> 
                {IsOpen.w_total_debt_collection ? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w মোট ঋণ আদায় "
                    type='number'
                    name='w_total_debt_collection'
                    defaultValue={debtInfoBook.w_total_debt_collection}
                    required
                     
                /> 
                :""}
                {IsOpen.w_total_debt_status? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="w মোট ঋণ স্থিতি"
                    type='number'
                    name='w_total_debt_status'
                    defaultValue={debtInfoBook.w_total_debt_status}
                    required 
                /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D ঋণ প্রদান"
                    type='number'
                    name='d_lending'
                    required
                     
                /> 
                {IsOpen.d_total_loan_disbursement? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D মোট ঋণ প্রদান"
                    type='number'
                    name='d_total_loan_disbursement'
                    defaultValue={debtInfoBook.d_total_loan_disbursement}
                    required
                     
                /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D সার্ভিস চার্জ "
                    type='number'
                    name='d_service_charge'
                    required
                     
                /> 
                {IsOpen.d_total_service_charge? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D মোট সার্ভিস চার্জ "
                    type='number'
                    name='d_total_service_charge'
                    defaultValue={debtInfoBook.d_total_service_charge}
                    required
                     
                /> : ""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D ঋণ আদায়"
                    type='number'
                    name='d_debt_collection'
                    required
                     
                />  
                {IsOpen.d_total_debt_collection ? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D মোট ঋণ আদায়"
                    type='number'
                    name='d_total_debt_collection'
                    defaultValue={debtInfoBook.d_total_debt_collection}
                    required
                     
                /> :""}
                {IsOpen.d_total_debt_status? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="D মোট ঋণ স্থিতি"
                    type='number'
                    name='d_total_debt_status'
                    required
                    defaultValue={debtInfoBook.d_total_debt_status}
                />  :""}
                                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M ঋণ প্রদান"
                    type='number'
                    name='m_lending'
                    required
                     
                /> 
                {IsOpen.m_total_loan_disbursement? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M মোট  ঋণ প্রদান"
                    type='number'
                    name='m_total_loan_disbursement'
                    required 
                    defaultValue={debtInfoBook.m_total_loan_disbursement}
                /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M  সার্ভিস চার্জ"
                    type='number'
                    name='m_service_charge'
                    required
                     
                /> 
                {IsOpen.m_total_service_charge? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M মোট সার্ভিস চার্জ "
                    type='number'
                    name='m_total_service_charge'
                    required
                    defaultValue={debtInfoBook.m_total_service_charge}
                     
                /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M ঋণ আদায় "
                    type='number'
                    name='m_debt_collection'
                    required
                     
                /> 
                {IsOpen.m_total_debt_collection? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M মোট ঋণ আদায়"
                    type='number'
                    name='m_total_debt_collection'
                    required
                    defaultValue={debtInfoBook.m_total_debt_collection}
                     
                /> :""} 
                {IsOpen.m_total_debt_status ? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="M মোট ঋণ স্থিতি"
                    type='number'
                    name='m_total_debt_status'
                    required 
                    defaultValue={debtInfoBook.m_total_debt_status}
                />:""}
                                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM ঋণ প্রদান"
                    type='number'
                    name='sm_lending'
                    required
                     
                /> 
                {IsOpen.sm_total_loan_disbursement? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM মোট  ঋণ প্রদান"
                    type='number'
                    name='sm_total_loan_disbursement'
                    required
                    defaultValue={debtInfoBook.sm_total_loan_disbursement}
                     
                /> :""}
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM সার্ভিস চার্জ "
                    type='number'
                    name='sm_service_charge'
                    required
                     
                /> 
                {IsOpen.sm_total_service_charge ? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM মোট সার্ভিস চার্জ"
                    type='number'
                    name='sm_total_service_charge'
                    required
                    defaultValue={debtInfoBook.sm_total_service_charge} 
                /> :""}

                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM ঋণ আদায়"
                    type='number'
                    name='sm_debt_collection'
                    required
                     
                /> 
                {IsOpen.sm_total_debt_collection? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM মোট ঋণ আদায় "
                    type='number'
                    name='sm_total_debt_collection'
                    required
                    defaultValue={debtInfoBook.sm_total_debt_collection} 
                /> :""}
                {IsOpen.sm_total_debt_status? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="SM মোট ঋণ স্থিতি "
                    type='number'
                    name='sm_total_debt_status'
                    required
                    defaultValue={debtInfoBook.sm_total_debt_status}
                /> :""}
                {IsOpen.total_debt_status? 
                <input
                    className='input'
                    onBlur={handleBlur}
                    placeholder="মোট ঋণ স্থিতি "
                    type='number'
                    name='total_debt_status'
                    required
                    defaultValue={debtInfoBook.total_debt_status}
                /> :""}

                <input type="submit" value="submit" className='submit__button' /> 
                {/*  */}
                {/*  */}
                {/*  */}
                {/*  */}
                {/*  */}
                {/*  */}
                {/*  */}
                {/*  */}
            </form> : 
            <form onSubmit={handleDebtInfoBook}> 

                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="Phone"
                    type='date'
                    name='date'
                    required
                     
                /> 
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w ঋণ প্রদান"
                    type='number'
                    name='w_lending'
                    required
                     
                />   
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w মোট ঋণ প্রদান"
                    type='number'
                    name='w_total_lending' 
                    required
                    />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w সার্ভিস চার্জ "
                    type='number'
                    name='w_service_charge'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w মোট সার্ভিস চার্জ "
                    type='number'
                    name='w_total_service_charge' 
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w ঋণ আদায়"
                    type='number'
                    name='w_debt_collection'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w মোট ঋণ আদায় "
                    type='number'
                    name='w_total_debt_collection' 
                    required
                     
                /> 
                  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="w মোট ঋণ স্থিতি"
                    type='number'
                    name='w_total_debt_status' 
                    required 
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D ঋণ প্রদান"
                    type='number'
                    name='d_lending'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D মোট ঋণ প্রদান"
                    type='number'
                    name='d_total_loan_disbursement' 
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D সার্ভিস চার্জ "
                    type='number'
                    name='d_service_charge'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D মোট সার্ভিস চার্জ "
                    type='number'
                    name='d_total_service_charge' 
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D ঋণ আদায়"
                    type='number'
                    name='d_debt_collection'
                    required
                     
                />   
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D মোট ঋণ আদায়"
                    type='number'
                    name='d_total_debt_collection' 
                    required
                     
                />   
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="D মোট ঋণ স্থিতি"
                    type='number'
                    name='d_total_debt_status'
                    required 
                />   
                                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M ঋণ প্রদান"
                    type='number'
                    name='m_lending'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M মোট  ঋণ প্রদান"
                    type='number'
                    name='m_total_loan_disbursement'
                    required  
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M  সার্ভিস চার্জ"
                    type='number'
                    name='m_service_charge'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M মোট সার্ভিস চার্জ "
                    type='number'
                    name='m_total_service_charge'
                    required 
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M ঋণ আদায় "
                    type='number'
                    name='m_debt_collection'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M মোট ঋণ আদায়"
                    type='number'
                    name='m_total_debt_collection'
                    required 
                     
                />   
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="M মোট ঋণ স্থিতি"
                    type='number'
                    name='m_total_debt_status'
                    required  
                />
                                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM ঋণ প্রদান"
                    type='number'
                    name='sm_lending'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM মোট  ঋণ প্রদান"
                    type='number'
                    name='sm_total_loan_disbursement'
                    required 
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM সার্ভিস চার্জ "
                    type='number'
                    name='sm_service_charge'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM মোট সার্ভিস চার্জ"
                    type='number'
                    name='sm_total_service_charge'
                    required 
                />  

                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM ঋণ আদায়"
                    type='number'
                    name='sm_debt_collection'
                    required
                     
                />  
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM মোট ঋণ আদায় "
                    type='number'
                    name='sm_total_debt_collection'
                    required 
                />   
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="SM মোট ঋণ স্থিতি "
                    type='number'
                    name='sm_total_debt_status'
                    required 
                />   
                <input
                    className='input'
                    onBlur={handleNewBlur}
                    placeholder="মোট ঋণ স্থিতি "
                    type='number'
                    name='total_debt_status'
                    required 
                />  

                <input type="submit" value="submit" className='submit__button' />
            </form> }

            <button onClick={()=>setOpenTable(!openTable)} className='btn btn-outline-success text-center mt-3'>{openTable? "CLOSE TABLE":"SHOW TABLE"}</button>
 
        </div>
        
        : ""}
        {openTable? 
        <table className='table table-dark' style={{overflow:'scroll'}}>
                <thead>
                    <tr>
                        {
                            ['date', 'w ঋণ প্রদান', 'w মোট ঋণ প্রদান',' w সার্ভিস চার্জ', 'w মোট সার্ভিস চার্জ',' w ঋণ আদায়', 'w মোট ঋণ আদায়' , 'w মোট ঋণ স্থিতি', 'd ঋণ প্রদান', 'd মোট ঋণ প্রদান', 'd সার্ভিস চার্জ ', 'd মোট সার্ভিস চার্জ', 'd ঋণ আদায়', 'd মোট ঋণ আদায় ', 'd মোট ঋণ স্থিতি','M ঋণ প্রদান', 'M মোট ঋণ প্রদান', 'M সার্ভিস চার্জ', 'M মোট সার্ভিসচার্জ '  ,  'M ঋণ আদায়','M মোট ঋণ আদায়' , 'M মোট ঋণ স্থিতি', 'SM ঋণ প্রদান', 'SM মোট ঋণ প্রদান', 'SM সার্ভিস চার্জ', 'SM মোট সার্ভিস চার্জ', 'SM ঋণ আদায়', 'SM মোট ঋণ আদায়' , 'SM মোট ঋণ স্থিতি','মোট ঋণ স্থিতি'].map(data => {
                                return(<td key={data}>{data}</td>)
                            })                        
                        }
 
                    </tr> 
                </thead>
                 <tbody>
                   
                        {
                            accountInfo.map(info => {   
                                return(<tr key={info.id_find} id={`${info.id_find}`}>
                                        <td>{info.date}</td> 
                                        <td>{info.w_lending}</td> 
                                        <td>{info.w_total_lending}</td> 
                                        <td>{info.w_service_charge}</td> 
                                        <td>{info.w_total_service_charge}</td> 
                                        <td>{info.w_debt_collection}</td> 
                                        <td>{info.w_total_debt_collection}</td> 
                                        <td>{info.w_total_debt_status}</td> 
                                        <td>{info.d_lending}</td> 
                                        <td>{info.d_total_loan_disbursement}</td> 
                                        <td>{info.d_service_charge}</td> 
                                        <td>{info.d_total_service_charge}</td> 
                                        <td>{info.d_debt_collection}</td> 
                                        <td>{info.d_total_debt_collection}</td> 
                                        <td>{info.d_total_debt_status}</td> 
                                        <td>{info.m_lending}</td> 
                                        <td>{info.m_total_loan_disbursement}</td> 
                                        <td>{info.m_service_charge}</td> 
                                        <td>{info.m_total_service_charge }</td> 
                                        <td>{info.m_debt_collection}</td> 
                                        <td>{info.m_total_debt_collection}</td> 
                                        <td>{info.m_total_debt_status}</td> 
                                        <td>{info.sm_lending}</td> 
                                        <td>{info.sm_total_loan_disbursement}</td> 
                                        <td>{info.sm_service_charge}</td> 
                                        <td>{info.sm_total_service_charge}</td> 
                                        <td>{info.sm_debt_collection}</td> 
                                        <td>{info.sm_total_debt_collection}</td> 
                                        <td>{info.sm_total_debt_status}</td> 
                                        <td>{info.total_debt_status}</td>  
                                        {loggedInUser.admin_level==='01'?<span><button onClick={()=>handleDebtInfoDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button> <Link to={`/loanexchangeupdate/${info.id_find}`}><button className='btn btn-warning btn-sm mr-1'>UPDATE</button></Link></span>:""} 
                                        
                                     </tr>)
                                     
                            })
                        } 

                    
                </tbody>
            </table>:""}
        </div>
    );
};

export default DebtInfoBook;

// setDebtInfo({ 
    // branch_code: "0",
    // d_debt_collection: "0",
    // d_lending: "0",
    // d_service_charge: "0",
    // d_total_debt_collection: "0",
    // d_total_debt_status: "0",
    // d_total_loan_disbursement: "0",
    // d_total_service_charge: "0",
    // date: "0",
    // day: "0",
    // id_find: 0,
    // m_debt_collection: "0",
    // m_lending: "0",
    // m_service_charge: "0",
    // m_total_debt_collection: "0",
    // m_total_debt_status: "0",
    // m_total_loan_disbursement: "0",
    // m_total_service_charge: "0",
    // month: "0",
    // sm_debt_collection: "0",
    // sm_lending: "0",
    // sm_service_charge: "0",
    // sm_total_debt_collection: "0",
    // sm_total_debt_status: "0",
    // sm_total_loan_disbursement: "0",
    // sm_total_service_charge: "0",
    // total_debt_status: "0",
    // w_debt_collection: "0",
    // w_lending: "0",
    // w_service_charge: "0",
    // w_total_debt_collection: "0",
    // w_total_debt_status: "0",
    // w_total_lending: "0",
    // w_total_service_charge: "0",
    // year: "0"
    // }); 