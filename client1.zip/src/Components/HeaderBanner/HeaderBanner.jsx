import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { useEffect } from 'react';
import axios from 'axios';
import { useState } from 'react';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import FaildResult from '../Loader/FaildResult';
const HeaderBanner = () => {
    const [prevCarousel, setPrevCarousel] = useState([]);
 

    useEffect(()=>{ 

 
  
        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'carousel'
            }
        })
        .then(res=> {   
            let currentNotice = res.data.successResult;
            setPrevCarousel(currentNotice);  
    
        }).catch(error => { 
            //console.log(error.message);
        })
    },[])

    return (
        <div className='mb-1'>
            <Carousel   showArrows={true} showIndicators={false} autoPlay={true} emulateTouch={true} infiniteLoop={true} interval={4000} stopOnHover={true} showThumbs={false}>
                {
                    prevCarousel.map((info)=> {
                        return <div key={info.id}>
                            <img src={`https://www.md-sohidul-islam.com${info.img__url}`}  alt="" />
                            <p className='legend' style={{backgroundColor:"#FBF002",color:"green"}}>{info.description}</p>
                        </div>
                    })
                } 
            </Carousel>
        </div>
    );
};

export default HeaderBanner;