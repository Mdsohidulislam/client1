import React from 'react';
import './Delete.scss';


const Delete = () => {
    return (
        <div className='delete__container__area'>
            <div className="message__containerr">
                <p>Do you want to delete this document?</p>
            </div>
            <div className="button__container">
                <button className='yes__button'>YES</button> 
                <button className='no__button'>NO</button>
            </div>
        </div>
    );
};

export default Delete;