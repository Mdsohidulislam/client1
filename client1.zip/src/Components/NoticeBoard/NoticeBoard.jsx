import axios from 'axios';
import React from 'react';
import { useEffect, useState } from 'react';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import { useContext } from 'react';
import { UserContext } from '../../App';

const NoticeBoard = () => {
    
    const [notices, setNotices] = useState([]);
    const [officeNotices, setofficeNotices] = useState([]);
    const [showOffice,setShowOffice] = useState(false) 
    const [loggedInUser, setLoggedInUser] = useContext(UserContext)
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });

        useEffect(()=>{ 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'officenotice'
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    
                        let currentNotice = res.data.successResult;
                        setofficeNotices(currentNotice); 
                    }, 800); 
            }, 800);

        })
        .catch(error => {
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])


    useEffect(()=>{ 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'notice'
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    
                        let currentNotice = res.data.successResult;
                        setNotices(currentNotice); 
                    }, 800); 
            }, 800);

        })
        .catch(error => {
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])

    return (
        <div>

                {ServerResult.loaderShow? <Loader/>:""}
                {ServerResult.successShow? <SuccessResult
                msg={ServerResult.successMessage}/>:""}
                {ServerResult.faildShow? <FaildResult
                msg={ServerResult.faildMesssage}/> : ""}

             <div className="notice__container container-fluid services__container">  

                <div className="tittle__container py-3">
                    <h3>বিজ্ঞপ্তিসমূহ</h3>
                </div>
                    {loggedInUser.isLoggedIn? <button className='notice__toggle__borad' onClick={()=>setShowOffice(!showOffice)}>{!showOffice?"SHOW OFFICE NOTICE":"SHOW GENERAL NOTICE"}</button>:""}
                    

                    {!showOffice? 
                    <div className='pb-3'>
                    {notices.map(info => {
                        return  <div key={info.id_find} className="container py-2 bg-white rounded  mb-2">
                                    <p><b> বন্ধুসততা  বিজনেস লিমিটেড (Head office)</b></p>
                                    <p title='dd/mm/yyyy'>{info.date}</p>
                                    <p className='text-danger'>{info.notice}</p>
                                </div>
                    })} </div>  :""} 
                    {showOffice? 
                    <div className='pb-3'>
                    {officeNotices.map(info => {
                        return  <div key={info.id_find} className="container py-2 bg-white rounded  mb-2">
                                    <p><b> বন্ধুসততা  বিজনেস লিমিটেড (Head office)</b></p>
                                    <p title='dd/mm/yyyy'>{info.date}</p>
                                    <p className='text-danger'>{info.notice}</p>
                                </div>
                    })}</div> :""}


                </div>

        </div>
    );
};

export default NoticeBoard;