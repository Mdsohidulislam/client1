import React from 'react';
import './NotFound.scss'

const NotFound = () => {
    return (
        <div className="not__found">
            <div className='notfound__container'> 
                <h1>404</h1>
                <h1>page not found</h1>
            </div>
        </div>
    );
};

export default NotFound;