import React from 'react'; 

const FaildResult = (props) => {
    return (
        <div className='faild__result'>
             {props.msg}
        </div>
    );
};

export default FaildResult;