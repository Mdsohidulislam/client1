import React from 'react';
import './Result.scss'

const SuccessResult = (props) => {
    return (
        <div className='result__container'>  
            {props.msg}
        </div>
    );
};

export default SuccessResult;