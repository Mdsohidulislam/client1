import React, { useContext } from 'react';
import { useState } from 'react';
import Spinner from 'react-loader-spinner'; 

const Loader = () => { 
 
    const SpinnerContainer = {  
        position: 'fixed', 
        width: '200px',
        height: '200px',
        overflow:'hidden',
        borderRadius: '200px',
        zIndex:'200',
        backgroundColor:'white',
        left:'50%',
        top:"50%",
        transform: `translate(-50%,-50%)`

    }

    const logoPosition = {
        position: 'absolute',
        top: '-3.5px',
        left: '0',
        width: '200px',
        height: '200px',
        borderRadius: '200px', 
    }
    return (
        <div  style={SpinnerContainer} title='loading'> 

            <Spinner 
            // type="TailSpin"
            type='TailSpin'
            color="#ff0066"
            height={200}
            width={200}
            timeout={6000000}
            
            
            >


            </Spinner>
            <img style={logoPosition} className='bg-inf' src='/logo.png' alt=''/>  
        </div>
    );
};

export default Loader;