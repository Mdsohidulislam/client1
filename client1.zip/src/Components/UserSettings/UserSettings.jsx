import React from 'react';
import { useContext } from 'react'; 
import './UserSetting.scss';
import {UserContext} from '../../App'
import '../Form.scss'
import { useState } from 'react';
import Loader from '../Loader/Loader';
import axios from 'axios';
import SuccessResult from '../Loader/SuccessResult';
import FaildResult from '../Loader/FaildResult';

const UserSettings = () => {

    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [updateInfo, setUpdateInfo] = useState({});  
    const [check, setCheck] = useState({
        name:true
    });
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [openLoader, setOpenLoader] = useState(false);

    const handleBlurUpdate = (e) => { 
        let newInfos = {...updateInfo};
        newInfos[e.target.name] = e.target.value;
        setUpdateInfo(newInfos);
        ////console.log(newInfos);
    }

    

    const handleOpenUpdateName = () => { 
        var password = prompt('Enter your password then change your username');
        if(password===loggedInUser.fourth_securityy){ 
            document.getElementById('update_name').style.cssText=`
                top:-45px;
                transition: .3s;
            ` 
            

        }else{
            alert('Wrong password')
        }
    }
    // let uName = updateInfo.first_name;
    // let uEmail  = updateInfo.second_email;
    // let uPhone = updateInfo.third_phone;
    // let uPassword = updateInfo.fourth_securityy;
    // const {first_name, second_email, third_phone, fourth_securityy}  = prevInfo;
    // var sql = `UPDATE admin SET (first_name = '${uName}' AND second_email = '${uEmail}' AND third_phone = '${uPhone}' AND fourth_securityy = '${uPassword}') WHERE (first_name = '${first_name}' AND second_email = '${second_email}' AND third_phone = '${third_phone}' AND fourth_securityy = '${fourth_securityy}' )`;

    const handleOpenUpdateEmail = () => { 
        var password = prompt('Enter your password then change your email');
        if(password===loggedInUser.fourth_securityy){ 
            document.getElementById('update_email').style.cssText=`
                top:-45px;
                transition: .3s;
            `
        }else{
            alert('Wrong password')
        }
    }

    const handleOpenUpdatePhone = () => { 
        var password = prompt('Enter your password then change your phone number');
        if(password===loggedInUser.fourth_securityy){ 
            document.getElementById('update_phone').style.cssText=`
                top:-45px;
                transition: .3s;
            `
        }else{
            alert('Wrong password')
        }
    }

    const handleOpenUpdatePassword = () => { 
        var password = prompt('Enter your old password then change your new password');
        if(password===loggedInUser.fourth_securityy){ 
            document.getElementById('update_password').style.cssText=`
                top:-45px;
                transition: .3s;
            `
        }else{
            alert('Wrong password')
        }
    }

    const handlePasswordUpdate = () => {
        let passWord = document.getElementById('password').value;
        let newInfos = {};
        if(passWord){ 
           newInfos = {...loggedInUser}
           newInfos.fourth_securityy=passWord; 
           
           let newInfo = {...ServerResult};
           newInfo.loaderShow=true;
           setServerResult(newInfo);
           

            axios.patch('https://www.md-sohidul-islam.com/updateadmin',{
                updateInfo:newInfos,  
            })
            .then(res => {  
                newInfos.fourth_securityy=passWord; 
                setLoggedInUser(newInfos); 

                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully password updated';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);  
                            document.getElementById('update_password').style.cssText=`
                            top: 45px;
                            transition: .3s;
                            `;
                            document.getElementById('password').value=''
                        }, 800); 
                }, 800);

            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message; 
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 3000);
            })
            
           setTimeout(() => {
            setOpenLoader(false);
           }, 1000);  
           
        }else{ 
            alert('Enter your new password then update')
        } 
        setUpdateInfo(newInfos);  
    }
    

    const handlePhoneUpdate = () => {
        let phone = document.getElementById('phone').value;
        let newInfos = {};
        if(phone){ 
           newInfos = {...loggedInUser}
           newInfos.third_phone=phone; 
           
           let newInfo = {...ServerResult};
           newInfo.loaderShow=true;
           setServerResult(newInfo);
           

            axios.patch('https://www.md-sohidul-islam.com/updateadmin',{
                updateInfo:newInfos,  
            })
            .then(res => {  
                newInfos.third_phone=phone; 
                setLoggedInUser(newInfos); 

                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully phone updated';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);  
                            document.getElementById('update_phone').style.cssText=`
                            top: 45px;
                            transition: .3s;
                            `;
                            document.getElementById('phone').value=''
                        }, 800); 
                }, 800);

            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message; 
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 3000);
            })
            
           
        }else{ 
            alert('Enter your new phone number then update')
        } 
        setUpdateInfo(newInfos);  
    }



    const handleEmailUpdate = () => {
        let email = document.getElementById('email').value;
        let newInfos = {};
        if(email){ 
           newInfos = {...loggedInUser}
           newInfos.second_email=email; 
           
           let newInfo = {...ServerResult};
           newInfo.loaderShow=true;
           setServerResult(newInfo);
           

            axios.patch('https://www.md-sohidul-islam.com/updateadmin',{
                updateInfo:newInfos,  
            })
            .then(res => {  
                newInfos.second_email=email; 
                setLoggedInUser(newInfos); 

                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully email updated';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);  
                            document.getElementById('update_email').style.cssText=`
                            top: 45px;
                            transition: .3s;
                            `;
                            document.getElementById('email').value=''
                        }, 800); 
                }, 800);

            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message; 
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 3000);
            })
            
           
        }else{ 
            alert('Enter your new email then update')
        } 
        setUpdateInfo(newInfos);  
    }

    const handleNameUpdate = () => {
        let name = document.getElementById('name').value;
        let newInfos = {};
        if(name){ 
           newInfos = {...loggedInUser}
           newInfos.first_name=name; 
           
           let newInfo = {...ServerResult};
           newInfo.loaderShow=true;
           setServerResult(newInfo);
           

            axios.patch('https://www.md-sohidul-islam.com/updateadmin',{
                updateInfo:newInfos,
            })
            .then(res => {  
                newInfos.first_name=name; 
                setLoggedInUser(newInfos); 

                setTimeout(() => {     
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=true;
                    newInfo.successMessage='Successfully name updated';
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult}; 
                            newInfo.successShow=false;
                            setServerResult(newInfo);  
                            document.getElementById('update_name').style.cssText=`
                            top: 45px;
                            transition: .3s;
                            `;
                            document.getElementById('name').value=''
                        }, 800); 
                }, 800);

            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message; 
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 3000);
            })
            
           
        }else{ 
            alert('Enter your new name then update')
        } 
        setUpdateInfo(newInfos);  
    }

 

    return (
        <div className='p-5 user__setting__container text-white p-5 my-2' style={{backgroundColor:'#015e31'}}> 

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}

            <div className="info__container mb-1">
                <p><b>Name</b> : {loggedInUser.first_name}</p>
                <button className='edit__button' onClick={handleOpenUpdateName}>change</button>
                <div className="update_name" id='update_name'>
                    <input type="text" placeholder='Enter your new name' name="name" id="name"/>
                    <button className='update__button' onClick={handleNameUpdate}>update</button>
                </div>
            </div>
            <div className="info__container mb-1">
                <p><b>Email</b> : {loggedInUser.second_email}</p>
                <button className='edit__button' onClick={handleOpenUpdateEmail}>change</button>
                <div className="update_name" id='update_email'>
                    <input type="text" placeholder='Enter your new email' name="email" id="email"/>
                    <button className='update__button' onClick={handleEmailUpdate}>update</button>
                </div>
            </div>
            <div className="info__container mb-1">
                <p><b>Phone</b> : {loggedInUser.third_phone}</p>
                <button className='edit__button' onClick={handleOpenUpdatePhone}>change</button>
                <div className="update_name" id='update_phone'>
                    <input type="text" placeholder='Enter your new phone number' name="phone" id="phone"/>
                    <button className='update__button' onClick={handlePhoneUpdate}>update</button>
                </div>
            </div>

            <div className="info__container mb-1">
                <p><b>Password</b> : **************</p>
                <button className='edit__button' onClick={handleOpenUpdatePassword}>change</button>
                <div className="update_name" id='update_password'>
                    <input type="text" placeholder='Enter your new password' name="password" id="password"/>
                    <button className='update__button' onClick={handlePasswordUpdate}>update</button>
                </div>
            </div>
        </div>
    );
};

export default UserSettings;


 