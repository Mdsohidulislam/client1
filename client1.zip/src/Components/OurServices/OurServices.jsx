 
import Services from './Services'; 
 
    // document.title = 'আমাদের সেবাসমূহ'

    const OurServices = () => {
    
    

    return (
        <div> 
            <Services/>
        </div>
    );
};

export default OurServices;