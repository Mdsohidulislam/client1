import axios from 'axios';
import React from 'react';
import { useContext } from 'react';
import { useState } from 'react';
import { UserContext } from '../../App';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './FooterForm.scss'

const FooterForm = () => {

    const [formInfo, setFromInfo] = useState({}); 
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    })

    const handleBlur = (e) => {
        let newInfo = {...formInfo};
        newInfo[e.target.name] = e.target.value;
        setFromInfo(newInfo);
        
    }
    formInfo.isView=false;
    let dbYear = new Date().getFullYear().toString();
    let dbMonth =new Date().getMonth()+1;
    let dbDay =  new Date().getDate().toString(); 
    formInfo.day=dbDay;
    formInfo.month=dbMonth.toString();
    formInfo.year=dbYear;
    formInfo.date=`${dbMonth}/${dbDay}/${dbYear}`; 
    formInfo.fullTime = new Date();


    const handleformSubmit = (e) => {
        e.preventDefault(); 
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.post('https://www.md-sohidul-islam.com/formInfo',{
            info:formInfo
        }).then(response => {  
 
                    setTimeout(() => {
                        let newInfo = {...ServerResult};
                        newInfo.loaderShow=false;
                        newInfo.successShow=true;
                        newInfo.successMessage='Successfully data submitted';
                        setServerResult(newInfo)   
                            setTimeout(() => { 
                                let newInfo = {...ServerResult}; 
                                newInfo.successShow=false;
                                setServerResult(newInfo);
                                document.getElementById('name').value=''
                                document.getElementById('email').value=''
                                document.getElementById('phone').value=''
                                document.getElementById('message').value=''
                            }, 3000); 
                    }, 3000);
                   
            }).catch(error => {  
                setTimeout(() => {
                    let newInfo = {...ServerResult};
                    newInfo.loaderShow=false;
                    newInfo.successShow=false;
                    newInfo.faildShow=true;
                    newInfo.faildMesssage=error.message 
                    setServerResult(newInfo)   
                        setTimeout(() => { 
                            let newInfo = {...ServerResult};  
                            newInfo.faildShow=false; 
                            setServerResult(newInfo)  
                        }, 3000); 
                }, 3000);
            })
    }
    
    

    return (
        <div className='footer__Form__container'>
                        {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult msg={ServerResult.faildMesssage}/> : ""}
            <div className="tittle__container">   
                <h3>LET US KNOW HOW <br/> WE <span className='tittle__coloring'>CAN IMPROVE <br/> OUR</span> SERVICE</h3> 
            </div>
            <div className="footer__form__container">
                <form onSubmit={handleformSubmit}>
                    <input onBlur={handleBlur} className='input' type="text" name='name' placeholder='Enter your name' id='name' required/>
                    <input onBlur={handleBlur} className='input' type="text" name='email' placeholder='Enter your email' id='email' required/>
                    <input onBlur={handleBlur} className='input' type="tel" name="phone" placeholder='Enter your phone number' id='phone' required/>
                    <textarea onBlur={handleBlur} name="message" placeholder='write here your opinion' id='message' required></textarea>
                    <input className='submit__button' type="submit" value="Submit" />
                </form>
            </div> 
        </div>
    );
};

export default FooterForm;