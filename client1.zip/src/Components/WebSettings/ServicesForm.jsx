import axios from 'axios';
import React, { useEffect } from 'react';
import { useState } from 'react'; 
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import Carousel from './Carousel'
import './ContactUsForm.scss'
import WebSettingsNav from './WebSettingsNav';
const ServicesForm = () => {
    const [serviceInfo, setServiceInfo] = useState({});
    const [services,setServices] = useState([]);
    const [showCarousel, setShowCarousel] = useState(false)
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);

    const handleBlur = (e) => {

        let newInfo = {...serviceInfo}
        newInfo[e.target.name] = e.target.value;
        setServiceInfo(newInfo);

    }
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });

    const handleServiceInfo = (e) => {
        e.preventDefault();

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.post('https://www.md-sohidul-islam.com/postservice',{
            info:serviceInfo
        }).then(res => {
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data submitted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById('service').value=''
                    }, 800); 
            }, 800);
        }).catch(error => {
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
        
    }

    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getallservice',{
            params:{
                code:']42T3a2cP&p?m3Fg'
            }
        })
        .then(res => {

            
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        setServices(res.data.successResult);
                    }, 800); 
            }, 800);

        }).catch(error => {
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])

    const handleDeleteAccess = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    const handleDelete = (id) => {

        setDeleteState(false);

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'services'
            }
        }).then(response => { 
            

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);  
                        document.getElementById(`${deleteNumber}`).style.display='none'
                    }, 800); 
            }, 800);

        }).catch(error => {  

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);

        })
    }

    return (
        <div className='web__settings__container mb-3 pb-2'>

        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}

            <WebSettingsNav/>
            <div className='container'>
                    <button className='notice__toggle' onClick={()=>setShowCarousel(!showCarousel)}>{!showCarousel?"SWITCH CAROUSEL":"SWITCH SERVICES"}</button>
            </div>
            {showCarousel? 
            <Carousel/>:
            <div>

                <div className='contact__us__form__container container'>
                    {ServerResult.loaderShow? <Loader/>:""}
                    {ServerResult.successShow? <SuccessResult
                    msg={ServerResult.successMessage}/>:""}
                    {ServerResult.faildShow? <FaildResult
                    msg={ServerResult.faildMesssage}/> : ""}
                    <h4>Add service.....</h4>
                    <form onSubmit={handleServiceInfo}>
                        <input onBlur={handleBlur} type="text" className='input' placeholder='Service' name="service" id="service" required/> 

                        <input onBlur={handleBlur} type="submit" className="submit__button" />
                    </form>
                </div>
                {services.length? 
                <div className="services__container"> 
                    {
                        services.map(info => {
                            return<div className="bg-light m-2 rounded p-2" key={info.id_find} id={info.id_find}>   
                                        <h5>{info.service}</h5> 
                                        <button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger btn-sm mr-1'>delete</button>
                                </div>
                        })
                    } 
            
    
                </div>:""}
                
            </div>}
        </div>
    );
};

export default ServicesForm;