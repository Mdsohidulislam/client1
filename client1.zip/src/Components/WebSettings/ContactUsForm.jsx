
import axios from 'axios';
import React, { useEffect } from 'react';
import { useState } from 'react';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import './ContactUsForm.scss'
import './WebSettings.scss'
import WebSettingsNav from './WebSettingsNav';

const ContactUsForm = () => {

    const [contactInfo, setContactInfo] = useState({});
    const [prevInfo, setPrevInfo] = useState([]);
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [notice, setNotice]  = useState([]);
    const [showOffice,setShowOffice] = useState(false)
    const [deleteState, setDeleteState] = useState(false);
    const [deleteStateAboutUs, setDeleteStateAboutUs] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [noticeInfo, setNoticeInfo] = useState({});
    const handleBlur = (e) => {
        
        let newInfo = {...contactInfo};
        newInfo[e.target.name] = e.target.value;
        setContactInfo(newInfo) ;
        
    }
    
    const handleNoticeBlur = (e) => {
        let newInfo = {...noticeInfo}
        newInfo[e.target.name]=e.target.value; 
        setNoticeInfo(newInfo); 
        
    } 

    const  handleNoticeFormSubmit = (e) => {
        e.preventDefault();
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);
        
        axios.post('https://www.md-sohidul-islam.com/postaboutus',{            
            info:noticeInfo,
            
        },).then(response => {   

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data submitted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        document.getElementById('aboutus').value='' 
                    }, 800); 
            }, 800);


        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }   


    useEffect(()=>{

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.get('https://www.md-sohidul-islam.com/getallcontactinfo')
        .then(res=> {
            //console.log(res);
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    

                        let currentNotice = res.data.successResult;
                        setPrevInfo(currentNotice);  

                    }, 800); 
            }, 800);

  
        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])

    useEffect(()=>{ 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo); 

        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'aboutus'
            }
        })
        .then(res=> {

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    

                        let currentNotice = res.data.successResult;
                        setNotice(currentNotice);  

                    }, 800); 
            }, 800); 
        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])


    const handleContactFormSubmit = (e) => {
        e.preventDefault(); 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo)

        axios.post('https://www.md-sohidul-islam.com/contactinfo', {
                info: contactInfo
    }).then(response => {  
        
        setTimeout(() => {      
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully data submitted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo);  
                    /** name branch branch_code address mobile email*/
                    document.getElementById('name').value=''
                    document.getElementById('branch').value=''
                    document.getElementById('branch_code').value=''
                    document.getElementById('address').value=''
                    document.getElementById('mobile').value=''
                    document.getElementById('email').value=''
                }, 800); 
        }, 800);
    
        }).catch(error => {  
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        }) 

    }

    const handleDeleteAccess = (id) => {

        setDeleteState(true);
        setDeleteNumber(id);

    }
    
    const handleDeleteAccessAboutUs = (id) => {
        setDeleteStateAboutUs(true);
        setDeleteNumber(id);
    }

    const handleDeleteAboutUs = () => {
        setDeleteStateAboutUs(false);
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'aboutus'
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    
                        document.getElementById(`${deleteNumber}`).style.display='none';
                    }, 800); 
            }, 800);

             

        }).catch(error => { 

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000); 
        })
    }

    const handleDelete = (id) => {   
        setDeleteState(false);
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'contactinfo'
            }
        })
        .then(res => { 

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    
                        document.getElementById(`${deleteNumber}`).style.display='none';
                    }, 800); 
            }, 800);

             

        }).catch(error => { 

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000); 
        })
    }
     

    return (
        <div className='web__settings__container'>
        {ServerResult.loaderShow? <Loader/>:""}
        {ServerResult.successShow? <SuccessResult
        msg={ServerResult.successMessage}/>:""}
        {ServerResult.faildShow? <FaildResult
        msg={ServerResult.faildMesssage}/> : ""}
        {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>
        :""}

        {deleteStateAboutUs? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDeleteAboutUs}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteStateAboutUs(false)}>NO</button>
                </div>
            </div>
        :""}    
            <WebSettingsNav/>
            <div className='container'>
            <button className='notice__toggle' onClick={()=>setShowOffice(!showOffice)}>{!showOffice?"SWITCH ABOUT US":"SWITCH CONTACT US"}</button>
            </div>
            {!showOffice? 
            <div>
            <div className='contact__us__form__container container'>
 
                <h4>Add branch prevInfo info.....</h4>
                <form onSubmit={handleContactFormSubmit}> 
                    
                    <input onBlur={handleBlur} type="text" className='input' placeholder='নাম' name="name" id="name" required/>
                    <input onBlur={handleBlur} type="text" className='input' placeholder='শাখা' name="branch" id="branch" required/>
                    <input onBlur={handleBlur} type="text" className='input' placeholder='শাখা কোড' name="branch_code" id="branch_code" required/>
                    <input onBlur={handleBlur} type="text" className='input' placeholder='ঠিকানা' name="address" id="address" required/>
                    <input onBlur={handleBlur} type="text" className='input' placeholder='মোবাইল' name="mobile" id="mobile" required/>
                    <input onBlur={handleBlur} type="text" className='input' placeholder='Email' name="email" id="email" required/>
                    <input onBlur={handleBlur} type="submit" className="submit__button" />
                </form>
            </div>
            <div className="container">
            <h4 className='container'>Your previous notice</h4>
            </div>
            {prevInfo.length? 
            <div className="contact__us__container container">

                {
                    prevInfo.map(info => {
                        return  <div className="contact__us m-2" key={info.id_find} id={info.id_find}>  
                        <h5> {info.name} <br /> শাখা :  {info.branch} <br />শাখা কোড : {info.branch_code} <br />ঠিকানা : <small>{info.address}</small> <br />মোবাইল : <small>{info.mobile}</small> <br /> Email : <small>{info.email}</small></h5>
                        <button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger mr-2'>delete</button>
                    </div>
                    })
                }
            </div>:""}
            </div>
            
            
            :
            
            
            <div className='container'>
            <div className="web__form__container "> 
                <h4>ABOUT US.....</h4> 
                <form onSubmit={handleNoticeFormSubmit}>   
                    <textarea onBlur={handleNoticeBlur} name="aboutus" placeholder='Write your about us description here....' id="aboutus"></textarea>
                    <input type="submit" id='inputbutton' value="Submit" className='web__settings__button'/>
                </form> 
            </div>  

            <div className="prev__notice__container">
                <h4>Your previous about us description.....</h4> 
                    {
                        notice.map(info =>{
                            ////console.log(info);
                            return(<div key={info.id_find} id={info.id_find} className='mb-2'>
                                 <p>{info.aboutus}</p>
                                 <button onClick={()=>handleDeleteAccessAboutUs(info.id_find)} className='btn btn-danger mr-2'>delete</button> 
                            </div>)
                        })
                    } 
            </div>
        </div>

            
            
            }

        </div>
    );
};

export default ContactUsForm;