import React, { useEffect } from 'react';
import axios from 'axios';
import { useState } from 'react';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import FaildResult from '../Loader/FaildResult';

const Carousel = () => {

    const [file, setFile] = useState(null);
    const [description, setDescription]  = useState({});
    const [prevCarousel, setPrevCarousel] = useState([]);
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);

    const [ServerResult, setServerResult] = useState({
      successShow:false,
      faildShow:false,
      loaderShow:false,
      successMessage:'',
      faildMesssage:''
  });

  const handleDeleteAccess = (id) => {
    setDeleteState(true);
    setDeleteNumber(id);
  }

  const handleDelete = (id) => {   

    setDeleteState(false);

    let newInfo = {...ServerResult};
    newInfo.loaderShow=true;
    setServerResult(newInfo);

    axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
        params:{
            database:'carousel'
        }
    })
    .then(res => { 
        //console.log(res);
        setTimeout(() => {     
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully carousel deleted';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo);    
                    document.getElementById(`${deleteNumber}`).style.display='none';
                }, 800); 
        }, 800);

         

    }).catch(error => { 

        setTimeout(() => {
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=false;
            newInfo.faildShow=true;
            newInfo.faildMesssage=error.message; 
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult};  
                    newInfo.faildShow=false; 
                    setServerResult(newInfo)  
                }, 3000); 
        }, 3000); 
    })
}
 

    
    const handleBlur = (e) => {
      let newInfo = {...description};
      newInfo[e.target.name] = e.target.value;
      setDescription(newInfo);
    }
    
    useEffect(()=>{ 

      let newInfo = {...ServerResult};
      newInfo.loaderShow=true;
      setServerResult(newInfo); 

      axios.get('https://www.md-sohidul-islam.com/getallnotice',{
          params:{
              database:'carousel'
          }
      })
      .then(res=> {
        //console.log(res);
          setTimeout(() => {     
              let newInfo = {...ServerResult};
              newInfo.loaderShow=false;
              newInfo.successShow=true;
              newInfo.successMessage='Successfully data loaded';
              setServerResult(newInfo)   
                  setTimeout(() => { 
                      let newInfo = {...ServerResult}; 
                      newInfo.successShow=false;
                      setServerResult(newInfo);    

                      let currentNotice = res.data.successResult;
                      setPrevCarousel(currentNotice);  

                  }, 800); 
          }, 800); 
      }).catch(error => { 
          setTimeout(() => {
              let newInfo = {...ServerResult};
              newInfo.loaderShow=false;
              newInfo.successShow=false;
              newInfo.faildShow=true;
              newInfo.faildMesssage=error.message; 
              setServerResult(newInfo)   
                  setTimeout(() => { 
                      let newInfo = {...ServerResult};  
                      newInfo.faildShow=false; 
                      setServerResult(newInfo)  
                  }, 3000); 
          }, 3000);
      })
  },[])

    const handleCarouselImgSubmit = (e) => {
      e.preventDefault();

      let newInfo = {...ServerResult};
      newInfo.loaderShow=true;
      setServerResult(newInfo);
      
      let formData = new FormData();
      formData.append('file',file);
      formData.append('description', description.carousel__description);
  
      axios.post('https://www.md-sohidul-islam.com/postcarousel',formData, { 
  
          headers: {
              "Content-Type": "multipart/form-data",
            }
      
      }).then(res => {
        setTimeout(() => {     
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=true;
            newInfo.successMessage='Successfully image uploaded';
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult}; 
                    newInfo.successShow=false;
                    setServerResult(newInfo);   

                    document.getElementById('carousel__description').value=''
                    document.getElementById('img__carousel').value=null

                }, 800); 
        }, 800);
    }).catch(error => {
        setTimeout(() => {
            let newInfo = {...ServerResult};
            newInfo.loaderShow=false;
            newInfo.successShow=false;
            newInfo.faildShow=true;
            newInfo.faildMesssage=error.message; 
            setServerResult(newInfo)   
                setTimeout(() => { 
                    let newInfo = {...ServerResult};  
                    newInfo.faildShow=false; 
                    setServerResult(newInfo)  
                }, 3000); 
        }, 3000);
    }) 
    }

    return ( 
            
            <div className='bg-dark carousel__upload__container__first container-fluid'> 



              {deleteState? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>:""}


                {ServerResult.loaderShow? <Loader/>:""}
                {ServerResult.successShow? <SuccessResult
                msg={ServerResult.successMessage}/>:""}
                {ServerResult.faildShow? <FaildResult
                msg={ServerResult.faildMesssage}/> : ""}

                <div className='carousel__upload__container__second'>
                    <div className='carousel__upload__container__third'>
                      <form className='' onSubmit={handleCarouselImgSubmit}>
                          <input type='file' name='img__carousel' className='img__carousel' id='img__carousel' onChange={(e)=>setFile(e.target.files[0])} required></input>
                          <textarea type='text' placeholder='Enter here your carousel image description' name='carousel__description' className='carousel__description' id='carousel__description' onBlur={handleBlur} required></textarea>
                          <input type='submit' value='UPLOAD' className='carousel__img__submit__button'/>
                      </form>
                    </div>
                    {prevCarousel.length? 
                    <div className='prev__carousel__container'>
                          <h4>Your previous carousel</h4>
                          {prevCarousel.map((info)=> {
                            return<div className='my-2 prev__carousel__img__container' key={info.id_find} id={info.id_find}>
                                      <img src={`https://www.md-sohidul-islam.com${info.img__url}`} alt="" className="prev__img" />
                                      <p className="prev__description">{info.description}</p>
                                      <button className='btn btn-danger delete__button'onClick={()=>handleDeleteAccess(info.id_find)}>delete</button>
                                  </div>
                          })} 
                    </div>:""}
                </div>  
            </div>
   
    );
};

export default Carousel;