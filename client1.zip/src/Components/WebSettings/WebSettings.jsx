import axios from 'axios';
import React, { useEffect } from 'react';  
import { useState } from 'react';
import { Link, NavLink, useHistory, useLocation } from 'react-router-dom';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';
import ContactUsForm from './ContactUsForm';
import NoticeForm from './NoticeForm';
import ServicesForm from './ServicesForm';
import './WebSettings.scss'
import WebSettingsNav from './WebSettingsNav';


const WebSettings = () => {

    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
 
    

    return (
        <div className='web__settings__container bg-dark'> 

        {ServerResult.loaderShow? <Loader/>:""}
        {ServerResult.successShow? <SuccessResult
        msg={ServerResult.successMessage}/>:""}
        {ServerResult.faildShow? <FaildResult
        msg={ServerResult.faildMesssage}/> : ""}

            <WebSettingsNav/>
            <NoticeForm/>
            
        </div>
    );
};

export default WebSettings;