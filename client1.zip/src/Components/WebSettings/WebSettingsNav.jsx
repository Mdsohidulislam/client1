import React from 'react';
import { NavLink } from 'react-router-dom';

const WebSettingsNav = () => {
    return (
        <div className='web__settings__container'> 
            <div className="web__settings__nav__link">
                <NavLink activeClassName='li__active' to = '/websettings/notice' className='link notice__active'>
                    <li>NOTICE</li>
                </NavLink> 
                <NavLink activeClassName='li__active' to = '/websettings/contact' className='link contact__active'>
                    <li>CONTACT</li>
                </NavLink> 
                <NavLink activeClassName='li__active' to = '/websettings/service' className='link service__active'>
                    <li>SERVICE</li>
                </NavLink> 
            </div> 
        </div>
    );
};

export default WebSettingsNav;