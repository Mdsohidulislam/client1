import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useContext } from 'react';
import { UserContext } from '../../App';
import FaildResult from '../Loader/FaildResult';
import Loader from '../Loader/Loader';
import SuccessResult from '../Loader/SuccessResult';

const NoticeForm = () => {

    
    const [noticeInfo, setNoticeInfo] = useState({});
    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [notice, setNotice]  = useState([]);
    const [officeNotice, setOfficeNotice] = useState([]);
    const [showOffice,setShowOffice] = useState(false)
    const [ServerResult, setServerResult] = useState({
        successShow:false,
        faildShow:false,
        loaderShow:false,
        successMessage:'',
        faildMesssage:''
    });
    const [noticeClass, setNoticeClass] = useState(true);
    const [deleteState, setDeleteState] = useState(false);
    const [deleteNumber, setDeleteNumber] = useState(0);
    const [deleteStateOffice, setDeleteStateOffice] = useState(false);


    const handleNoticeBlur = (e) => {
        let newInfo = {...noticeInfo}
        newInfo[e.target.name]=e.target.value; 
        setNoticeInfo(newInfo); 
        
    } 
    let dbYear = new Date().getFullYear().toString();
    let dbMonth =new Date().getMonth()+1;
    let dbDay =  new Date().getDate().toString(); 
    noticeInfo.day=dbDay;
    noticeInfo.month=dbMonth.toString();
    noticeInfo.year=dbYear;
    noticeInfo.date=`${dbDay}/${dbMonth}/${dbYear}`; 
    noticeInfo.fullTime = new Date(); 

        useEffect(()=>{ 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo); 

        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'officenotice'
            }
        })
        .then(res=> {

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    

                        let currentNotice = res.data.successResult;
                        setOfficeNotice(currentNotice);  

                    }, 800); 
            }, 800); 
        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])

    useEffect(()=>{ 

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo); 

        axios.get('https://www.md-sohidul-islam.com/getallnotice',{
            params:{
                database:'notice'
            }
        })
        .then(res=> {

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data loaded';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    

                        let currentNotice = res.data.successResult;
                        setNotice(currentNotice);  

                    }, 800); 
            }, 800); 
        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    },[])

    const  handleOfficeNoticeFormSubmit = (e) => {
        e.preventDefault();
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        let officeNotice = document.getElementById('officenotice').value;
        let date = `${dbDay}/${dbMonth}/${dbYear}`
        let InfoData = {officeNotice,date}


        axios.post('https://www.md-sohidul-islam.com/marqueeofficenotice',{            
            info:InfoData,
            
        },).then(response => {  

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data submitted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        document.getElementById('officenotice').value='' 
                    }, 800); 
            }, 800);


        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }   

    const  handleNoticeFormSubmit = (e) => {
        e.preventDefault();
        
        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);
        
        axios.post('https://www.md-sohidul-islam.com/marqueenotice',{            
            info:noticeInfo,
            
        },).then(response => {  

            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data submitted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);   
                        document.getElementById('notice').value='' 
                    }, 800); 
            }, 800);


        }).catch(error => { 
            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000);
        })
    }   

    const handleDeleteAccess = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }

    
    const handleDeleteAccessOffice = (id) => {
        setDeleteState(true);
        setDeleteNumber(id);
    }


    const handleDelete = (id) => {   

        setDeleteState(false);

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'notice'
            }
        })
        .then(res => { 
            //console.log(res);
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    
                        document.getElementById(`${deleteNumber}`).style.display='none';
                    }, 800); 
            }, 800);

             

        }).catch(error => { 

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000); 
        })
    }
     
    
    const handleDeleteOffice = (id) => {   

        setDeleteState(false);

        let newInfo = {...ServerResult};
        newInfo.loaderShow=true;
        setServerResult(newInfo);

        axios.delete(`https://www.md-sohidul-islam.com/delete/${deleteNumber}`,{
            params:{
                database:'officenotice'
            }
        })
        .then(res => { 
            //console.log(res);
            setTimeout(() => {     
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=true;
                newInfo.successMessage='Successfully data deleted';
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult}; 
                        newInfo.successShow=false;
                        setServerResult(newInfo);    
                        document.getElementById(`${deleteNumber}`).style.display='none';
                    }, 800); 
            }, 800);

             

        }).catch(error => { 

            setTimeout(() => {
                let newInfo = {...ServerResult};
                newInfo.loaderShow=false;
                newInfo.successShow=false;
                newInfo.faildShow=true;
                newInfo.faildMesssage=error.message; 
                setServerResult(newInfo)   
                    setTimeout(() => { 
                        let newInfo = {...ServerResult};  
                        newInfo.faildShow=false; 
                        setServerResult(newInfo)  
                    }, 3000); 
            }, 3000); 
        })
    }





    return (
        <div>
        {deleteState? 
        <div>{!showOffice? 
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDelete}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteState(false)}>NO</button>
                </div>
            </div>:""}
            {showOffice?
            <div className='delete__container__area'>
                <div className="message__containerr">
                    <p>Do you want to delete this document?</p>
                </div>
                <div className="button__container">
                    <button className='yes__button'onClick={handleDeleteOffice}>YES</button> 
                    <button className='no__button' onClick={()=>setDeleteStateOffice(false)}>NO</button>
                </div>
            </div>:""}
        </div>
        :""}

            {ServerResult.loaderShow? <Loader/>:""}
            {ServerResult.successShow? <SuccessResult
             msg={ServerResult.successMessage}/>:""}
            {ServerResult.faildShow? <FaildResult
             msg={ServerResult.faildMesssage}/> : ""}
            <div className="marquee container"> 
                <button className='notice__toggle' onClick={()=>setShowOffice(!showOffice)}>{!showOffice?"SWITCH OFFICE NOTICE":"SWITCH GENERAL NOTICE"}</button>
            {!showOffice?

            <div>
                <div className="web__form__container "> 
                    <h4>GENERAL NOTICE.....</h4> 
                    <form onSubmit={handleNoticeFormSubmit}>   
                        <textarea onBlur={handleNoticeBlur} name="notice" placeholder='Enter your notice here....' id="notice"></textarea>
                        <input type="submit" id='inputbutton' value="Submit" className='web__settings__button'/>
                    </form> 
                </div>  

                <div className="prev__notice__container">
                    <h4>Your previous general notice</h4> 
                        {
                            notice.map(info =>{
                                ////console.log(info);
                                return(<div key={info.id_find} id={info.id_find} className='mb-2'>
                                     <p>{info.notice}</p>
                                     <button onClick={()=>handleDeleteAccess(info.id_find)} className='btn btn-danger mr-2'>delete</button> 
                                </div>)
                            })
                        } 
                </div>
            </div>:""}

            {showOffice? 

            <div>
                <div className="web__form__container "> 
                    <h4>OFFICE NOTICE.....</h4> 
                    <form onSubmit={handleOfficeNoticeFormSubmit}>   
                        <textarea name="officenotice" placeholder='Enter your office notice here....' id="officenotice" required></textarea>
                        <input type="submit" id='inputbutton' value="Submit" className='web__settings__button'/>
                    </form> 
                </div>
                <div className="prev__notice__container">
                    <h4>Your previous office notice</h4> 
                        {
                            officeNotice.map(info =>{
                                ////console.log(info);
                                return(<div key={info.id_find} id={info.id_find} className='mb-2'>
                                     <p>{info.notice}</p>
                                     <button onClick={()=>handleDeleteAccessOffice(info.id_find)} className='btn btn-danger mr-2'>delete</button> 
                                </div>)
                            })
                        } 
                </div>
            </div>:""}
            </div>
        </div>
    );
};

export default NoticeForm;