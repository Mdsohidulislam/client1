/**
 *  title : app helper function
 *  description: helper mama for build this appllication
 *  author: md sohidul islam
 *  date: 03/09/2021
 */


//   handle object module-scaffolding

const handle = {};

handle._sum=(...arg)=>{
    let sum = 0;

     arg.map(num => {
         sum += Number(num)
     })
    
     return sum;
}

module.exports = handle;

