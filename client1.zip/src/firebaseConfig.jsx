const firebaseConfigKeys = {
    apiKey: "AIzaSyCcI8Lvzv7KMTlWrLw4IB5WCr520ItRl1k",
    authDomain: "bsbl-695a8.firebaseapp.com",
    projectId: "bsbl-695a8",
    storageBucket: "bsbl-695a8.appspot.com",
    messagingSenderId: "440101832723",
    appId: "1:440101832723:web:648f3ba4d157107fcb97e6"
  };

  export default firebaseConfigKeys;