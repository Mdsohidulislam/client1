import React from 'react'; 

const Room = () => {
    return (
        <div className={`jonin__room__container`}>  
            <div className="room__container"> 

            </div>
            <div className="member__and__message__container"> 
                <div className="member__active__list">
                    <div className="intro">
                        <p>ACTIVE NOW</p>
                    </div>
                    <div className="members">
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                        <div className="member"></div>
                    </div>
                </div>
                <div className="message__container"> 

                </div>
            </div>
            <div className="send__message__container">

            </div>
        </div>
    );
};

export default Room;