import React from 'react';
import SideNavbar from './Components/SideNavbar/SideNavbar';

const dynamic = () => {
    return (
        <div> 
            <SideNavbar/> 
            <div> 
                <h1>Hello world</h1>
            </div>
        </div>
    );
};

export default dynamic;