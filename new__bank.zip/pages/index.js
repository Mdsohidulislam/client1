import Link from 'next/link';
import { useRouter } from 'next/router';
import SideNavbar from './Components/SideNavbar/SideNavbar';

const App = () => {
  const router = useRouter();

  return (
    <header className='app__root' id="app__root"> 
        <SideNavbar/>
        <h1 className={router.pathname==='/'?"active__side__link__style":""}>Hello world</h1>
    </header>
  )
}


export default App;