import React from 'react';
import SideNavbar from './Components/SideNavbar/SideNavbar';

const Home = () => {
    return (
        <div>
            <SideNavbar/>
        </div>
    );
};

export default Home;