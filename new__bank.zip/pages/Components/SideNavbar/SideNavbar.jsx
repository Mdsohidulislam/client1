import React from 'react'; 
import Link from 'next/link';
import { useRouter } from 'next/router';

 
const SideNavbar = () => {

    const router =useRouter(); 
    console.log('====================================');
    console.log(router.pathname);
    console.log('====================================');

    return (
        <div className='side__navbar__container'> 
            <div className="side__navbar">  
                <div className="">
                    <Link href="/Profile">
                        <a className={router.pathname == "/" ? "active__side__link__style" : ""}>
                            PROFILE
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/DGL">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            DGL 
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/DGLResults">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            DGL RESULTS
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/GL">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            GL
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/LoanReciever">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            LOAN RECIEVER
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/LoanExchange">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            LOAN EXCHANGE
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/MemberIntroduction">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            MEMBER INTRODUCTION
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/Passbook">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            PASSBOOK
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/UserSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            USER SETTINGS
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/AdminPanel">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            ADMIN PANEL
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/PassbookStatement">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            PASSBOOK STATEMENT
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/LoanExchangeStatement">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            Loan Exchange Statement
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/LoanRecieverStatement">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            LOAN RECIEVER STATEMENT
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/GLStatement">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            GL STATEMENT
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/DGLStatement">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            DGL STATEMENT
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/DGLResultsStatement">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            DGL RESULTS STATEMENT
                        </a>
                    </Link>
                </div> 

                <div className="">
                    <Link href="/GeneralNoticeSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            GENERAL NOTICE SETTINGS
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/OfficeNoticeSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            OFFICE NOTICE SETTINGS
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/AboutUsSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            ABOUT US SETTINGS
                        </a>
                    </Link>
                </div> 
                <div className="">
                    <Link href="/ContactUsSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            CONTACT US SETTINGS
                        </a>
                    </Link>
                </div>
                <div className="">
                    <Link href="/CarouselSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            CAROUSEL SETTINGS
                        </a>
                    </Link>
                </div>
                <div className="">
                    <Link href="/AddServiceSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            ADD SERVICE SETTINGS
                        </a>
                    </Link>
                </div>
                <div className="">
                    <Link href="/AddServiceSettings">
                        <a className={router.pathname == "/home" ? "active__side__link__style" : ""}>
                            LOG OUT
                        </a>
                    </Link>
                </div>

            </div>
        </div>
    );
};

export default SideNavbar;