import React from 'react';
import SideNavbar from '../SideNavbar/SideNavbar';

const DGL = () => {

    const handleSubmit = (e) => {
        e.preventDefault();
    }

    return (
        <div className='d-flex'>
            <SideNavbar className/>  
            <div className='w-100 bg__chosen__red'>
                <div className="form__container bg__chosen__green ml-3 p-2bg-success">
                     <form onSubmit={handleSubmit} className='row p-1'>
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="date" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div>
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div> 
                        <div className='col-6 col-md-4 col-lg-3'>
                            <div className="form-group">
                                <label>Email address</label>
                                <input
                                type="email" 
                                className="form-control" 
                                id="exampleInputEmail1" 
                                aria-describedby="emailHelp" 
                                placeholder="Enter email"/>  
                            </div> 
                        </div>   
                     </form>
                </div>
            </div>
        </div>
    );
};

export default DGL;